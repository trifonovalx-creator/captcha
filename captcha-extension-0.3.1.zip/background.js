(() => {
  // src/background.js
  var key = (tabId) => `controller:${tabId}`;
  chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.id) return;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      const saved = await chrome.storage.session.get(key(tab.id)), existing = saved[key(tab.id)];
      if (existing) {
        try {
          await chrome.windows.update(existing, { focused: true });
          await chrome.runtime.sendMessage({ kind: "ACTIVATE_CONTROLLER", tabId: tab.id }).catch(() => {
          });
          return;
        } catch {
          await chrome.storage.session.remove(key(tab.id));
        }
      }
      const window = await chrome.windows.create({
        url: chrome.runtime.getURL(`controller.html?tab=${tab.id}`),
        type: "popup",
        width: 600,
        height: 830,
        focused: false
      });
      await chrome.storage.session.set({ [key(tab.id)]: window.id });
      await chrome.action.setBadgeText({ tabId: tab.id, text: "\u2026" });
    } catch (error) {
      await chrome.action.setBadgeText({ tabId: tab.id, text: "!" });
      await chrome.action.setTitle({
        tabId: tab.id,
        title: `\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C\u0441\u044F: ${error.message}`
      });
    }
  });
  chrome.windows.onRemoved.addListener(async (windowId) => {
    const entries = await chrome.storage.session.get(null);
    for (const [name, id] of Object.entries(entries))
      if (name.startsWith("controller:") && id === windowId) {
        const tabId = Number(name.slice("controller:".length));
        await chrome.storage.session.remove(name);
        await chrome.tabs.sendMessage(tabId, { kind: "STOP" }).catch(() => {
        });
        await chrome.action.setBadgeText({ tabId, text: "" }).catch(() => {
        });
      }
  });
  chrome.tabs.onRemoved.addListener(
    (tabId) => chrome.storage.session.remove(key(tabId))
  );
  async function decodeLocalPNG(url) {
    const bytes = Uint8Array.from(
      atob(url.slice(url.indexOf(",") + 1)),
      (c) => c.charCodeAt(0)
    );
    return createImageBitmap(new Blob([bytes], { type: "image/png" }));
  }
  async function verifyVisibleImage(tabId, { image, rect, viewport }) {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active) throw Error("\u0418\u0441\u0445\u043E\u0434\u043D\u0430\u044F \u0432\u043A\u043B\u0430\u0434\u043A\u0430 \u043D\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u0430.");
    const shot = await decodeLocalPNG(
      await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" })
    );
    const expected = await decodeLocalPNG(image), sx = shot.width / viewport.width, sy = shot.height / viewport.height;
    const x = Math.round(rect.x * sx), y = Math.round(rect.y * sy), w = Math.round(rect.width * sx), h = Math.round(rect.height * sy);
    if (rect.x < 0 || rect.y < 0 || rect.x + rect.width > viewport.width || rect.y + rect.height > viewport.height || w !== expected.width || h !== expected.height)
      throw Error("\u041E\u0431\u043B\u0430\u0441\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u0432\u043D\u0435 \u044D\u043A\u0440\u0430\u043D\u0430.");
    const c = new OffscreenCanvas(w, h), ctx = c.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(shot, x, y, w, h, 0, 0, w, h);
    const a = ctx.getImageData(0, 0, w, h).data;
    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(expected, 0, 0);
    const b = ctx.getImageData(0, 0, w, h).data;
    shot.close();
    expected.close();
    if (!(await chrome.tabs.get(tabId)).active) return false;
    return a.length === b.length && a.every((v, i) => v === b[i]);
  }
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (message.kind !== "VERIFY_VISIBLE_IMAGE" || sender.id !== chrome.runtime.id || !sender.tab?.id)
      return;
    verifyVisibleImage(sender.tab.id, message).then(
      (ok) => reply({ ok }),
      (e) => reply({ ok: false, reason: e.message })
    );
    return true;
  });
})();
