(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __commonJS = (cb, mod) => function __require2() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/regenerator-runtime/runtime.js
  var require_runtime = __commonJS({
    "node_modules/regenerator-runtime/runtime.js"(exports, module) {
      var runtime = (function(exports2) {
        "use strict";
        var Op = Object.prototype;
        var hasOwn = Op.hasOwnProperty;
        var defineProperty = Object.defineProperty || function(obj, key, desc) {
          obj[key] = desc.value;
        };
        var undefined2;
        var $Symbol = typeof Symbol === "function" ? Symbol : {};
        var iteratorSymbol = $Symbol.iterator || "@@iterator";
        var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
        var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
        function define(obj, key, value) {
          Object.defineProperty(obj, key, {
            value,
            enumerable: true,
            configurable: true,
            writable: true
          });
          return obj[key];
        }
        try {
          define({}, "");
        } catch (err) {
          define = function(obj, key, value) {
            return obj[key] = value;
          };
        }
        function wrap(innerFn, outerFn, self, tryLocsList) {
          var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
          var generator = Object.create(protoGenerator.prototype);
          var context = new Context(tryLocsList || []);
          defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) });
          return generator;
        }
        exports2.wrap = wrap;
        function tryCatch(fn, obj, arg) {
          try {
            return { type: "normal", arg: fn.call(obj, arg) };
          } catch (err) {
            return { type: "throw", arg: err };
          }
        }
        var GenStateSuspendedStart = "suspendedStart";
        var GenStateSuspendedYield = "suspendedYield";
        var GenStateExecuting = "executing";
        var GenStateCompleted = "completed";
        var ContinueSentinel = {};
        function Generator() {
        }
        function GeneratorFunction() {
        }
        function GeneratorFunctionPrototype() {
        }
        var IteratorPrototype = {};
        define(IteratorPrototype, iteratorSymbol, function() {
          return this;
        });
        var getProto = Object.getPrototypeOf;
        var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
        if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
          IteratorPrototype = NativeIteratorPrototype;
        }
        var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
        GeneratorFunction.prototype = GeneratorFunctionPrototype;
        defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: true });
        defineProperty(
          GeneratorFunctionPrototype,
          "constructor",
          { value: GeneratorFunction, configurable: true }
        );
        GeneratorFunction.displayName = define(
          GeneratorFunctionPrototype,
          toStringTagSymbol,
          "GeneratorFunction"
        );
        function defineIteratorMethods(prototype) {
          ["next", "throw", "return"].forEach(function(method) {
            define(prototype, method, function(arg) {
              return this._invoke(method, arg);
            });
          });
        }
        exports2.isGeneratorFunction = function(genFun) {
          var ctor = typeof genFun === "function" && genFun.constructor;
          return ctor ? ctor === GeneratorFunction || // For the native GeneratorFunction constructor, the best we can
          // do is to check its .name property.
          (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
        };
        exports2.mark = function(genFun) {
          if (Object.setPrototypeOf) {
            Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
          } else {
            genFun.__proto__ = GeneratorFunctionPrototype;
            define(genFun, toStringTagSymbol, "GeneratorFunction");
          }
          genFun.prototype = Object.create(Gp);
          return genFun;
        };
        exports2.awrap = function(arg) {
          return { __await: arg };
        };
        function AsyncIterator(generator, PromiseImpl) {
          function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if (record.type === "throw") {
              reject(record.arg);
            } else {
              var result = record.arg;
              var value = result.value;
              if (value && typeof value === "object" && hasOwn.call(value, "__await")) {
                return PromiseImpl.resolve(value.__await).then(function(value2) {
                  invoke("next", value2, resolve, reject);
                }, function(err) {
                  invoke("throw", err, resolve, reject);
                });
              }
              return PromiseImpl.resolve(value).then(function(unwrapped) {
                result.value = unwrapped;
                resolve(result);
              }, function(error) {
                return invoke("throw", error, resolve, reject);
              });
            }
          }
          var previousPromise;
          function enqueue(method, arg) {
            function callInvokeWithMethodAndArg() {
              return new PromiseImpl(function(resolve, reject) {
                invoke(method, arg, resolve, reject);
              });
            }
            return previousPromise = // If enqueue has been called before, then we want to wait until
            // all previous Promises have been resolved before calling invoke,
            // so that results are always delivered in the correct order. If
            // enqueue has not been called before, then it is important to
            // call invoke immediately, without waiting on a callback to fire,
            // so that the async generator function has the opportunity to do
            // any necessary setup in a predictable way. This predictability
            // is why the Promise constructor synchronously invokes its
            // executor callback, and why async functions synchronously
            // execute code before the first await. Since we implement simple
            // async functions in terms of async generators, it is especially
            // important to get this right, even though it requires care.
            previousPromise ? previousPromise.then(
              callInvokeWithMethodAndArg,
              // Avoid propagating failures to Promises returned by later
              // invocations of the iterator.
              callInvokeWithMethodAndArg
            ) : callInvokeWithMethodAndArg();
          }
          defineProperty(this, "_invoke", { value: enqueue });
        }
        defineIteratorMethods(AsyncIterator.prototype);
        define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
          return this;
        });
        exports2.AsyncIterator = AsyncIterator;
        exports2.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
          if (PromiseImpl === void 0) PromiseImpl = Promise;
          var iter = new AsyncIterator(
            wrap(innerFn, outerFn, self, tryLocsList),
            PromiseImpl
          );
          return exports2.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
          });
        };
        function makeInvokeMethod(innerFn, self, context) {
          var state = GenStateSuspendedStart;
          return function invoke(method, arg) {
            if (state === GenStateExecuting) {
              throw new Error("Generator is already running");
            }
            if (state === GenStateCompleted) {
              if (method === "throw") {
                throw arg;
              }
              return doneResult();
            }
            context.method = method;
            context.arg = arg;
            while (true) {
              var delegate = context.delegate;
              if (delegate) {
                var delegateResult = maybeInvokeDelegate(delegate, context);
                if (delegateResult) {
                  if (delegateResult === ContinueSentinel) continue;
                  return delegateResult;
                }
              }
              if (context.method === "next") {
                context.sent = context._sent = context.arg;
              } else if (context.method === "throw") {
                if (state === GenStateSuspendedStart) {
                  state = GenStateCompleted;
                  throw context.arg;
                }
                context.dispatchException(context.arg);
              } else if (context.method === "return") {
                context.abrupt("return", context.arg);
              }
              state = GenStateExecuting;
              var record = tryCatch(innerFn, self, context);
              if (record.type === "normal") {
                state = context.done ? GenStateCompleted : GenStateSuspendedYield;
                if (record.arg === ContinueSentinel) {
                  continue;
                }
                return {
                  value: record.arg,
                  done: context.done
                };
              } else if (record.type === "throw") {
                state = GenStateCompleted;
                context.method = "throw";
                context.arg = record.arg;
              }
            }
          };
        }
        function maybeInvokeDelegate(delegate, context) {
          var methodName = context.method;
          var method = delegate.iterator[methodName];
          if (method === undefined2) {
            context.delegate = null;
            if (methodName === "throw" && delegate.iterator["return"]) {
              context.method = "return";
              context.arg = undefined2;
              maybeInvokeDelegate(delegate, context);
              if (context.method === "throw") {
                return ContinueSentinel;
              }
            }
            if (methodName !== "return") {
              context.method = "throw";
              context.arg = new TypeError(
                "The iterator does not provide a '" + methodName + "' method"
              );
            }
            return ContinueSentinel;
          }
          var record = tryCatch(method, delegate.iterator, context.arg);
          if (record.type === "throw") {
            context.method = "throw";
            context.arg = record.arg;
            context.delegate = null;
            return ContinueSentinel;
          }
          var info = record.arg;
          if (!info) {
            context.method = "throw";
            context.arg = new TypeError("iterator result is not an object");
            context.delegate = null;
            return ContinueSentinel;
          }
          if (info.done) {
            context[delegate.resultName] = info.value;
            context.next = delegate.nextLoc;
            if (context.method !== "return") {
              context.method = "next";
              context.arg = undefined2;
            }
          } else {
            return info;
          }
          context.delegate = null;
          return ContinueSentinel;
        }
        defineIteratorMethods(Gp);
        define(Gp, toStringTagSymbol, "Generator");
        define(Gp, iteratorSymbol, function() {
          return this;
        });
        define(Gp, "toString", function() {
          return "[object Generator]";
        });
        function pushTryEntry(locs) {
          var entry = { tryLoc: locs[0] };
          if (1 in locs) {
            entry.catchLoc = locs[1];
          }
          if (2 in locs) {
            entry.finallyLoc = locs[2];
            entry.afterLoc = locs[3];
          }
          this.tryEntries.push(entry);
        }
        function resetTryEntry(entry) {
          var record = entry.completion || {};
          record.type = "normal";
          delete record.arg;
          entry.completion = record;
        }
        function Context(tryLocsList) {
          this.tryEntries = [{ tryLoc: "root" }];
          tryLocsList.forEach(pushTryEntry, this);
          this.reset(true);
        }
        exports2.keys = function(val) {
          var object = Object(val);
          var keys = [];
          for (var key in object) {
            keys.push(key);
          }
          keys.reverse();
          return function next() {
            while (keys.length) {
              var key2 = keys.pop();
              if (key2 in object) {
                next.value = key2;
                next.done = false;
                return next;
              }
            }
            next.done = true;
            return next;
          };
        };
        function values(iterable) {
          if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) {
              return iteratorMethod.call(iterable);
            }
            if (typeof iterable.next === "function") {
              return iterable;
            }
            if (!isNaN(iterable.length)) {
              var i = -1, next = function next2() {
                while (++i < iterable.length) {
                  if (hasOwn.call(iterable, i)) {
                    next2.value = iterable[i];
                    next2.done = false;
                    return next2;
                  }
                }
                next2.value = undefined2;
                next2.done = true;
                return next2;
              };
              return next.next = next;
            }
          }
          return { next: doneResult };
        }
        exports2.values = values;
        function doneResult() {
          return { value: undefined2, done: true };
        }
        Context.prototype = {
          constructor: Context,
          reset: function(skipTempReset) {
            this.prev = 0;
            this.next = 0;
            this.sent = this._sent = undefined2;
            this.done = false;
            this.delegate = null;
            this.method = "next";
            this.arg = undefined2;
            this.tryEntries.forEach(resetTryEntry);
            if (!skipTempReset) {
              for (var name in this) {
                if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
                  this[name] = undefined2;
                }
              }
            }
          },
          stop: function() {
            this.done = true;
            var rootEntry = this.tryEntries[0];
            var rootRecord = rootEntry.completion;
            if (rootRecord.type === "throw") {
              throw rootRecord.arg;
            }
            return this.rval;
          },
          dispatchException: function(exception) {
            if (this.done) {
              throw exception;
            }
            var context = this;
            function handle(loc, caught) {
              record.type = "throw";
              record.arg = exception;
              context.next = loc;
              if (caught) {
                context.method = "next";
                context.arg = undefined2;
              }
              return !!caught;
            }
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              var record = entry.completion;
              if (entry.tryLoc === "root") {
                return handle("end");
              }
              if (entry.tryLoc <= this.prev) {
                var hasCatch = hasOwn.call(entry, "catchLoc");
                var hasFinally = hasOwn.call(entry, "finallyLoc");
                if (hasCatch && hasFinally) {
                  if (this.prev < entry.catchLoc) {
                    return handle(entry.catchLoc, true);
                  } else if (this.prev < entry.finallyLoc) {
                    return handle(entry.finallyLoc);
                  }
                } else if (hasCatch) {
                  if (this.prev < entry.catchLoc) {
                    return handle(entry.catchLoc, true);
                  }
                } else if (hasFinally) {
                  if (this.prev < entry.finallyLoc) {
                    return handle(entry.finallyLoc);
                  }
                } else {
                  throw new Error("try statement without catch or finally");
                }
              }
            }
          },
          abrupt: function(type, arg) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                var finallyEntry = entry;
                break;
              }
            }
            if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
              finallyEntry = null;
            }
            var record = finallyEntry ? finallyEntry.completion : {};
            record.type = type;
            record.arg = arg;
            if (finallyEntry) {
              this.method = "next";
              this.next = finallyEntry.finallyLoc;
              return ContinueSentinel;
            }
            return this.complete(record);
          },
          complete: function(record, afterLoc) {
            if (record.type === "throw") {
              throw record.arg;
            }
            if (record.type === "break" || record.type === "continue") {
              this.next = record.arg;
            } else if (record.type === "return") {
              this.rval = this.arg = record.arg;
              this.method = "return";
              this.next = "end";
            } else if (record.type === "normal" && afterLoc) {
              this.next = afterLoc;
            }
            return ContinueSentinel;
          },
          finish: function(finallyLoc) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.finallyLoc === finallyLoc) {
                this.complete(entry.completion, entry.afterLoc);
                resetTryEntry(entry);
                return ContinueSentinel;
              }
            }
          },
          "catch": function(tryLoc) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.tryLoc === tryLoc) {
                var record = entry.completion;
                if (record.type === "throw") {
                  var thrown = record.arg;
                  resetTryEntry(entry);
                }
                return thrown;
              }
            }
            throw new Error("illegal catch attempt");
          },
          delegateYield: function(iterable, resultName, nextLoc) {
            this.delegate = {
              iterator: values(iterable),
              resultName,
              nextLoc
            };
            if (this.method === "next") {
              this.arg = undefined2;
            }
            return ContinueSentinel;
          }
        };
        return exports2;
      })(
        // If this script is executing as a CommonJS module, use module.exports
        // as the regeneratorRuntime namespace. Otherwise create a new empty
        // object. Either way, the resulting object will be used to initialize
        // the regeneratorRuntime variable at the top of this file.
        typeof module === "object" ? module.exports : {}
      );
      try {
        regeneratorRuntime = runtime;
      } catch (accidentalStrictMode) {
        if (typeof globalThis === "object") {
          globalThis.regeneratorRuntime = runtime;
        } else {
          Function("r", "regeneratorRuntime = r")(runtime);
        }
      }
    }
  });

  // node_modules/tesseract.js/src/utils/getId.js
  var require_getId = __commonJS({
    "node_modules/tesseract.js/src/utils/getId.js"(exports, module) {
      "use strict";
      module.exports = (prefix, cnt) => `${prefix}-${cnt}-${Math.random().toString(16).slice(3, 8)}`;
    }
  });

  // node_modules/tesseract.js/src/createJob.js
  var require_createJob = __commonJS({
    "node_modules/tesseract.js/src/createJob.js"(exports, module) {
      "use strict";
      var getId = require_getId();
      var jobCounter = 0;
      module.exports = ({
        id: _id,
        action,
        payload = {}
      }) => {
        let id = _id;
        if (typeof id === "undefined") {
          id = getId("Job", jobCounter);
          jobCounter += 1;
        }
        return {
          id,
          action,
          payload
        };
      };
    }
  });

  // node_modules/tesseract.js/src/utils/log.js
  var require_log = __commonJS({
    "node_modules/tesseract.js/src/utils/log.js"(exports) {
      "use strict";
      var logging = false;
      exports.logging = logging;
      exports.setLogging = (_logging) => {
        logging = _logging;
      };
      exports.log = (...args) => logging ? console.log.apply(exports, args) : null;
    }
  });

  // node_modules/tesseract.js/src/createScheduler.js
  var require_createScheduler = __commonJS({
    "node_modules/tesseract.js/src/createScheduler.js"(exports, module) {
      "use strict";
      var createJob = require_createJob();
      var { log } = require_log();
      var getId = require_getId();
      var schedulerCounter = 0;
      module.exports = () => {
        const id = getId("Scheduler", schedulerCounter);
        const workers = {};
        const runningWorkers = {};
        let jobQueue = [];
        schedulerCounter += 1;
        const getQueueLen = () => jobQueue.length;
        const getNumWorkers = () => Object.keys(workers).length;
        const dequeue = () => {
          if (jobQueue.length !== 0) {
            const wIds = Object.keys(workers);
            for (let i = 0; i < wIds.length; i += 1) {
              if (typeof runningWorkers[wIds[i]] === "undefined") {
                jobQueue[0](workers[wIds[i]]);
                break;
              }
            }
          }
        };
        const queue = (action, payload) => new Promise((resolve, reject) => {
          const job2 = createJob({ action, payload });
          jobQueue.push(async (w) => {
            jobQueue.shift();
            runningWorkers[w.id] = job2;
            try {
              resolve(await w[action].apply(exports, [...payload, job2.id]));
            } catch (err) {
              reject(err);
            } finally {
              delete runningWorkers[w.id];
              dequeue();
            }
          });
          log(`[${id}]: Add ${job2.id} to JobQueue`);
          log(`[${id}]: JobQueue length=${jobQueue.length}`);
          dequeue();
        });
        const addWorker = (w) => {
          workers[w.id] = w;
          log(`[${id}]: Add ${w.id}`);
          log(`[${id}]: Number of workers=${getNumWorkers()}`);
          dequeue();
          return w.id;
        };
        const addJob = async (action, ...payload) => {
          if (getNumWorkers() === 0) {
            throw Error(`[${id}]: You need to have at least one worker before adding jobs`);
          }
          return queue(action, payload);
        };
        const terminate = async () => {
          Object.keys(workers).forEach(async (wid) => {
            await workers[wid].terminate();
          });
          jobQueue = [];
        };
        return {
          addWorker,
          addJob,
          terminate,
          getQueueLen,
          getNumWorkers
        };
      };
    }
  });

  // node_modules/tesseract.js/src/utils/getEnvironment.js
  var require_getEnvironment = __commonJS({
    "node_modules/tesseract.js/src/utils/getEnvironment.js"(exports, module) {
      "use strict";
      module.exports = (key) => {
        const env = {};
        if (typeof WorkerGlobalScope !== "undefined") {
          env.type = "webworker";
        } else if (typeof document === "object") {
          env.type = "browser";
        } else if (typeof process === "object" && typeof __require === "function") {
          env.type = "node";
        }
        if (typeof key === "undefined") {
          return env;
        }
        return env[key];
      };
    }
  });

  // node_modules/tesseract.js/src/utils/resolvePaths.js
  var require_resolvePaths = __commonJS({
    "node_modules/tesseract.js/src/utils/resolvePaths.js"(exports, module) {
      "use strict";
      var isBrowser = require_getEnvironment()("type") === "browser";
      var resolveURL = isBrowser ? (s) => new URL(s, window.location.href).href : (s) => s;
      module.exports = (options) => {
        const opts = { ...options };
        ["corePath", "workerPath", "langPath"].forEach((key) => {
          if (options[key]) {
            opts[key] = resolveURL(opts[key]);
          }
        });
        return opts;
      };
    }
  });

  // node_modules/tesseract.js/src/constants/OEM.js
  var require_OEM = __commonJS({
    "node_modules/tesseract.js/src/constants/OEM.js"(exports, module) {
      "use strict";
      module.exports = {
        TESSERACT_ONLY: 0,
        LSTM_ONLY: 1,
        TESSERACT_LSTM_COMBINED: 2,
        DEFAULT: 3
      };
    }
  });

  // node_modules/tesseract.js/package.json
  var require_package = __commonJS({
    "node_modules/tesseract.js/package.json"(exports, module) {
      module.exports = {
        name: "tesseract.js",
        version: "6.0.1",
        description: "Pure Javascript Multilingual OCR",
        main: "src/index.js",
        type: "commonjs",
        types: "src/index.d.ts",
        unpkg: "dist/tesseract.min.js",
        jsdelivr: "dist/tesseract.min.js",
        scripts: {
          start: "node scripts/server.js",
          build: "rimraf dist && webpack --config scripts/webpack.config.prod.js && rollup -c scripts/rollup.esm.mjs",
          "profile:tesseract": "webpack-bundle-analyzer dist/tesseract-stats.json",
          "profile:worker": "webpack-bundle-analyzer dist/worker-stats.json",
          prepublishOnly: "npm run build",
          wait: "rimraf dist && wait-on http://localhost:3000/dist/tesseract.min.js",
          test: "npm-run-all -p -r start test:all",
          "test:all": "npm-run-all wait test:browser test:node:all",
          "test:browser": "karma start karma.conf.js",
          "test:node": "nyc mocha --exit --bail --require ./scripts/test-helper.mjs",
          "test:node:all": "npm run test:node -- ./tests/*.test.mjs",
          lint: "eslint src",
          "lint:fix": "eslint --fix src",
          postinstall: "opencollective-postinstall || true"
        },
        browser: {
          "./src/worker/node/index.js": "./src/worker/browser/index.js"
        },
        author: "",
        contributors: [
          "jeromewu"
        ],
        license: "Apache-2.0",
        devDependencies: {
          "@babel/core": "^7.21.4",
          "@babel/eslint-parser": "^7.21.3",
          "@babel/preset-env": "^7.21.4",
          "@rollup/plugin-commonjs": "^24.1.0",
          acorn: "^8.8.2",
          "babel-loader": "^9.1.2",
          buffer: "^6.0.3",
          cors: "^2.8.5",
          eslint: "^7.32.0",
          "eslint-config-airbnb-base": "^14.2.1",
          "eslint-plugin-import": "^2.27.5",
          "expect.js": "^0.3.1",
          express: "^4.18.2",
          mocha: "^10.2.0",
          "npm-run-all": "^4.1.5",
          karma: "^6.4.2",
          "karma-chrome-launcher": "^3.2.0",
          "karma-firefox-launcher": "^2.1.2",
          "karma-mocha": "^2.0.1",
          "karma-webpack": "^5.0.0",
          nyc: "^15.1.0",
          rimraf: "^5.0.0",
          rollup: "^3.20.7",
          "wait-on": "^7.0.1",
          webpack: "^5.79.0",
          "webpack-bundle-analyzer": "^4.8.0",
          "webpack-cli": "^5.0.1",
          "webpack-dev-middleware": "^6.0.2",
          "rollup-plugin-sourcemaps": "^0.6.3"
        },
        dependencies: {
          "bmp-js": "^0.1.0",
          "idb-keyval": "^6.2.0",
          "is-url": "^1.2.4",
          "node-fetch": "^2.6.9",
          "opencollective-postinstall": "^2.0.3",
          "regenerator-runtime": "^0.13.3",
          "tesseract.js-core": "^6.0.0",
          "wasm-feature-detect": "^1.2.11",
          zlibjs: "^0.3.1"
        },
        overrides: {
          "@rollup/pluginutils": "^5.0.2"
        },
        repository: {
          type: "git",
          url: "https://github.com/naptha/tesseract.js.git"
        },
        bugs: {
          url: "https://github.com/naptha/tesseract.js/issues"
        },
        homepage: "https://github.com/naptha/tesseract.js",
        collective: {
          type: "opencollective",
          url: "https://opencollective.com/tesseractjs"
        }
      };
    }
  });

  // node_modules/tesseract.js/src/constants/defaultOptions.js
  var require_defaultOptions = __commonJS({
    "node_modules/tesseract.js/src/constants/defaultOptions.js"(exports, module) {
      "use strict";
      module.exports = {
        /*
         * Use BlobURL for worker script by default
         * TODO: remove this option
         *
         */
        workerBlobURL: true,
        logger: () => {
        }
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/defaultOptions.js
  var require_defaultOptions2 = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/defaultOptions.js"(exports, module) {
      "use strict";
      var version = require_package().version;
      var defaultOptions = require_defaultOptions();
      module.exports = {
        ...defaultOptions,
        workerPath: `https://cdn.jsdelivr.net/npm/tesseract.js@v${version}/dist/worker.min.js`
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/spawnWorker.js
  var require_spawnWorker = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/spawnWorker.js"(exports, module) {
      "use strict";
      module.exports = ({ workerPath, workerBlobURL }) => {
        let worker2;
        if (Blob && URL && workerBlobURL) {
          const blob = new Blob([`importScripts("${workerPath}");`], {
            type: "application/javascript"
          });
          worker2 = new Worker(URL.createObjectURL(blob));
        } else {
          worker2 = new Worker(workerPath);
        }
        return worker2;
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/terminateWorker.js
  var require_terminateWorker = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/terminateWorker.js"(exports, module) {
      "use strict";
      module.exports = (worker2) => {
        worker2.terminate();
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/onMessage.js
  var require_onMessage = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/onMessage.js"(exports, module) {
      "use strict";
      module.exports = (worker2, handler) => {
        worker2.onmessage = ({ data }) => {
          handler(data);
        };
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/send.js
  var require_send = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/send.js"(exports, module) {
      "use strict";
      module.exports = async (worker2, packet) => {
        worker2.postMessage(packet);
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/loadImage.js
  var require_loadImage = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/loadImage.js"(exports, module) {
      "use strict";
      var readFromBlobOrFile = (blob) => new Promise((resolve, reject) => {
        const fileReader = new FileReader();
        fileReader.onload = () => {
          resolve(fileReader.result);
        };
        fileReader.onerror = ({ target: { error: { code } } }) => {
          reject(Error(`File could not be read! Code=${code}`));
        };
        fileReader.readAsArrayBuffer(blob);
      });
      var loadImage2 = async (image) => {
        let data = image;
        if (typeof image === "undefined") {
          return "undefined";
        }
        if (typeof image === "string") {
          if (/data:image\/([a-zA-Z]*);base64,([^"]*)/.test(image)) {
            data = atob(image.split(",")[1]).split("").map((c) => c.charCodeAt(0));
          } else {
            const resp = await fetch(image);
            data = await resp.arrayBuffer();
          }
        } else if (typeof HTMLElement !== "undefined" && image instanceof HTMLElement) {
          if (image.tagName === "IMG") {
            data = await loadImage2(image.src);
          }
          if (image.tagName === "VIDEO") {
            data = await loadImage2(image.poster);
          }
          if (image.tagName === "CANVAS") {
            await new Promise((resolve) => {
              image.toBlob(async (blob) => {
                data = await readFromBlobOrFile(blob);
                resolve();
              });
            });
          }
        } else if (typeof OffscreenCanvas !== "undefined" && image instanceof OffscreenCanvas) {
          const blob = await image.convertToBlob();
          data = await readFromBlobOrFile(blob);
        } else if (image instanceof File || image instanceof Blob) {
          data = await readFromBlobOrFile(image);
        }
        return new Uint8Array(data);
      };
      module.exports = loadImage2;
    }
  });

  // node_modules/tesseract.js/src/worker/browser/index.js
  var require_browser = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/index.js"(exports, module) {
      "use strict";
      var defaultOptions = require_defaultOptions2();
      var spawnWorker = require_spawnWorker();
      var terminateWorker2 = require_terminateWorker();
      var onMessage = require_onMessage();
      var send2 = require_send();
      var loadImage2 = require_loadImage();
      module.exports = {
        defaultOptions,
        spawnWorker,
        terminateWorker: terminateWorker2,
        onMessage,
        send: send2,
        loadImage: loadImage2
      };
    }
  });

  // node_modules/tesseract.js/src/createWorker.js
  var require_createWorker = __commonJS({
    "node_modules/tesseract.js/src/createWorker.js"(exports, module) {
      "use strict";
      var resolvePaths = require_resolvePaths();
      var createJob = require_createJob();
      var { log } = require_log();
      var getId = require_getId();
      var OEM = require_OEM();
      var {
        defaultOptions,
        spawnWorker,
        terminateWorker: terminateWorker2,
        onMessage,
        loadImage: loadImage2,
        send: send2
      } = require_browser();
      var workerCounter = 0;
      module.exports = async (langs = "eng", oem = OEM.LSTM_ONLY, _options = {}, config = {}) => {
        const id = getId("Worker", workerCounter);
        const {
          logger,
          errorHandler,
          ...options
        } = resolvePaths({
          ...defaultOptions,
          ..._options
        });
        const promises = {};
        const currentLangs = typeof langs === "string" ? langs.split("+") : langs;
        let currentOem = oem;
        let currentConfig = config;
        const lstmOnlyCore = [OEM.DEFAULT, OEM.LSTM_ONLY].includes(oem) && !options.legacyCore;
        let workerResReject;
        let workerResResolve;
        const workerRes = new Promise((resolve, reject) => {
          workerResResolve = resolve;
          workerResReject = reject;
        });
        const workerError = (event) => {
          workerResReject(event.message);
        };
        let worker2 = spawnWorker(options);
        worker2.onerror = workerError;
        workerCounter += 1;
        const startJob = ({ id: jobId, action, payload }) => new Promise((resolve, reject) => {
          log(`[${id}]: Start ${jobId}, action=${action}`);
          const promiseId = `${action}-${jobId}`;
          promises[promiseId] = { resolve, reject };
          send2(worker2, {
            workerId: id,
            jobId,
            action,
            payload
          });
        });
        const load = () => console.warn("`load` is depreciated and should be removed from code (workers now come pre-loaded)");
        const loadInternal = (jobId) => startJob(createJob({
          id: jobId,
          action: "load",
          payload: { options: { lstmOnly: lstmOnlyCore, corePath: options.corePath, logging: options.logging } }
        }));
        const writeText = (path, text, jobId) => startJob(createJob({
          id: jobId,
          action: "FS",
          payload: { method: "writeFile", args: [path, text] }
        }));
        const readText = (path, jobId) => startJob(createJob({
          id: jobId,
          action: "FS",
          payload: { method: "readFile", args: [path, { encoding: "utf8" }] }
        }));
        const removeFile = (path, jobId) => startJob(createJob({
          id: jobId,
          action: "FS",
          payload: { method: "unlink", args: [path] }
        }));
        const FS = (method, args, jobId) => startJob(createJob({
          id: jobId,
          action: "FS",
          payload: { method, args }
        }));
        const loadLanguageInternal = (_langs, jobId) => startJob(createJob({
          id: jobId,
          action: "loadLanguage",
          payload: {
            langs: _langs,
            options: {
              langPath: options.langPath,
              dataPath: options.dataPath,
              cachePath: options.cachePath,
              cacheMethod: options.cacheMethod,
              gzip: options.gzip,
              lstmOnly: [OEM.DEFAULT, OEM.LSTM_ONLY].includes(currentOem) && !options.legacyLang
            }
          }
        }));
        const initializeInternal = (_langs, _oem, _config, jobId) => startJob(createJob({
          id: jobId,
          action: "initialize",
          payload: { langs: _langs, oem: _oem, config: _config }
        }));
        const reinitialize = (langs2 = "eng", oem2, config2, jobId) => {
          if (lstmOnlyCore && [OEM.TESSERACT_ONLY, OEM.TESSERACT_LSTM_COMBINED].includes(oem2)) throw Error("Legacy model requested but code missing.");
          const _oem = oem2 || currentOem;
          currentOem = _oem;
          const _config = config2 || currentConfig;
          currentConfig = _config;
          const langsArr = typeof langs2 === "string" ? langs2.split("+") : langs2;
          const _langs = langsArr.filter((x) => !currentLangs.includes(x));
          currentLangs.push(..._langs);
          if (_langs.length > 0) {
            return loadLanguageInternal(_langs, jobId).then(() => initializeInternal(langs2, _oem, _config, jobId));
          }
          return initializeInternal(langs2, _oem, _config, jobId);
        };
        const setParameters = (params = {}, jobId) => startJob(createJob({
          id: jobId,
          action: "setParameters",
          payload: { params }
        }));
        const recognize3 = async (image, opts = {}, output = {
          text: true
        }, jobId) => startJob(createJob({
          id: jobId,
          action: "recognize",
          payload: { image: await loadImage2(image), options: opts, output }
        }));
        const detect = async (image, jobId) => {
          if (lstmOnlyCore) throw Error("`worker.detect` requires Legacy model, which was not loaded.");
          return startJob(createJob({
            id: jobId,
            action: "detect",
            payload: { image: await loadImage2(image) }
          }));
        };
        const terminate = async () => {
          if (worker2 !== null) {
            terminateWorker2(worker2);
            worker2 = null;
          }
          return Promise.resolve();
        };
        onMessage(worker2, ({
          workerId,
          jobId,
          status: status2,
          action,
          data
        }) => {
          const promiseId = `${action}-${jobId}`;
          if (status2 === "resolve") {
            log(`[${workerId}]: Complete ${jobId}`);
            promises[promiseId].resolve({ jobId, data });
            delete promises[promiseId];
          } else if (status2 === "reject") {
            promises[promiseId].reject(data);
            delete promises[promiseId];
            if (action === "load") workerResReject(data);
            if (errorHandler) {
              errorHandler(data);
            } else {
              throw Error(data);
            }
          } else if (status2 === "progress") {
            logger({ ...data, userJobId: jobId });
          }
        });
        const resolveObj = {
          id,
          worker: worker2,
          load,
          writeText,
          readText,
          removeFile,
          FS,
          reinitialize,
          setParameters,
          recognize: recognize3,
          detect,
          terminate
        };
        loadInternal().then(() => loadLanguageInternal(langs)).then(() => initializeInternal(langs, oem, config)).then(() => workerResResolve(resolveObj)).catch(() => {
        });
        return workerRes;
      };
    }
  });

  // node_modules/tesseract.js/src/Tesseract.js
  var require_Tesseract = __commonJS({
    "node_modules/tesseract.js/src/Tesseract.js"(exports, module) {
      "use strict";
      var createWorker2 = require_createWorker();
      var recognize3 = async (image, langs, options) => {
        const worker2 = await createWorker2(langs, 1, options);
        return worker2.recognize(image).finally(async () => {
          await worker2.terminate();
        });
      };
      var detect = async (image, options) => {
        const worker2 = await createWorker2("osd", 0, options);
        return worker2.detect(image).finally(async () => {
          await worker2.terminate();
        });
      };
      module.exports = {
        recognize: recognize3,
        detect
      };
    }
  });

  // node_modules/tesseract.js/src/constants/languages.js
  var require_languages = __commonJS({
    "node_modules/tesseract.js/src/constants/languages.js"(exports, module) {
      "use strict";
      module.exports = {
        AFR: "afr",
        AMH: "amh",
        ARA: "ara",
        ASM: "asm",
        AZE: "aze",
        AZE_CYRL: "aze_cyrl",
        BEL: "bel",
        BEN: "ben",
        BOD: "bod",
        BOS: "bos",
        BUL: "bul",
        CAT: "cat",
        CEB: "ceb",
        CES: "ces",
        CHI_SIM: "chi_sim",
        CHI_TRA: "chi_tra",
        CHR: "chr",
        CYM: "cym",
        DAN: "dan",
        DEU: "deu",
        DZO: "dzo",
        ELL: "ell",
        ENG: "eng",
        ENM: "enm",
        EPO: "epo",
        EST: "est",
        EUS: "eus",
        FAS: "fas",
        FIN: "fin",
        FRA: "fra",
        FRK: "frk",
        FRM: "frm",
        GLE: "gle",
        GLG: "glg",
        GRC: "grc",
        GUJ: "guj",
        HAT: "hat",
        HEB: "heb",
        HIN: "hin",
        HRV: "hrv",
        HUN: "hun",
        IKU: "iku",
        IND: "ind",
        ISL: "isl",
        ITA: "ita",
        ITA_OLD: "ita_old",
        JAV: "jav",
        JPN: "jpn",
        KAN: "kan",
        KAT: "kat",
        KAT_OLD: "kat_old",
        KAZ: "kaz",
        KHM: "khm",
        KIR: "kir",
        KOR: "kor",
        KUR: "kur",
        LAO: "lao",
        LAT: "lat",
        LAV: "lav",
        LIT: "lit",
        MAL: "mal",
        MAR: "mar",
        MKD: "mkd",
        MLT: "mlt",
        MSA: "msa",
        MYA: "mya",
        NEP: "nep",
        NLD: "nld",
        NOR: "nor",
        ORI: "ori",
        PAN: "pan",
        POL: "pol",
        POR: "por",
        PUS: "pus",
        RON: "ron",
        RUS: "rus",
        SAN: "san",
        SIN: "sin",
        SLK: "slk",
        SLV: "slv",
        SPA: "spa",
        SPA_OLD: "spa_old",
        SQI: "sqi",
        SRP: "srp",
        SRP_LATN: "srp_latn",
        SWA: "swa",
        SWE: "swe",
        SYR: "syr",
        TAM: "tam",
        TEL: "tel",
        TGK: "tgk",
        TGL: "tgl",
        THA: "tha",
        TIR: "tir",
        TUR: "tur",
        UIG: "uig",
        UKR: "ukr",
        URD: "urd",
        UZB: "uzb",
        UZB_CYRL: "uzb_cyrl",
        VIE: "vie",
        YID: "yid"
      };
    }
  });

  // node_modules/tesseract.js/src/constants/PSM.js
  var require_PSM = __commonJS({
    "node_modules/tesseract.js/src/constants/PSM.js"(exports, module) {
      "use strict";
      module.exports = {
        OSD_ONLY: "0",
        AUTO_OSD: "1",
        AUTO_ONLY: "2",
        AUTO: "3",
        SINGLE_COLUMN: "4",
        SINGLE_BLOCK_VERT_TEXT: "5",
        SINGLE_BLOCK: "6",
        SINGLE_LINE: "7",
        SINGLE_WORD: "8",
        CIRCLE_WORD: "9",
        SINGLE_CHAR: "10",
        SPARSE_TEXT: "11",
        SPARSE_TEXT_OSD: "12",
        RAW_LINE: "13"
      };
    }
  });

  // node_modules/tesseract.js/src/index.js
  var require_src = __commonJS({
    "node_modules/tesseract.js/src/index.js"(exports, module) {
      "use strict";
      require_runtime();
      var createScheduler = require_createScheduler();
      var createWorker2 = require_createWorker();
      var Tesseract = require_Tesseract();
      var languages = require_languages();
      var OEM = require_OEM();
      var PSM2 = require_PSM();
      var { setLogging } = require_log();
      module.exports = {
        languages,
        OEM,
        PSM: PSM2,
        createScheduler,
        createWorker: createWorker2,
        setLogging,
        ...Tesseract
      };
    }
  });

  // src/observation-db.js
  var pending;
  function open() {
    if (!pending)
      pending = new Promise((resolve, reject) => {
        const req = indexedDB.open("captcha-observations", 1);
        req.onupgradeneeded = () => req.result.createObjectStore("records", { keyPath: "id" });
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    return pending;
  }
  async function loadObservations() {
    const db = await open();
    return new Promise((resolve, reject) => {
      const req = db.transaction("records").objectStore("records").getAll();
      req.onsuccess = () => resolve(
        req.result.sort((a, b) => a.createdAt.localeCompare(b.createdAt))
      );
      req.onerror = () => reject(req.error);
    });
  }
  async function saveObservation(record) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction("records", "readwrite");
      tx.objectStore("records").put(structuredClone(record));
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
  }

  // src/thresholds.js
  var THRESHOLDS = Object.freeze({ shapes: 85, color: 101, lines: 101 });
  var AUTO_TYPES = Object.freeze(["shapes", "color", "lines"]);

  // src/decision.js
  var CYRILLIC = "\u0410\u0411\u0412\u0413\u0414\u0415\u0401\u0416\u0417\u0418\u0419\u041A\u041B\u041C\u041D\u041E\u041F\u0420\u0421\u0422\u0423\u0424\u0425\u0426\u0427\u0428\u0429\u042A\u042B\u042C\u042D\u042E\u042F";
  var LATIN = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  function decide(candidates, {
    type,
    alphabet,
    min,
    max,
    shapeConfidence = 100,
    threshold = THRESHOLDS[type]
  }) {
    const valid2 = candidates.filter(
      (c) => c.text && Number.isFinite(c.confidence)
    );
    const groups = /* @__PURE__ */ new Map();
    for (const c of valid2) {
      const group = groups.get(c.text) || [];
      group.push(c);
      groups.set(c.text, group);
    }
    const admissible = (text) => !!alphabet && [...text].every((c) => alphabet.includes(c)) && text.length >= min && text.length <= max;
    const family = (c) => c.family || {
      original: "source",
      gray: "source",
      binary: "binary",
      "thin-lines": "binary",
      "tight-line": "tight",
      "tight-raw": "tight",
      "dark-line": "dark",
      "dark-raw": "dark",
      "large-components": "components",
      "large-components-color": "components",
      "symbols-tight": "tight",
      "symbols-tight-binary": "tight"
    }[c.variant] || c.variant;
    const ranked = [...groups].map(([text, list]) => {
      const byFamily = /* @__PURE__ */ new Map();
      for (const c of list) {
        const f = family(c);
        byFamily.set(f, Math.max(byFamily.get(f) ?? 0, c.confidence));
      }
      const scores = [...byFamily.values()].sort((a, b) => b - a);
      return {
        text,
        confidence: scores.slice(0, 2).reduce((a, b) => a + b, 0) / Math.min(2, scores.length),
        votes: byFamily.size,
        maxConfidence: scores[0],
        admissible: admissible(text)
      };
    }).sort(
      (a, b) => Number(b.admissible) - Number(a.admissible) || b.votes - a.votes || b.confidence - a.confidence
    );
    const best = ranked[0] || { text: "", confidence: 0, votes: 0 };
    let reason = "";
    if (!alphabet) reason = "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0430\u043B\u0444\u0430\u0432\u0438\u0442 \u0432 \u043F\u0440\u043E\u0444\u0438\u043B\u0435.";
    else if (!best.text) reason = "OCR \u043D\u0435 \u043D\u0430\u0448\u0451\u043B \u0441\u0438\u043C\u0432\u043E\u043B\u044B.";
    else if (threshold > 100)
      reason = "\u0410\u0432\u0442\u043E\u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u044D\u0442\u043E\u0433\u043E \u0442\u0438\u043F\u0430 \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u043E: \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0432\u044B\u044F\u0432\u0438\u043B\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u0443\u044E \u043D\u0430\u0434\u0451\u0436\u043D\u043E\u0441\u0442\u044C. \u041A\u0430\u043D\u0434\u0438\u0434\u0430\u0442 \u2014 \u0434\u043B\u044F \u0440\u0443\u0447\u043D\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438.";
    else if ([...best.text].some((c) => !alphabet.includes(c)))
      reason = "\u0415\u0441\u0442\u044C \u0441\u0438\u043C\u0432\u043E\u043B\u044B \u0432\u043D\u0435 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0433\u043E \u0430\u043B\u0444\u0430\u0432\u0438\u0442\u0430.";
    else if (best.text.length < min || best.text.length > max)
      reason = `\u0414\u043B\u0438\u043D\u0430 ${best.text.length} \u0432\u043D\u0435 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0430 ${min}\u2013${max}.`;
    else if (best.votes < 2)
      reason = "\u0412\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043D\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u044B \u043C\u0435\u0436\u0434\u0443 \u0441\u043E\u0431\u043E\u0439.";
    else if (ranked[1]?.admissible && ranked[1]?.votes >= best.votes)
      reason = "\u0415\u0441\u0442\u044C \u043A\u043E\u043D\u043A\u0443\u0440\u0438\u0440\u0443\u044E\u0449\u0438\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u0441 \u0440\u0430\u0432\u043D\u044B\u043C \u0447\u0438\u0441\u043B\u043E\u043C \u0433\u043E\u043B\u043E\u0441\u043E\u0432.";
    else if (ranked.slice(1).some(
      (r) => r.admissible && r.maxConfidence >= 85 && r.maxConfidence >= best.confidence - 10
    ))
      reason = "\u0415\u0441\u0442\u044C \u0441\u0438\u043B\u044C\u043D\u044B\u0439 \u043A\u043E\u043D\u043A\u0443\u0440\u0438\u0440\u0443\u044E\u0449\u0438\u0439 \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442; \u0443\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u044C \u043D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u0430.";
    else if (best.confidence < threshold)
      reason = "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u0430\u044F \u0443\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u044C OCR.";
    else if (shapeConfidence < 85)
      reason = "\u041D\u0435\u0443\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0431\u0443\u043A\u0432 \u0438 \u0444\u0438\u0433\u0443\u0440.";
    return {
      candidate: best.text,
      confidence: Math.round(best.confidence),
      accepted: !reason,
      reason: reason || "\u0412\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u044B; \u0430\u043B\u0444\u0430\u0432\u0438\u0442, \u0434\u043B\u0438\u043D\u0430 \u0438 \u0443\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u044B.",
      ranked
    };
  }
  function cleanOCR(text) {
    return String(text || "").replace(/\s/g, "");
  }

  // src/profile.js
  var DEFAULT_PROFILE = {
    container: "[data-captcha]",
    image: "[data-captcha-image]",
    instruction: "[data-captcha-instruction]",
    minSelector: "[data-captcha-min]",
    maxSelector: "[data-captcha-max]",
    input: "[data-captcha-answer]",
    type: "auto",
    alphabet: LATIN,
    crop: { top: 0, bottom: 0, left: 0, right: 0 },
    debug: true,
    mode: "auto",
    maxConsecutiveSkips: 3,
    skipLowConfidence: false,
    skipSelector: "[data-captcha-skip]",
    feedbackSelector: "",
    feedbackSuccess: "",
    feedbackFailure: ""
  };
  function inferType(instruction) {
    if (/треуголь|triangle/i.test(instruction)) return "shapes";
    if (/цветн|color|colour/i.test(instruction)) return "color";
    if (/наклон|пересека|slant|crossing/i.test(instruction)) return "lines";
    throw Error("\u0422\u0438\u043F \u043D\u0435 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0451\u043D \u043F\u043E \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0435\u0433\u043E \u0432\u0440\u0443\u0447\u043D\u0443\u044E.");
  }
  function inferAlphabet(instruction, configured) {
    if (/кирилл|cyrillic/i.test(instruction))
      return "\u0410\u0411\u0412\u0413\u0414\u0415\u0401\u0416\u0417\u0418\u0419\u041A\u041B\u041C\u041D\u041E\u041F\u0420\u0421\u0422\u0423\u0424\u0425\u0426\u0427\u0428\u0429\u042A\u042B\u042C\u042D\u042E\u042F";
    if (/только цифр|digits only/i.test(instruction)) return "0123456789";
    return configured;
  }

  // src/ocr.js
  var import_tesseract = __toESM(require_src(), 1);

  // src/image.js
  function canvas(width, height) {
    const c = document.createElement("canvas");
    c.width = width;
    c.height = height;
    return c;
  }
  async function loadImage(url) {
    const image = new Image();
    image.src = url;
    await image.decode();
    if (image.width * image.height > 12e6)
      throw Error("\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 (\u043C\u0430\u043A\u0441\u0438\u043C\u0443\u043C 12 \u041C\u043F).");
    const out = canvas(image.width, image.height);
    out.getContext("2d").drawImage(image, 0, 0);
    return out;
  }
  function crop(source, box, scale = 1) {
    const x = Math.max(0, Math.round(box.x)), y = Math.max(0, Math.round(box.y));
    const w = Math.min(source.width - x, Math.round(box.width));
    const h = Math.min(source.height - y, Math.round(box.height));
    if (w < 1 || h < 1) throw Error("\u041F\u0443\u0441\u0442\u0430\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F.");
    const out = canvas(Math.round(w * scale), Math.round(h * scale));
    const ctx = out.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, out.width, out.height);
    ctx.drawImage(source, x, y, w, h, 0, 0, out.width, out.height);
    return out;
  }
  function transform(source, mode) {
    const out = crop(source, {
      x: 0,
      y: 0,
      width: source.width,
      height: source.height
    });
    const ctx = out.getContext("2d", { willReadFrequently: true });
    const data = ctx.getImageData(0, 0, out.width, out.height);
    for (let i = 0; i < data.data.length; i += 4) {
      const r = data.data[i], g = data.data[i + 1], b = data.data[i + 2];
      const gray = 0.299 * r + 0.587 * g + 0.114 * b;
      let value = gray;
      if (mode === "contrast")
        value = Math.max(0, Math.min(255, (gray - 170) * 2.6 + 170));
      if (mode === "binary" || mode === "thin-lines")
        value = gray < 155 ? 0 : 255;
      if (mode === "color")
        value = Math.max(r, g, b) - Math.min(r, g, b) > 55 && gray < 230 ? 0 : 255;
      data.data[i] = data.data[i + 1] = data.data[i + 2] = value;
    }
    if (mode === "thin-lines") {
      const original = data.data.slice();
      for (let y = 1; y < out.height - 1; y++) {
        let start2 = -1;
        for (let x = 0; x <= out.width; x++) {
          const dark = x < out.width && original[(y * out.width + x) * 4] === 0;
          if (dark && start2 < 0) start2 = x;
          if (!dark && start2 >= 0) {
            if (x - start2 > out.width * 0.45)
              for (let k = start2; k < x; k++) {
                const up = original[((y - 1) * out.width + k) * 4], down = original[((y + 1) * out.width + k) * 4];
                if (up === 255 || down === 255) {
                  const i = (y * out.width + k) * 4;
                  data.data[i] = data.data[i + 1] = data.data[i + 2] = 255;
                }
              }
            start2 = -1;
          }
        }
      }
    }
    ctx.putImageData(data, 0, 0);
    return out;
  }
  function hull(points) {
    points.sort((a, b) => a.x - b.x || a.y - b.y);
    const cross = (a, b, c) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    const lower = [], upper = [];
    for (const p of points) {
      while (lower.length > 1 && cross(lower.at(-2), lower.at(-1), p) <= 0)
        lower.pop();
      lower.push(p);
    }
    for (const p of points.toReversed()) {
      while (upper.length > 1 && cross(upper.at(-2), upper.at(-1), p) <= 0)
        upper.pop();
      upper.push(p);
    }
    return lower.slice(0, -1).concat(upper.slice(0, -1));
  }
  function simplifyPolygon(points, tolerance) {
    const p = points.slice();
    let changed = true;
    while (changed && p.length > 3) {
      changed = false;
      for (let i = 0; i < p.length; i++) {
        const a = p[(i + p.length - 1) % p.length], b = p[i], c = p[(i + 1) % p.length];
        const distance = Math.abs(
          (c.y - a.y) * b.x - (c.x - a.x) * b.y + c.x * a.y - c.y * a.x
        ) / (Math.hypot(c.x - a.x, c.y - a.y) || 1);
        if (distance < tolerance) {
          p.splice(i, 1);
          changed = true;
          break;
        }
      }
    }
    return p;
  }
  function findShapes(source) {
    const { width: w, height: h } = source;
    const pixels = source.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, w, h).data;
    const mask = new Uint8Array(w * h), seen2 = new Uint8Array(w * h);
    for (let y = Math.floor(h * 0.5); y < h; y++)
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4, r = pixels[i], g = pixels[i + 1], b = pixels[i + 2];
        mask[y * w + x] = Math.max(r, g, b) - Math.min(r, g, b) > 35 && Math.min(r, g, b) < 215 ? 1 : 0;
      }
    const shapes = [];
    for (let i = 0; i < mask.length; i++) {
      if (!mask[i] || seen2[i]) continue;
      const queue = [i], boundary = [];
      seen2[i] = 1;
      let x0 = w, y0 = h, x1 = 0, y1 = 0;
      for (let q = 0; q < queue.length; q++) {
        const pos = queue[q], x = pos % w, y = Math.floor(pos / w);
        x0 = Math.min(x0, x);
        x1 = Math.max(x1, x);
        y0 = Math.min(y0, y);
        y1 = Math.max(y1, y);
        let edge = false;
        for (const [dx, dy] of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1]
        ]) {
          const nx = x + dx, ny = y + dy, n = ny * w + nx;
          if (nx < 0 || nx >= w || ny < 0 || ny >= h || !mask[n]) {
            edge = true;
            continue;
          }
          if (!seen2[n]) {
            seen2[n] = 1;
            queue.push(n);
          }
        }
        if (edge) boundary.push({ x, y });
      }
      if (queue.length < 30 || x1 - x0 < 7 || y1 - y0 < 7) continue;
      const contour = simplifyPolygon(
        hull(boundary),
        Math.max(x1 - x0, y1 - y0) * 0.065
      );
      const area = (x1 - x0 + 1) * (y1 - y0 + 1), fill = queue.length / area;
      const triangle = contour.length === 3 && fill > 0.3 && fill < 0.7;
      shapes.push({
        x: x0,
        y: y0,
        width: x1 - x0 + 1,
        height: y1 - y0 + 1,
        center: (x0 + x1) / 2,
        triangle,
        contour,
        fill
      });
    }
    return shapes.sort((a, b) => a.center - b.center);
  }
  function shapeColumns(shapes, width) {
    return shapes.map((s, i) => ({
      ...s,
      left: i ? (shapes[i - 1].center + s.center) / 2 : 0,
      right: i < shapes.length - 1 ? (s.center + shapes[i + 1].center) / 2 : width
    }));
  }
  function overlayShapes(source, shapes) {
    const out = crop(source, {
      x: 0,
      y: 0,
      width: source.width,
      height: source.height
    });
    const ctx = out.getContext("2d");
    ctx.lineWidth = 2;
    for (const s of shapes) {
      ctx.strokeStyle = s.triangle ? "#d02b63" : "#177565";
      ctx.beginPath();
      s.contour.forEach(
        (p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)
      );
      ctx.closePath();
      ctx.stroke();
      ctx.strokeStyle = "#697c8a";
      ctx.beginPath();
      ctx.moveTo(s.left, 0);
      ctx.lineTo(s.left, out.height);
      ctx.stroke();
    }
    return out;
  }
  function largeColorComponents(source, binary = true) {
    const { width: w, height: h } = source, ctx = source.getContext("2d", { willReadFrequently: true }), data = ctx.getImageData(0, 0, w, h).data;
    const labels = new Int32Array(w * h);
    labels.fill(-1);
    const seen2 = new Uint8Array(w * h), keep = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) {
      const p = i * 4, r = data[p], g = data[p + 1], b = data[p + 2];
      if (Math.min(r, g, b) < 210)
        labels[i] = Math.floor(r / 40) * 49 + Math.floor(g / 40) * 7 + Math.floor(b / 40);
    }
    for (let i = 0; i < labels.length; i++) {
      if (labels[i] < 0 || seen2[i]) continue;
      const queue = [i];
      seen2[i] = 1;
      let y0 = h, y1 = 0;
      for (let q = 0; q < queue.length; q++) {
        const pos = queue[q], x = pos % w, y = Math.floor(pos / w);
        y0 = Math.min(y0, y);
        y1 = Math.max(y1, y);
        for (const [dx, dy] of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
          [1, 1],
          [-1, 1],
          [1, -1],
          [-1, -1]
        ]) {
          const nx = x + dx, ny = y + dy, n = ny * w + nx;
          if (nx >= 0 && nx < w && ny >= 0 && ny < h && !seen2[n] && labels[n] === labels[i]) {
            seen2[n] = 1;
            queue.push(n);
          }
        }
      }
      if (y1 - y0 > h * 0.34 && queue.length > w * h * 15e-4)
        for (const p of queue) keep[p] = 1;
    }
    const out = canvas(w, h), octx = out.getContext("2d"), outData = octx.createImageData(w, h);
    for (let i = 0; i < w * h; i++) {
      const p = i * 4;
      for (let k = 0; k < 3; k++)
        outData.data[p + k] = keep[i] ? binary ? 0 : data[p + k] : 255;
      outData.data[p + 3] = 255;
    }
    octx.putImageData(outData, 0, 0);
    return out;
  }
  function normalizeInk(source, threshold = 180, targetHeight = 96) {
    const { width: w, height: h } = source, p = source.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, w, h).data;
    let x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        if (0.299 * p[i] + 0.587 * p[i + 1] + 0.114 * p[i + 2] < threshold) {
          x0 = Math.min(x0, x);
          x1 = Math.max(x1, x);
          y0 = Math.min(y0, y);
          y1 = Math.max(y1, y);
        }
      }
    if (x1 < x0) return crop(source, { x: 0, y: 0, width: w, height: h });
    const scale = targetHeight / (y1 - y0 + 1), padding = 16, out = canvas(
      Math.ceil((x1 - x0 + 1) * scale) + padding * 2,
      targetHeight + padding * 2
    ), ctx = out.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, out.width, out.height);
    ctx.drawImage(
      source,
      x0,
      y0,
      x1 - x0 + 1,
      y1 - y0 + 1,
      padding,
      padding,
      (x1 - x0 + 1) * scale,
      targetHeight
    );
    return out;
  }
  function darkInk(source, threshold = 110) {
    const out = crop(source, {
      x: 0,
      y: 0,
      width: source.width,
      height: source.height
    }), ctx = out.getContext("2d"), d = ctx.getImageData(0, 0, out.width, out.height);
    for (let i = 0; i < d.data.length; i += 4) {
      const v = 0.299 * d.data[i] + 0.587 * d.data[i + 1] + 0.114 * d.data[i + 2] < threshold ? 0 : 255;
      d.data[i] = d.data[i + 1] = d.data[i + 2] = v;
    }
    ctx.putImageData(d, 0, 0);
    return out;
  }

  // src/ocr.js
  var pendingWorker;
  var currentLanguage = "rus+eng";
  function getWorker(progress = () => {
  }) {
    if (!pendingWorker)
      pendingWorker = (0, import_tesseract.createWorker)("rus+eng", 1, {
        workerPath: chrome.runtime.getURL("vendor/worker.min.js"),
        corePath: chrome.runtime.getURL("vendor/core"),
        langPath: chrome.runtime.getURL("vendor/lang"),
        workerBlobURL: false,
        gzip: true,
        cacheMethod: "none",
        logger: progress
      }).catch((error) => {
        pendingWorker = null;
        throw error;
      });
    return pendingWorker;
  }
  function terminateWorker() {
    const old = pendingWorker;
    pendingWorker = null;
    currentLanguage = "rus+eng";
    if (old) old.then((w) => w.terminate()).catch(() => {
    });
  }
  async function read(worker2, image, mode, alphabet, blocks = true) {
    await worker2.setParameters({
      tessedit_pageseg_mode: mode,
      tessedit_char_whitelist: alphabet,
      preserve_interword_spaces: "0"
    });
    const { data } = await worker2.recognize(
      image.toDataURL(),
      {},
      { text: true, blocks }
    );
    return {
      text: cleanOCR(data.text),
      confidence: data.confidence,
      charConfidence: (() => {
        const chars = symbols(data.blocks).filter((c) => cleanOCR(c.text));
        return chars.length && chars.map((c) => cleanOCR(c.text)).join("") === cleanOCR(data.text) ? Math.min(...chars.map((c) => c.confidence)) : void 0;
      })(),
      blocks: data.blocks
    };
  }
  function symbols(blocks) {
    return (blocks || []).flatMap(
      (b) => (b.paragraphs || []).flatMap(
        (p) => (p.lines || []).flatMap(
          (l) => (l.words || []).flatMap((w) => w.symbols || [])
        )
      )
    );
  }
  async function recognize(task, { progress = () => {
  }, engines = {}, stage = "final", signal } = {}) {
    if (engines[task.type]) {
      const evidence = await engines[task.type](task, { progress });
      return {
        ...evidence,
        ...decide(evidence.candidates || [], {
          ...task,
          alphabet: task.type === "shapes" ? CYRILLIC : task.alphabet,
          shapeConfidence: evidence.shapeConfidence ?? 100
        })
      };
    }
    signal?.throwIfAborted();
    const worker2 = await getWorker(progress), source = await loadImage(task.image);
    const effectiveAlphabet = task.type === "shapes" ? CYRILLIC : task.alphabet;
    const hasCyrillic = /[А-ЯЁа-яё]/.test(effectiveAlphabet || "");
    const language = hasCyrillic ? /[A-Za-z]/.test(effectiveAlphabet) ? "rus+eng" : "rus" : "eng";
    if (currentLanguage !== language) {
      await worker2.reinitialize(language, 1);
      currentLanguage = language;
    }
    const debug = [], candidates = [];
    const add = (name, c) => debug.push({ name, image: c.toDataURL() });
    let shapeConfidence = 100, shapeInfo = [];
    const alphabet = task.type === "shapes" ? CYRILLIC : task.alphabet;
    if (!alphabet)
      return { ...decide([], { ...task, alphabet }), candidates, debug };
    if (task.type === "shapes") {
      signal?.throwIfAborted();
      const shapes = shapeColumns(findShapes(source), source.width);
      shapeInfo = shapes;
      add("\u041A\u043E\u043D\u0442\u0443\u0440\u044B \u0438 \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0441\u0442\u043E\u043B\u0431\u0446\u043E\u0432", overlayShapes(source, shapes));
      const selected = shapes.filter((s) => s.triangle);
      if (!selected.length || shapes.length < 2)
        return {
          candidate: "",
          confidence: 0,
          accepted: false,
          reason: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0443\u0432\u0435\u0440\u0435\u043D\u043D\u043E \u043D\u0430\u0439\u0442\u0438 \u0442\u0440\u0435\u0443\u0433\u043E\u043B\u044C\u043D\u0438\u043A\u0438.",
          candidates,
          debug,
          shapes
        };
      shapeConfidence = shapes.some(
        (s) => s.width < 8 || s.height < 8 || s.y < source.height * 0.52
      ) ? 65 : 95;
      const top = Math.max(1, Math.min(...shapes.map((s) => s.y)) - 3);
      const strip = crop(
        source,
        { x: 0, y: 0, width: source.width, height: top },
        4
      );
      add("\u0412\u0435\u0440\u0445\u043D\u044F\u044F \u0441\u0442\u0440\u043E\u043A\u0430 \u0431\u0443\u043A\u0432", strip);
      const full = await read(worker2, strip, import_tesseract.PSM.SINGLE_LINE, alphabet, true);
      const lineSymbols = symbols(full.blocks).filter((s) => cleanOCR(s.text));
      const byLine = [];
      for (const s of selected) {
        const found = lineSymbols.filter((c) => {
          const x = (c.bbox.x0 + c.bbox.x1) / 8;
          return x >= s.left && x < s.right;
        });
        if (found.length === 1) byLine.push(found[0]);
      }
      const original = [], binary = [], tight = [], tightBinary = [];
      for (const [index, s] of selected.entries()) {
        signal?.throwIfAborted();
        const letter = crop(
          source,
          { x: s.left, y: 0, width: s.right - s.left, height: top },
          4
        );
        const bin = transform(letter, "binary");
        add(`\u0422\u0440\u0435\u0443\u0433\u043E\u043B\u044C\u043D\u0438\u043A ${index + 1}: \u0441\u0438\u043C\u0432\u043E\u043B`, letter);
        add(`\u0422\u0440\u0435\u0443\u0433\u043E\u043B\u044C\u043D\u0438\u043A ${index + 1}: \u0431\u0438\u043D\u0430\u0440\u0438\u0437\u0430\u0446\u0438\u044F`, bin);
        original.push(await read(worker2, letter, import_tesseract.PSM.SINGLE_CHAR, alphabet));
        binary.push(await read(worker2, bin, import_tesseract.PSM.SINGLE_CHAR, alphabet));
        const normalized = normalizeInk(letter), normalizedBinary = transform(normalized, "binary");
        add(`\u0422\u0440\u0435\u0443\u0433\u043E\u043B\u044C\u043D\u0438\u043A ${index + 1}: \u043F\u043B\u043E\u0442\u043D\u0430\u044F \u043E\u0431\u0440\u0435\u0437\u043A\u0430 + \u043F\u043E\u043B\u044F`, normalized);
        add(`\u0422\u0440\u0435\u0443\u0433\u043E\u043B\u044C\u043D\u0438\u043A ${index + 1}: \u043F\u043B\u043E\u0442\u043D\u0430\u044F \u0431\u0438\u043D\u0430\u0440\u0438\u0437\u0430\u0446\u0438\u044F`, normalizedBinary);
        tight.push(await read(worker2, normalized, import_tesseract.PSM.SINGLE_CHAR, alphabet));
        tightBinary.push(
          await read(worker2, normalizedBinary, import_tesseract.PSM.RAW_LINE, alphabet)
        );
      }
      for (const [variant, list] of [
        ["symbols-original", original],
        ["symbols-binary", binary],
        ["symbols-tight", tight],
        ["symbols-tight-binary", tightBinary]
      ]) {
        candidates.push({
          variant,
          text: list.map((c) => c.text).join(""),
          confidence: Math.min(...list.map((c) => c.confidence)),
          charConfidence: Math.min(
            ...list.map((c) => c.charConfidence ?? c.confidence)
          )
        });
      }
      if (byLine.length === selected.length)
        candidates.push({
          variant: "line-coordinates",
          text: byLine.map((c) => cleanOCR(c.text)).join(""),
          confidence: Math.min(...byLine.map((c) => c.confidence))
        });
      debug.push({
        name: "OCR \u0432\u0441\u0435\u0439 \u0441\u0442\u0440\u043E\u043A\u0438 (\u043D\u0435 \u0433\u043E\u043B\u043E\u0441\u0443\u0435\u0442 \u0431\u0435\u0437 \u043A\u043E\u043E\u0440\u0434\u0438\u043D\u0430\u0442)",
        text: full.text,
        confidence: full.confidence,
        symbolCount: lineSymbols.length
      });
    } else {
      const bounds = task.crop || { top: 0, bottom: 0, left: 0, right: 0 };
      for (const value of Object.values(bounds))
        if (!Number.isFinite(value) || value < 0 || value >= 1)
          throw Error("\u041E\u0431\u0440\u0435\u0437\u043A\u0430 \u0437\u0430\u0434\u0430\u0451\u0442\u0441\u044F \u0434\u043E\u043B\u044F\u043C\u0438 \u043E\u0442 0 \u0434\u043E 1.");
      const area = crop(
        source,
        {
          x: source.width * (bounds.left || 0),
          y: source.height * (bounds.top || 0),
          width: source.width * (1 - (bounds.left || 0) - (bounds.right || 0)),
          height: source.height * (1 - (bounds.top || 0) - (bounds.bottom || 0))
        },
        3
      );
      add("\u041E\u0431\u043B\u0430\u0441\u0442\u044C \u0437\u0430\u0434\u0430\u043D\u0438\u044F \xD73", area);
      const modes = task.type === "color" ? [
        "original",
        "contrast",
        "color",
        "large-components",
        "large-components-color"
      ] : ["original", "gray", "binary", "thin-lines"];
      for (const variant of modes) {
        const image = variant === "original" ? area : variant.startsWith("large-components") ? largeColorComponents(area, variant === "large-components") : transform(area, variant);
        add(variant, image);
        candidates.push({
          variant,
          ...await read(worker2, image, import_tesseract.PSM.SINGLE_LINE, alphabet)
        });
      }
      const normalized = normalizeInk(
        area,
        task.type === "lines" ? 100 : 200,
        96
      );
      add("\u041F\u043B\u043E\u0442\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430 \u0441 \u0431\u0435\u043B\u044B\u043C\u0438 \u043F\u043E\u043B\u044F\u043C\u0438", normalized);
      candidates.push({
        variant: "tight-line",
        ...await read(worker2, normalized, import_tesseract.PSM.SINGLE_LINE, alphabet)
      });
      candidates.push({
        variant: "tight-raw",
        ...await read(worker2, normalized, import_tesseract.PSM.RAW_LINE, alphabet)
      });
      if (stage !== "crop" && task.type === "lines") {
        const denoised = normalizeInk(darkInk(area, 110), 100, 96);
        add("\u0422\u0451\u043C\u043D\u044B\u0435 \u0448\u0442\u0440\u0438\u0445\u0438; \u0441\u043B\u0430\u0431\u044B\u0435 \u043B\u0438\u043D\u0438\u0438 \u043F\u043E\u0434\u0430\u0432\u043B\u0435\u043D\u044B", denoised);
        candidates.push({
          variant: "dark-line",
          ...await read(worker2, denoised, import_tesseract.PSM.SINGLE_LINE, alphabet)
        });
        candidates.push({
          variant: "dark-raw",
          ...await read(worker2, denoised, import_tesseract.PSM.RAW_LINE, alphabet)
        });
      }
      if (task.type === "lines") {
        const image = transform(area, "binary"), ctx = image.getContext("2d"), data = ctx.getImageData(0, 0, image.width, image.height).data;
        const runs = [];
        let start2 = -1;
        for (let x = 0; x <= image.width; x++) {
          let count = 0;
          if (x < image.width) {
            for (let y = 0; y < image.height; y++)
              if (data[(y * image.width + x) * 4] === 0) count++;
          }
          if (count > 1 && start2 < 0) start2 = x;
          if (count <= 1 && start2 >= 0) {
            if (x - start2 > 4) runs.push({ start: start2, end: x });
            start2 = -1;
          }
        }
        if (runs.length >= task.min && runs.length <= task.max && runs.every((r) => r.end - r.start > 10)) {
          const chars = [];
          for (const r of runs)
            chars.push(
              await read(
                worker2,
                crop(image, {
                  x: Math.max(0, r.start - 3),
                  y: 0,
                  width: Math.min(image.width - r.start, r.end - r.start + 6),
                  height: image.height
                }),
                import_tesseract.PSM.SINGLE_CHAR,
                alphabet
              )
            );
          candidates.push({
            variant: "stable-components",
            text: chars.map((c) => c.text).join(""),
            confidence: Math.min(...chars.map((c) => c.confidence))
          });
        }
      }
    }
    if (stage === "symbols" || stage === "final")
      for (const c of candidates) {
        c.wordConfidence = c.confidence;
        if (Number.isFinite(c.charConfidence)) c.confidence = c.charConfidence;
      }
    signal?.throwIfAborted();
    return {
      ...decide(candidates, { ...task, alphabet, shapeConfidence }),
      candidates,
      debug,
      shapes: shapeInfo,
      shapeConfidence
    };
  }

  // src/model-client.js
  var worker;
  var seq = 0;
  var requests = /* @__PURE__ */ new Map();
  function get() {
    if (!worker) {
      worker = new Worker(chrome.runtime.getURL("models-worker.js"), {
        type: "module"
      });
      worker.onmessage = ({ data }) => {
        const r = requests.get(data.id);
        if (!r) return;
        requests.delete(data.id);
        data.error ? r.reject(Error(data.error)) : r.resolve(data.result);
      };
      worker.onerror = (e) => {
        for (const r of requests.values()) r.reject(Error(e.message));
        requests.clear();
      };
    }
    return worker;
  }
  function modelRecognize(name, image, alphabet, signal) {
    return new Promise((resolve, reject) => {
      if (signal?.aborted) return reject(signal.reason);
      const id = ++seq;
      requests.set(id, { resolve, reject });
      signal?.addEventListener(
        "abort",
        () => {
          requests.delete(id);
          reject(signal.reason);
        },
        { once: true }
      );
      get().postMessage({ id, name, image, alphabet });
    });
  }
  function terminateModels() {
    worker?.terminate();
    worker = null;
    for (const r of requests.values())
      r.reject(new DOMException("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E", "AbortError"));
    requests.clear();
  }

  // src/color-decision.js
  var COLOR_THRESHOLD = 94;
  function decideColor(task, candidates, threshold = COLOR_THRESHOLD) {
    const valid2 = (text) => text.length >= task.min && text.length <= task.max && [...text].every((c) => task.alphabet.includes(c));
    const groups = /* @__PURE__ */ new Map();
    for (const c of candidates) {
      if (!groups.has(c.text)) groups.set(c.text, []);
      groups.get(c.text).push(c);
    }
    const ranked = [...groups].map(([text, entries]) => {
      const views = /* @__PURE__ */ new Map();
      for (const c of entries.filter((c2) => /^helper-(original|contrast|gray)$/.test(c2.variant)))
        views.set(c.variant, c);
      const helper = [...views.values()].sort((a, b) => b.confidence - a.confidence);
      const viewScore = helper.length >= 2 ? helper[1].confidence : 0;
      const original = views.get("helper-original");
      const easy = entries.find((c) => c.variant === "easyocr-fallback");
      const crossScore = original && easy?.confidence >= 98 ? original.confidence : 0;
      const confidence = Math.max(viewScore, crossScore);
      return {
        text,
        confidence,
        votes: entries.length,
        viewScore,
        crossScore,
        evidence: crossScore > viewScore ? "original+EasyOCR" : "two-Helper-views"
      };
    }).sort((a, b) => Number(valid2(b.text)) - Number(valid2(a.text)) || b.confidence - a.confidence || b.votes - a.votes);
    const best = ranked[0] || { text: "", confidence: 0, votes: 0 };
    const competitor = candidates.find((c) => c.text !== best.text && valid2(c.text) && c.confidence >= 95);
    const accepted = valid2(best.text) && best.confidence >= threshold && !competitor;
    const reason = !valid2(best.text) ? "\u0426\u0432\u0435\u0442\u043D\u0430\u044F: \u043D\u0435\u0442 \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u0430 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u043E\u0439 \u0434\u043B\u0438\u043D\u044B \u0438 \u0430\u043B\u0444\u0430\u0432\u0438\u0442\u0430." : competitor ? `\u0426\u0432\u0435\u0442\u043D\u0430\u044F: \u0441\u0438\u043B\u044C\u043D\u044B\u0439 \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442 ${competitor.text} (${competitor.confidence.toFixed(2)}); \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0443\u0447\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430.` : best.confidence < threshold ? `\u0426\u0432\u0435\u0442\u043D\u0430\u044F: \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 ${best.confidence.toFixed(2)} \u043D\u0438\u0436\u0435 ${threshold}; \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0440\u0443\u0447\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430.` : `\u0426\u0432\u0435\u0442\u043D\u0430\u044F: ${best.evidence}, \u043E\u0446\u0435\u043D\u043A\u0430 ${best.confidence.toFixed(2)} \u2265 ${threshold}, \u0441\u0438\u043B\u044C\u043D\u044B\u0445 \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u043E\u0432 \u043D\u0435\u0442.`;
    return {
      candidate: best.text,
      confidence: best.confidence,
      accepted,
      reason,
      ranked,
      colorPolicy: { threshold, competitor: competitor?.text || null, evidence: best.evidence }
    };
  }

  // src/pipeline.js
  function terminateAll() {
    terminateWorker();
    terminateModels();
  }
  function valid(text, task) {
    return !!text && text.length >= task.min && text.length <= task.max && [...text].every((c) => task.alphabet.includes(c));
  }
  function resultFor(task, list, base = {}) {
    const grouped = /* @__PURE__ */ new Map();
    for (const c of list) {
      if (!grouped.has(c.text)) grouped.set(c.text, []);
      grouped.get(c.text).push(c);
    }
    const ranked = [...grouped].map(([text, c]) => ({
      text,
      confidence: Math.min(...c.map((v) => v.confidence)),
      votes: c.length
    })).sort(
      (a, b) => Number(valid(b.text, task)) - Number(valid(a.text, task)) || b.votes - a.votes || b.confidence - a.confidence
    );
    const best = ranked[0] || { text: "", confidence: 0, votes: 0 };
    const threshold = task.type === "shapes" ? 97 : 98;
    const accepted = valid(best.text, task) && best.confidence >= threshold && best.votes >= 2 && !ranked.some(
      (r) => r.text !== best.text && valid(r.text, task) && r.confidence >= 95
    );
    return {
      ...base,
      candidate: best.text,
      confidence: best.confidence,
      accepted,
      reason: accepted ? "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043C\u043E\u0434\u0435\u043B\u0438 \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u044B; \u0430\u043B\u0444\u0430\u0432\u0438\u0442, \u0434\u043B\u0438\u043D\u0430 \u0438 \u043F\u043E\u0440\u043E\u0433 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u044B." : "\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043C\u043E\u0434\u0435\u043B\u0438: \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0443\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0433\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u044F.",
      ranked,
      candidates: [
        ...(base.candidates || []).filter(
          (c) => !list.some((l) => l.engine === c.engine && l.variant === c.variant)
        ),
        ...list
      ],
      debug: base.debug || [],
      modelPath: true
    };
  }
  async function recognize2(task, options = {}) {
    const { signal, progress = () => {
    } } = options, deadline = options.deadline || Date.now() + 28e3;
    signal?.throwIfAborted();
    const alphabet = task.type === "shapes" ? CYRILLIC : task.alphabet;
    task = { ...task, alphabet };
    if (task.type === "shapes") {
      const base = await recognize(task, options);
      if (base.accepted || deadline - Date.now() < 1700)
        return { ...base, path: "v2" };
      const source2 = await loadImage(task.image), shapes = shapeColumns(findShapes(source2), source2.width), selected = shapes.filter((s) => s.triangle);
      if (!selected.length) return base;
      const top = Math.min(...shapes.map((s) => s.y)) - 3, list2 = [];
      for (const variant of ["original", "binary"]) {
        let text = "", confidence = 100;
        for (const s of selected) {
          signal?.throwIfAborted();
          if (Date.now() >= deadline) throw Error("\u0411\u044E\u0434\u0436\u0435\u0442 \u043C\u043E\u0434\u0435\u043B\u0438 \u0438\u0441\u0442\u0451\u043A.");
          let image = crop(source2, {
            x: s.left,
            y: 0,
            width: s.right - s.left,
            height: top
          });
          if (variant === "binary") image = transform(image, "binary");
          const r = await modelRecognize(
            "easyocr-cyrillic",
            image.toDataURL(),
            alphabet,
            signal
          );
          text += r.text;
          confidence = Math.min(confidence, r.confidence);
        }
        list2.push({
          text,
          confidence,
          variant: "easyocr-" + variant,
          engine: "EasyOCR"
        });
      }
      const result2 = resultFor(task, list2, base);
      return result2.accepted ? { ...result2, path: "v2\u2192EasyOCR" } : {
        ...base,
        alternativesModels: list2,
        candidates: [...base.candidates, ...list2],
        path: "v2\u2192EasyOCR refused"
      };
    }
    const source = await loadImage(task.image), b = task.crop || {}, area = crop(source, {
      x: source.width * (b.left || 0),
      y: source.height * (b.top || 0),
      width: source.width * (1 - (b.left || 0) - (b.right || 0)),
      height: source.height * (1 - (b.top || 0) - (b.bottom || 0))
    });
    const isCyrillic = /[А-Яа-яЁё]/.test(alphabet), name = isCyrillic ? "easyocr-cyrillic" : "helper", list = [];
    for (const variant of ["original", "contrast"]) {
      signal?.throwIfAborted();
      const image = variant === "original" ? area : transform(area, "contrast");
      const r = await modelRecognize(name, image.toDataURL(), alphabet, signal);
      list.push({ ...r, variant: name + "-" + variant });
    }
    let result = resultFor(task, list, {
      debug: [{ name: "\u0412\u0445\u043E\u0434 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0439 \u043C\u043E\u0434\u0435\u043B\u0438", image: area.toDataURL() }]
    });
    if (result.accepted) return { ...result, path: name };
    if (deadline - Date.now() > 2e3) {
      const alternate = name === "helper" ? "easyocr-cyrillic" : null;
      if (alternate) {
        const r = await modelRecognize(
          alternate,
          area.toDataURL(),
          alphabet,
          signal
        );
        list.push({ ...r, variant: "easyocr-fallback" });
        result = resultFor(task, list, result);
      }
    }
    if (task.type === "color" && name === "helper") {
      if (deadline - Date.now() > 800) {
        signal?.throwIfAborted();
        const gray = transform(area, "gray");
        const r = await modelRecognize("helper", gray.toDataURL(), alphabet, signal);
        list.push({ ...r, variant: "helper-gray" });
        result.debug.push({ name: "\u0426\u0432\u0435\u0442\u043D\u0430\u044F: \u0441\u0435\u0440\u044B\u0439 \u0431\u0435\u0437 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0448\u0442\u0440\u0438\u0445\u043E\u0432", image: gray.toDataURL() });
      }
      return { ...result, ...decideColor(task, list), candidates: list, path: "helper\u2192color-v4" };
    }
    return { ...result, path: name + "\u2192fallback" };
  }

  // src/budget.js
  var BudgetExpired = class extends Error {
    constructor() {
      super("\u0418\u0441\u0442\u0451\u043A \u0431\u044E\u0434\u0436\u0435\u0442 OCR (28 \u0441\u0435\u043A\u0443\u043D\u0434).");
      this.name = "BudgetExpired";
    }
  };
  function untilDeadline(promise, deadline, signal) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(
        () => finish(reject, new BudgetExpired()),
        Math.max(0, deadline - Date.now())
      );
      const abort = () => finish(
        reject,
        signal.reason || new DOMException("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E", "AbortError")
      );
      let settled = false;
      function finish(fn, value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        signal?.removeEventListener("abort", abort);
        fn(value);
      }
      if (signal?.aborted) return abort();
      signal?.addEventListener("abort", abort, { once: true });
      Promise.resolve(promise).then(
        (v) => finish(resolve, v),
        (e) => finish(reject, e)
      );
    });
  }

  // src/observations.js
  function parseCSV(text) {
    const rows = [];
    let row = [], field = "", quoted = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (c === '"') {
        if (quoted && text[i + 1] === '"') {
          field += '"';
          i++;
        } else quoted = !quoted;
      } else if (c === "," && !quoted) {
        row.push(field);
        field = "";
      } else if ((c === "\n" || c === "\r") && !quoted) {
        if (c === "\r" && text[i + 1] === "\n") i++;
        row.push(field);
        if (row.some(Boolean)) rows.push(row);
        row = [];
        field = "";
      } else field += c;
    }
    if (quoted) throw Error("\u041D\u0435\u0437\u0430\u043A\u0440\u044B\u0442\u0430\u044F \u043A\u0430\u0432\u044B\u0447\u043A\u0430 CSV.");
    if (field || row.length) {
      row.push(field);
      rows.push(row);
    }
    if (!rows.length) return [];
    const header = rows.shift().map((x) => x.replace(/^\uFEFF/, "").trim());
    return rows.map(
      (r) => Object.fromEntries(header.map((k, i) => [k, r[i] ?? ""]))
    );
  }
  function observationRecord({
    taskId,
    type,
    image,
    source = "unverified",
    result,
    startedAt,
    task,
    instruction,
    origin: origin2
  }) {
    return {
      id: crypto.randomUUID(),
      taskId,
      type,
      source,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      startedAt,
      task: task ? {
        type: task.type,
        alphabet: task.alphabet,
        min: task.min,
        max: task.max,
        crop: task.crop
      } : void 0,
      instruction,
      origin: origin2,
      candidate: result.candidate,
      confidence: result.confidence,
      alternatives: result.ranked || [],
      candidates: (result.candidates || []).map(
        ({ text, confidence, variant, engine, symbols: symbols2 }) => ({
          text,
          confidence,
          variant,
          engine,
          symbols: symbols2
        })
      ),
      wouldFill: result.accepted,
      reason: result.reason,
      answer: null,
      labelVerified: false,
      image
    };
  }

  // src/controller.js
  var $ = (id) => document.getElementById(id);
  var tabId = Number(new URLSearchParams(location.search).get("tab")) || null;
  var profile = structuredClone(DEFAULT_PROFILE);
  var origin = "local";
  var running = false;
  var busy = false;
  var dirty = false;
  var generation = 0;
  var seen = /* @__PURE__ */ new Set();
  var observationWrites = Promise.resolve();
  function persistObservation(r) {
    observationWrites = observationWrites.then(() => saveObservation(r)).catch((e) => status("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435: " + e.message));
  }
  var lastResult = null;
  var job = null;
  var observations = [];
  var processedActions = /* @__PURE__ */ new Set();
  var stats = {
    pageJobs: 0,
    fills: 0,
    skips: 0,
    skipClicks: 0,
    correct: 0,
    incorrect: 0
  };
  var pendingFills = /* @__PURE__ */ new Set();
  function showCounters() {
    $("counters").textContent = `\u0417\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u043E: ${stats.fills} \xB7 \u041F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u043E: ${stats.skips}` + (profile.feedbackSelector ? ` \xB7 \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u0441\u0430\u0439\u0442\u043E\u043C: ${stats.correct} \u0432\u0435\u0440\u043D\u043E, ${stats.incorrect} \u043D\u0435\u0432\u0435\u0440\u043D\u043E; \u0431\u0435\u0437 \u043E\u0446\u0435\u043D\u043A\u0438: ${stats.fills - stats.correct - stats.incorrect}` : "");
  }
  function status(text) {
    $("status").textContent = text;
  }
  async function badge(text) {
    if (tabId) await chrome.action.setBadgeText({ tabId, text }).catch(() => {
    });
  }
  async function send(kind, payload = {}) {
    const response = await chrome.tabs.sendMessage(tabId, { kind, ...payload });
    if (!response)
      throw Error(
        "\u041D\u0435\u0442 \u0441\u0432\u044F\u0437\u0438 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435\u0439. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0438\u043A\u043E\u043D\u043A\u0443 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u043D\u0430 \u043D\u0443\u0436\u043D\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0435."
      );
    if (response.error) throw Error(response.error);
    return response.value;
  }
  var fields = {
    container: "\u041A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440 \u043A\u0430\u043F\u0447\u0438 (\u043F\u0443\u0441\u0442\u043E = \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442)",
    image: "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 <img> \u0438\u043B\u0438 <canvas>",
    instruction: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F",
    minSelector: "\u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 min (\u043F\u0443\u0441\u0442\u043E = minlength \u043F\u043E\u043B\u044F)",
    maxSelector: "\u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 max (\u043F\u0443\u0441\u0442\u043E = maxlength \u043F\u043E\u043B\u044F)",
    input: "\u041F\u043E\u043B\u0435 \u043E\u0442\u0432\u0435\u0442\u0430",
    skipSelector: "\u041A\u043D\u043E\u043F\u043A\u0430 \u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C (\u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440)",
    feedbackSelector: "\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C \u0441\u0430\u0439\u0442\u0430 (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)",
    feedbackSuccess: "\u0422\u043E\u0447\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442 \u0443\u0441\u043F\u0435\u0448\u043D\u043E\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438",
    feedbackFailure: "\u0422\u043E\u0447\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442 \u043E\u0448\u0438\u0431\u043A\u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438"
  };
  for (const [key, title] of Object.entries(fields)) {
    const label = document.createElement("label");
    label.textContent = title;
    const input = document.createElement("input");
    input.id = `selector-${key}`;
    input.spellcheck = false;
    label.append(input);
    $("selectors").append(label);
  }
  for (const key of ["top", "bottom", "left", "right"]) {
    const label = document.createElement("label");
    label.textContent = {
      top: "\u0421\u0432\u0435\u0440\u0445\u0443",
      bottom: "\u0421\u043D\u0438\u0437\u0443",
      left: "\u0421\u043B\u0435\u0432\u0430",
      right: "\u0421\u043F\u0440\u0430\u0432\u0430"
    }[key];
    const input = document.createElement("input");
    input.id = `crop-${key}`;
    input.type = "number";
    input.min = 0;
    input.max = 0.9;
    input.step = 0.01;
    label.append(input);
    $("crop-fields").append(label);
  }
  function showProfile() {
    for (const key in fields) $(`selector-${key}`).value = profile[key];
    $("type").value = profile.type;
    $("alphabet").value = profile.alphabet;
    $("debug-mode").checked = profile.debug;
    $("skip-low").checked = true;
    $("mode").value = profile.mode;
    $("skip-limit").value = profile.maxConsecutiveSkips;
    showCounters();
    for (const key in profile.crop) $(`crop-${key}`).value = profile.crop[key];
  }
  function readProfile() {
    const p = { ...profile, crop: {} };
    for (const key in fields) p[key] = $(`selector-${key}`).value.trim();
    p.type = $("type").value;
    p.alphabet = $("alphabet").value.replace(/\s/g, "");
    p.debug = $("debug-mode").checked;
    p.skipLowConfidence = true;
    p.mode = $("mode").value;
    p.maxConsecutiveSkips = Number($("skip-limit").value);
    if (!Number.isInteger(p.maxConsecutiveSkips) || p.maxConsecutiveSkips < 1 || p.maxConsecutiveSkips > 100)
      throw Error("\u041B\u0438\u043C\u0438\u0442 \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u043E\u0432 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043E\u0442 1 \u0434\u043E 100.");
    if (p.feedbackSelector && (!p.feedbackSuccess || !p.feedbackFailure || p.feedbackSuccess === p.feedbackFailure))
      throw Error(
        "\u0414\u043B\u044F \u043E\u0431\u0440\u0430\u0442\u043D\u043E\u0439 \u0441\u0432\u044F\u0437\u0438 \u0437\u0430\u0434\u0430\u0439\u0442\u0435 \u0434\u0432\u0430 \u0440\u0430\u0437\u043D\u044B\u0445 \u043D\u0435\u043F\u0443\u0441\u0442\u044B\u0445 \u0442\u043E\u0447\u043D\u044B\u0445 \u0442\u0435\u043A\u0441\u0442\u0430 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430."
      );
    if (p.skipLowConfidence && !p.skipSelector)
      throw Error("\u0417\u0430\u0434\u0430\u0439\u0442\u0435 \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440 \u043A\u043D\u043E\u043F\u043A\u0438 \u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C.");
    for (const key of ["top", "bottom", "left", "right"]) {
      p.crop[key] = Number($(`crop-${key}`).value);
      if (!Number.isFinite(p.crop[key]) || p.crop[key] < 0 || p.crop[key] >= 1)
        throw Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u043E\u0431\u0440\u0435\u0437\u043A\u0430.");
    }
    if (p.crop.top + p.crop.bottom >= 1 || p.crop.left + p.crop.right >= 1)
      throw Error("\u041E\u0431\u0440\u0435\u0437\u043A\u0430 \u0443\u0434\u0430\u043B\u044F\u0435\u0442 \u0432\u0441\u0451 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435.");
    return p;
  }
  function render(result) {
    lastResult = result;
    $("candidate").textContent = result.candidate || "\u2014";
    $("debug").hidden = !profile.debug;
    $("variants").replaceChildren();
    if (profile.debug) {
      for (const item of result.debug || [])
        if (item.image) {
          const figure = document.createElement("figure"), caption = document.createElement("figcaption"), image = document.createElement("img");
          caption.textContent = item.name;
          image.src = item.image;
          image.alt = item.name;
          figure.append(caption, image);
          $("variants").append(figure);
        }
    }
    $("evidence").textContent = JSON.stringify(
      {
        candidate: result.candidate,
        confidence: result.confidence,
        accepted: result.accepted,
        reason: result.reason,
        candidates: result.candidates,
        shapes: result.shapes?.map(({ triangle, center, contour }) => ({
          triangle,
          center,
          vertices: contour.length
        }))
      },
      null,
      2
    );
  }
  async function capture(snapshot) {
    const r = snapshot.rect, v = snapshot.viewport;
    if (r.width <= 0 || r.height <= 0 || r.x < 0 || r.y < 0 || r.x + r.width > v.width || r.y + r.height > v.height)
      throw Error(
        "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0432\u043D\u0435 \u0432\u0438\u0434\u0438\u043C\u043E\u0439 \u043E\u0431\u043B\u0430\u0441\u0442\u0438. \u041F\u0440\u043E\u043A\u0440\u0443\u0442\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u043A \u043A\u0430\u043F\u0447\u0435."
      );
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active)
      throw Error("\u0414\u043B\u044F \u0437\u0430\u0445\u0432\u0430\u0442\u0430 \u0441\u0434\u0435\u043B\u0430\u0439\u0442\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u0443\u044E \u0432\u043A\u043B\u0430\u0434\u043A\u0443 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0439 \u0432 \u0435\u0451 \u043E\u043A\u043D\u0435.");
    const url = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: "png"
    });
    const latest = await chrome.tabs.get(tabId);
    if (!latest.active || !await send("VALIDATE", { token: snapshot.token }))
      throw Error("\u0421\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0437\u0430\u0445\u0432\u0430\u0442\u0430. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443.");
    const shot = await loadImage(url), sx = shot.width / v.width, sy = shot.height / v.height;
    return crop(shot, {
      x: r.x * sx,
      y: r.y * sy,
      width: r.width * sx,
      height: r.height * sy
    }).toDataURL();
  }
  function taskFrom(snapshot, image) {
    if (!inferAlphabet(snapshot.instruction, profile.alphabet))
      throw Error(
        "\u041D\u0435 \u0437\u0430\u0434\u0430\u043D \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0430\u043B\u0444\u0430\u0432\u0438\u0442. \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u043E\u0444\u0438\u043B\u044C; \u043F\u0440\u043E\u043F\u0443\u0441\u043A \u043E\u0442\u043C\u0435\u043D\u0451\u043D."
      );
    const type = profile.type === "auto" ? inferType(snapshot.instruction) : profile.type;
    return {
      type,
      image,
      min: snapshot.min,
      max: snapshot.max,
      alphabet: inferAlphabet(snapshot.instruction, profile.alphabet),
      crop: profile.crop
    };
  }
  function logObservation(snapshot, task, result) {
    const record = observationRecord({
      taskId: snapshot.taskId,
      type: task.type,
      image: task.image,
      result,
      startedAt: snapshot.startedAt,
      task,
      instruction: snapshot.instruction,
      origin
    });
    observations.push(record);
    showObservations();
    persistObservation(record);
  }
  function showObservations() {
    $("observations").replaceChildren();
    for (const r of observations.slice(-30).toReversed()) {
      const block = document.createElement("div"), text = document.createElement("p"), input = document.createElement("input");
      text.textContent = `${r.type}: ${r.candidate || "\u2205"} \xB7 ${r.confidence} \xB7 \u0430\u0432\u0442\u043E\u0440\u0435\u0436\u0438\u043C: ${r.wouldFill ? "\u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C" : "\u043E\u0442\u043A\u0430\u0437"} \xB7 ${r.reason}`;
      input.placeholder = "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442";
      input.value = r.answer ?? "";
      input.addEventListener("change", () => {
        r.answer = input.value;
        r.labelVerified = !!input.value;
        persistObservation(r);
      });
      block.append(text, input);
      $("observations").append(block);
    }
  }
  async function finishSkip(snapshot, response, run) {
    if (!response.clicked) throw Error(response.reason || "\u041F\u0440\u043E\u043F\u0443\u0441\u043A \u043E\u0442\u043C\u0435\u043D\u0451\u043D.");
    if (!processedActions.has(snapshot.taskId)) {
      processedActions.add(snapshot.taskId);
      stats.skipClicks++;
    }
    status("\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043D\u0430\u0436\u0430\u0442\u043E. \u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435 \u0441\u043C\u0435\u043D\u044B \u043A\u0430\u043F\u0447\u0438\u2026");
    const end = Date.now() + 4e3;
    let changed = false;
    while (Date.now() < end && run === generation && running) {
      await new Promise((r) => setTimeout(r, 100));
      const next = await send("SNAPSHOT", { profile });
      if (next.manual) throw Error("\u041F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430 \u043D\u0430\u0447\u0430\u0442 \u0440\u0443\u0447\u043D\u043E\u0439 \u0432\u0432\u043E\u0434.");
      if (next.taskId !== snapshot.taskId || next.challenge !== snapshot.challenge) {
        changed = true;
        break;
      }
    }
    if (run !== generation || !running) return;
    if (!changed)
      throw Error(
        "\u041F\u043E\u0441\u043B\u0435 \u043D\u0430\u0436\u0430\u0442\u0438\u044F \u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043A\u0430\u043F\u0447\u0430 \u043D\u0435 \u0441\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0433\u043E \u043D\u0430\u0436\u0430\u0442\u0438\u044F \u043D\u0435 \u0431\u0443\u0434\u0435\u0442."
      );
    stats.skips++;
    showCounters();
    if (response.skipsInARow >= profile.maxConsecutiveSkips) {
      await send("PAUSE", { reason: "\u0414\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442 \u043B\u0438\u043C\u0438\u0442 \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u043E\u0432 \u043F\u043E\u0434\u0440\u044F\u0434." });
      running = false;
      status("\u041F\u0430\u0443\u0437\u0430: \u0434\u043E\u0441\u0442\u0438\u0433\u043D\u0443\u0442 \u043B\u0438\u043C\u0438\u0442 \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u043E\u0432 \u043F\u043E\u0434\u0440\u044F\u0434.");
      return;
    }
    status("\u0421\u043C\u0435\u043D\u0430 \u043A\u0430\u043F\u0447\u0438 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430.");
    if ($("auto").checked) dirty = true;
    else {
      running = false;
      await send("STOP");
    }
  }
  async function processLatest() {
    if (!running) return;
    if (busy) {
      dirty = true;
      return;
    }
    busy = true;
    dirty = false;
    const run = generation, abort = new AbortController();
    job = { abort };
    let snapshot, task, phase = "\u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B / \u0437\u0430\u0445\u0432\u0430\u0442\u0430";
    try {
      snapshot = await send("SNAPSHOT", { profile });
      job.taskId = snapshot.taskId;
      job.snapshot = snapshot;
      if (run !== generation || !running) return;
      if (seen.has(snapshot.taskId)) return;
      if (snapshot.manual) {
        status("\u0412 \u043F\u043E\u043B\u0435 \u0435\u0441\u0442\u044C \u0440\u0443\u0447\u043D\u043E\u0439 \u0442\u0435\u043A\u0441\u0442. \u041E\u043D \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D.");
        await send("PAUSE", { reason: "\u0420\u0443\u0447\u043D\u043E\u0439 \u0432\u0432\u043E\u0434" });
        running = false;
        return;
      }
      if (snapshot.action) {
        status("\u041F\u0430\u0443\u0437\u0430: \u0437\u0430\u0434\u0430\u043D\u0438\u0435 \u0443\u0436\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E \u0438\u043B\u0438 \u0438\u0441\u0442\u0451\u043A \u0435\u0433\u043E \u0434\u0435\u0434\u043B\u0430\u0439\u043D.");
        running = false;
        return;
      }
      seen.add(snapshot.taskId);
      stats.pageJobs++;
      const work = (async () => {
        while (snapshot.loading) {
          await new Promise((r) => setTimeout(r, 75));
          abort.signal.throwIfAborted();
          snapshot = await send("SNAPSHOT", { profile });
        }
        const image = snapshot.image || await capture(snapshot);
        if (snapshot.fallback)
          await send("CAPTURE_BASELINE", { token: snapshot.token, image });
        task = taskFrom(snapshot, image);
        phase = "OCR";
        return recognize2(task, {
          signal: abort.signal,
          deadline: snapshot.ocrDeadline,
          progress: (m) => {
            if (!abort.signal.aborted && run === generation)
              status(`OCR: ${m.status}`);
          }
        });
      })();
      const result = await untilDeadline(
        work,
        snapshot.ocrDeadline,
        abort.signal
      );
      if (run !== generation || !running || abort.signal.aborted) return;
      if (!await send("VALIDATE", { token: snapshot.token })) {
        status("\u041A\u0430\u043F\u0447\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u043D\u0430\u0447\u0430\u0442 \u0440\u0443\u0447\u043D\u043E\u0439 \u0432\u0432\u043E\u0434. \u041F\u043E\u0437\u0434\u043D\u0438\u0439 \u043E\u0442\u0432\u0435\u0442 \u043E\u0442\u0431\u0440\u043E\u0448\u0435\u043D.");
        return;
      }
      if (snapshot.fallback) {
        const fresh = await capture(snapshot);
        if (fresh !== task.image)
          throw Error("\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C \u0432\u043E \u0432\u0440\u0435\u043C\u044F OCR.");
        await send("CAPTURE_BASELINE", {
          token: snapshot.token,
          image: fresh,
          verified: true
        });
      }
      render(result);
      if (!snapshot.auto) {
        logObservation(snapshot, task, result);
        status(`\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435: ${result.reason} \u041F\u043E\u043B\u0435 \u0438 \u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u043B\u0438\u0441\u044C.`);
      } else if (result.accepted) {
        const filled = await send("FILL", {
          token: snapshot.token,
          taskId: snapshot.taskId,
          value: result.candidate
        });
        if (!filled.ok) throw Error(filled.reason);
        stats.fills++;
        processedActions.add(snapshot.taskId);
        pendingFills.add(snapshot.token);
        showCounters();
        status("\u041E\u0442\u0432\u0435\u0442 \u0432\u043D\u0435\u0441\u0451\u043D. \u041E\u0442\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0444\u043E\u0440\u043C\u0443 \u0441\u0430\u043C\u043E\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u043D\u043E.");
        await badge("OK");
      } else {
        phase = "\u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430";
        await finishSkip(
          snapshot,
          await send("SKIP", { token: snapshot.token, taskId: snapshot.taskId }),
          run
        );
      }
      if (!$("auto").checked) {
        running = false;
        await send("STOP");
      }
    } catch (error) {
      if (error instanceof BudgetExpired) {
        abort.abort(error);
        terminateAll();
        if (snapshot?.auto && running && run === generation) {
          try {
            const next = await send("SNAPSHOT", { profile });
            if (next.taskId !== snapshot.taskId) {
              dirty = true;
              return;
            }
            if (!next.action && !next.fallback)
              await finishSkip(
                next,
                await send("SKIP", { token: next.token, taskId: next.taskId }),
                run
              );
          } catch (e) {
            running = false;
            status("\u041F\u0430\u0443\u0437\u0430 \u043F\u043E \u0434\u0435\u0434\u043B\u0430\u0439\u043D\u0443: " + e.message);
            await send("PAUSE", { reason: e.message });
          }
        } else
          status(
            "\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435: OCR \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D \u0447\u0435\u0440\u0435\u0437 28 \u0441\u0435\u043A\u0443\u043D\u0434, \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u043D\u0435\u0442."
          );
      } else if (error?.name === "AbortError") {
      } else if (run === generation) {
        running = false;
        status(
          `${phase === "\u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430" ? "\u041F\u0440\u043E\u043F\u0443\u0441\u043A \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D" : "\u0422\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0448\u0438\u0431\u043A\u0430 " + phase}: ${error.message}`
        );
        await send("PAUSE", { reason: error.message }).catch(() => {
        });
      }
    } finally {
      busy = false;
      if (job?.abort === abort) job = null;
      if (dirty && running) setTimeout(processLatest, 0);
    }
  }
  async function start() {
    if (!tabId) {
      status(
        "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u044D\u0442\u043E \u043E\u043A\u043D\u043E \u0438\u043A\u043E\u043D\u043A\u043E\u0439 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u043D\u0430 \u0432\u043A\u043B\u0430\u0434\u043A\u0435 \u0441 \u043A\u0430\u043F\u0447\u0435\u0439. \u0418\u043B\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u0444\u0430\u0439\u043B \u043D\u0438\u0436\u0435."
      );
      return;
    }
    status("\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B\u2026");
    $("candidate").textContent = "";
    try {
      job?.abort.abort(new DOMException("\u041F\u0435\u0440\u0435\u0437\u0430\u043F\u0443\u0441\u043A", "AbortError"));
      terminateAll();
      generation++;
      running = false;
      await send("STOP");
      profile = readProfile();
      seen = /* @__PURE__ */ new Set();
      await send("START", { profile, resetSeries: true });
      running = true;
      await processLatest();
    } catch (error) {
      status(error.message);
    }
  }
  async function stop() {
    job?.abort.abort(new DOMException("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E", "AbortError"));
    terminateAll();
    generation++;
    running = false;
    dirty = false;
    if (tabId) await send("STOP").catch(() => {
    });
    status("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E. \u041D\u043E\u0432\u044B\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u043D\u0435 \u0431\u0443\u0434\u0443\u0442 \u0432\u043D\u0435\u0441\u0435\u043D\u044B.");
    await badge("");
  }
  $("start").addEventListener("click", start);
  $("stop").addEventListener("click", stop);
  $("auto").addEventListener("change", () => {
    if (!$("auto").checked) stop();
  });
  $("settings").addEventListener("input", () => {
    if (running) stop();
  });
  $("save").addEventListener("click", async () => {
    try {
      profile = readProfile();
      await chrome.storage.local.set({ ["profile:" + origin]: profile });
      $("saved").textContent = "\u041F\u0440\u043E\u0444\u0438\u043B\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E \u0434\u043B\u044F " + origin;
    } catch (error) {
      $("saved").textContent = error.message;
    }
  });
  chrome.runtime.onMessage.addListener((message, sender) => {
    if (sender.tab?.id === tabId && message.kind === "TASK_PAUSED") {
      job?.abort.abort(new DOMException("\u041F\u0430\u0443\u0437\u0430", "AbortError"));
      terminateAll();
      running = false;
      status("\u041F\u0430\u0443\u0437\u0430: " + message.reason);
      return;
    }
    if (sender.tab?.id === tabId && message.kind === "TASK_ACTION") {
      const snapshot = job?.snapshot;
      job?.abort.abort(new DOMException("\u0414\u0435\u0434\u043B\u0430\u0439\u043D", "AbortError"));
      terminateAll();
      if (message.clicked && !processedActions.has(message.taskId)) {
        const run = generation;
        const old = { taskId: message.taskId, challenge: message.challenge };
        finishSkip(old, message, run).then(() => {
          if (dirty && running) processLatest();
        }).catch((e) => {
          running = false;
          status("\u041F\u0430\u0443\u0437\u0430: " + e.message);
          send("PAUSE", { reason: e.message });
        });
      } else if (!message.clicked) {
        running = false;
        status("\u041F\u0430\u0443\u0437\u0430: " + message.reason);
      }
      return;
    }
    if (sender.tab?.id === tabId && message.kind === "CAPTCHA_FEEDBACK" && pendingFills.has(message.token)) {
      pendingFills.delete(message.token);
      if (message.outcome === "correct") stats.correct++;
      else if (message.outcome === "incorrect") stats.incorrect++;
      showCounters();
      return;
    }
    if (sender.id === chrome.runtime.id && message.kind === "ACTIVATE_CONTROLLER" && message.tabId === tabId) {
      stop().then(init);
      return;
    }
    if (sender.tab?.id === tabId && message.kind === "CAPTCHA_CHANGED" && running && $("auto").checked) {
      if (job && message.taskId && message.taskId !== job.taskId) {
        job.abort.abort(new DOMException("\u041D\u043E\u0432\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435", "AbortError"));
        terminateAll();
      }
      processLatest();
    }
  });
  chrome.tabs.onRemoved.addListener((id) => {
    if (id === tabId) stop();
  });
  $("recognize-file").addEventListener("click", async () => {
    if (busy) {
      status("\u0414\u043E\u0436\u0434\u0438\u0442\u0435\u0441\u044C \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E OCR.");
      return;
    }
    await stop();
    try {
      profile = readProfile();
      const file = $("upload").files[0];
      if (!file) throw Error("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u0430\u0439\u043B \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F.");
      if (profile.type === "auto") throw Error("\u0414\u043B\u044F \u0444\u0430\u0439\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0442\u0438\u043F \u0432\u0440\u0443\u0447\u043D\u0443\u044E.");
      const min = Number($("local-min").value), max = Number($("local-max").value);
      if (min < 1 || max < min || max > 64) throw Error("\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 min/max.");
      const run = generation;
      busy = true;
      const image = await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result);
        r.onerror = reject;
        r.readAsDataURL(file);
      });
      status("\u0420\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430\u2026");
      const result = await recognize2({
        image,
        type: profile.type,
        alphabet: profile.alphabet,
        crop: profile.crop,
        min,
        max
      });
      if (run !== generation) return;
      render(result);
      status(`\u0424\u0430\u0439\u043B: ${result.reason} \u041F\u043E\u043B\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u043B\u043E\u0441\u044C.`);
    } catch (error) {
      status(error.message);
    } finally {
      busy = false;
    }
  });
  globalThis.CaptchaLab = {
    recognize: recognize2,
    stats,
    observations,
    flushObservations: () => observationWrites,
    get lastResult() {
      return lastResult;
    }
  };
  async function init() {
    try {
      if (tabId) {
        const tab = await chrome.tabs.get(tabId);
        origin = new URL(tab.url).origin;
      }
      const saved = await chrome.storage.local.get("profile:" + origin);
      for (const r of await loadObservations())
        if (!observations.some((x) => x.id === r.id)) observations.push(r);
      showObservations();
      profile = {
        ...DEFAULT_PROFILE,
        ...saved["profile:" + origin],
        crop: { ...DEFAULT_PROFILE.crop, ...saved["profile:" + origin]?.crop }
      };
      showProfile();
      if (tabId) await start();
      else
        status(
          "OCR-\u0441\u0442\u0435\u043D\u0434: \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0438\u043A\u043E\u043D\u043A\u0443 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435."
        );
    } catch (error) {
      showProfile();
      status(error.message);
    }
  }
  $("export-observations").addEventListener("click", () => {
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(observations, null, 2)], {
        type: "application/json"
      })
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = "captcha-observations.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  });
  $("run-folder").addEventListener("click", async () => {
    await stop();
    try {
      profile = readProfile();
      const files = [...$("folder").files], csv = files.find((f) => /\.csv$/i.test(f.name));
      if (!csv)
        throw Error("\u0412 \u043F\u0430\u043F\u043A\u0435 \u043D\u0443\u0436\u0435\u043D CSV \u0441 \u043A\u043E\u043B\u043E\u043D\u043A\u0430\u043C\u0438 file,type,answer,source.");
      const rows = parseCSV(await csv.text());
      for (const row of rows) {
        const file = files.find(
          (f) => f.name === row.file || f.webkitRelativePath.endsWith("/" + row.file)
        );
        if (!file) throw Error("\u041D\u0435\u0442 \u0444\u0430\u0439\u043B\u0430 " + row.file);
        const image = await new Promise((resolve, reject) => {
          const r = new FileReader();
          r.onload = () => resolve(r.result);
          r.onerror = reject;
          r.readAsDataURL(file);
        });
        const task = {
          image,
          type: row.type,
          alphabet: row.alphabet || profile.alphabet,
          min: Number(row.min || 3),
          max: Number(row.max || 6),
          crop: {
            top: Number(row.crop_top || 0),
            bottom: Number(row.crop_bottom || 0),
            left: 0,
            right: 0
          }
        };
        const startedAt = Date.now(), result = await untilDeadline(recognize2(task), startedAt + 28e3);
        const rec = observationRecord({
          taskId: row.file,
          type: row.type,
          image,
          result,
          startedAt,
          source: row.source || "unverified",
          task
        });
        if (row.answer) {
          rec.answer = row.answer;
          rec.labelVerified = true;
        }
        observations.push(rec);
        persistObservation(rec);
        render(result);
        showObservations();
      }
      status("\u041F\u0430\u043F\u043A\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u0430 \u0432 \u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0438; \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u043D\u0435\u0442.");
    } catch (e) {
      terminateAll();
      status("\u041D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435 \u043F\u0430\u043F\u043A\u0438: " + e.message);
    }
  });
  init();
})();
