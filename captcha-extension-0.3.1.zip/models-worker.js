var __require = /* @__PURE__ */ ((x2) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x2, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x2)(function(x2) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x2 + '" is not supported');
});

// node_modules/onnxruntime-web/dist/ort.wasm.bundle.min.mjs
var Ft = Object.defineProperty;
var zo = Object.getOwnPropertyDescriptor;
var Ho = Object.getOwnPropertyNames;
var Vo = Object.prototype.hasOwnProperty;
var Nt = ((t) => typeof __require < "u" ? __require : typeof Proxy < "u" ? new Proxy(t, { get: (r, s) => (typeof __require < "u" ? __require : r)[s] }) : t)(function(t) {
  if (typeof __require < "u") return __require.apply(this, arguments);
  throw Error('Dynamic require of "' + t + '" is not supported');
});
var L = (t, r) => () => (t && (r = t(t = 0)), r);
var Xe = (t, r) => {
  for (var s in r) Ft(t, s, { get: r[s], enumerable: true });
};
var jo = (t, r, s, n) => {
  if (r && typeof r == "object" || typeof r == "function") for (let a of Ho(r)) !Vo.call(t, a) && a !== s && Ft(t, a, { get: () => r[a], enumerable: !(n = zo(r, a)) || n.enumerable });
  return t;
};
var kt = (t) => jo(Ft({}, "__esModule", { value: true }), t);
var Qe;
var we;
var Ge;
var Yo;
var Qr;
var Wt = L(() => {
  "use strict";
  Qe = /* @__PURE__ */ new Map(), we = [], Ge = (t, r, s) => {
    if (r && typeof r.init == "function" && typeof r.createInferenceSessionHandler == "function") {
      let n = Qe.get(t);
      if (n === void 0) Qe.set(t, { backend: r, priority: s });
      else {
        if (n.priority > s) return;
        if (n.priority === s && n.backend !== r) throw new Error(`cannot register backend "${t}" using priority ${s}`);
      }
      if (s >= 0) {
        let a = we.indexOf(t);
        a !== -1 && we.splice(a, 1);
        for (let c = 0; c < we.length; c++) if (Qe.get(we[c]).priority <= s) {
          we.splice(c, 0, t);
          return;
        }
        we.push(t);
      }
      return;
    }
    throw new TypeError("not a valid backend");
  }, Yo = async (t) => {
    let r = Qe.get(t);
    if (!r) return "backend not found.";
    if (r.initialized) return r.backend;
    if (r.aborted) return r.error;
    {
      let s = !!r.initPromise;
      try {
        return s || (r.initPromise = r.backend.init(t)), await r.initPromise, r.initialized = true, r.backend;
      } catch (n) {
        return s || (r.error = `${n}`, r.aborted = true), r.error;
      } finally {
        delete r.initPromise;
      }
    }
  }, Qr = async (t) => {
    let r = t.executionProviders || [], s = r.map((d) => typeof d == "string" ? d : d.name), n = s.length === 0 ? we : s, a, c = [], f = /* @__PURE__ */ new Set();
    for (let d of n) {
      let m = await Yo(d);
      typeof m == "string" ? c.push({ name: d, err: m }) : (a || (a = m), a === m && f.add(d));
    }
    if (!a) throw new Error(`no available backend found. ERR: ${c.map((d) => `[${d.name}] ${d.err}`).join(", ")}`);
    for (let { name: d, err: m } of c) s.includes(d) && console.warn(`removing requested execution provider "${d}" from session options because it is not available: ${m}`);
    let i = r.filter((d) => f.has(typeof d == "string" ? d : d.name));
    return [a, new Proxy(t, { get: (d, m) => m === "executionProviders" ? i : Reflect.get(d, m) })];
  };
});
var Zr = L(() => {
  "use strict";
  Wt();
});
var Kr;
var en = L(() => {
  "use strict";
  Kr = "1.23.2";
});
var tn;
var z;
var Gt = L(() => {
  "use strict";
  en();
  tn = "warning", z = { wasm: {}, webgl: {}, webgpu: {}, versions: { common: Kr }, set logLevel(t) {
    if (t !== void 0) {
      if (typeof t != "string" || ["verbose", "info", "warning", "error", "fatal"].indexOf(t) === -1) throw new Error(`Unsupported logging level: ${t}`);
      tn = t;
    }
  }, get logLevel() {
    return tn;
  } };
  Object.defineProperty(z, "logLevel", { enumerable: true });
});
var F;
var rn = L(() => {
  "use strict";
  Gt();
  F = z;
});
var nn;
var on;
var sn = L(() => {
  "use strict";
  nn = (t, r) => {
    let s = typeof document < "u" ? document.createElement("canvas") : new OffscreenCanvas(1, 1);
    s.width = t.dims[3], s.height = t.dims[2];
    let n = s.getContext("2d");
    if (n != null) {
      let a, c;
      r?.tensorLayout !== void 0 && r.tensorLayout === "NHWC" ? (a = t.dims[2], c = t.dims[3]) : (a = t.dims[3], c = t.dims[2]);
      let f = r?.format !== void 0 ? r.format : "RGB", i = r?.norm, d, m;
      i === void 0 || i.mean === void 0 ? d = [255, 255, 255, 255] : typeof i.mean == "number" ? d = [i.mean, i.mean, i.mean, i.mean] : (d = [i.mean[0], i.mean[1], i.mean[2], 0], i.mean[3] !== void 0 && (d[3] = i.mean[3])), i === void 0 || i.bias === void 0 ? m = [0, 0, 0, 0] : typeof i.bias == "number" ? m = [i.bias, i.bias, i.bias, i.bias] : (m = [i.bias[0], i.bias[1], i.bias[2], 0], i.bias[3] !== void 0 && (m[3] = i.bias[3]));
      let h = c * a, b = 0, w = h, y = h * 2, O = -1;
      f === "RGBA" ? (b = 0, w = h, y = h * 2, O = h * 3) : f === "RGB" ? (b = 0, w = h, y = h * 2) : f === "RBG" && (b = 0, y = h, w = h * 2);
      for (let v = 0; v < c; v++) for (let U = 0; U < a; U++) {
        let S = (t.data[b++] - m[0]) * d[0], T = (t.data[w++] - m[1]) * d[1], M = (t.data[y++] - m[2]) * d[2], B = O === -1 ? 255 : (t.data[O++] - m[3]) * d[3];
        n.fillStyle = "rgba(" + S + "," + T + "," + M + "," + B + ")", n.fillRect(U, v, 1, 1);
      }
      if ("toDataURL" in s) return s.toDataURL();
      throw new Error("toDataURL is not supported");
    } else throw new Error("Can not access image data");
  }, on = (t, r) => {
    let s = typeof document < "u" ? document.createElement("canvas").getContext("2d") : new OffscreenCanvas(1, 1).getContext("2d"), n;
    if (s != null) {
      let a, c, f;
      r?.tensorLayout !== void 0 && r.tensorLayout === "NHWC" ? (a = t.dims[2], c = t.dims[1], f = t.dims[3]) : (a = t.dims[3], c = t.dims[2], f = t.dims[1]);
      let i = r !== void 0 && r.format !== void 0 ? r.format : "RGB", d = r?.norm, m, h;
      d === void 0 || d.mean === void 0 ? m = [255, 255, 255, 255] : typeof d.mean == "number" ? m = [d.mean, d.mean, d.mean, d.mean] : (m = [d.mean[0], d.mean[1], d.mean[2], 255], d.mean[3] !== void 0 && (m[3] = d.mean[3])), d === void 0 || d.bias === void 0 ? h = [0, 0, 0, 0] : typeof d.bias == "number" ? h = [d.bias, d.bias, d.bias, d.bias] : (h = [d.bias[0], d.bias[1], d.bias[2], 0], d.bias[3] !== void 0 && (h[3] = d.bias[3]));
      let b = c * a;
      if (r !== void 0 && (r.format !== void 0 && f === 4 && r.format !== "RGBA" || f === 3 && r.format !== "RGB" && r.format !== "BGR")) throw new Error("Tensor format doesn't match input tensor dims");
      let w = 4, y = 0, O = 1, v = 2, U = 3, S = 0, T = b, M = b * 2, B = -1;
      i === "RGBA" ? (S = 0, T = b, M = b * 2, B = b * 3) : i === "RGB" ? (S = 0, T = b, M = b * 2) : i === "RBG" && (S = 0, M = b, T = b * 2), n = s.createImageData(a, c);
      for (let D = 0; D < c * a; y += w, O += w, v += w, U += w, D++) n.data[y] = (t.data[S++] - h[0]) * m[0], n.data[O] = (t.data[T++] - h[1]) * m[1], n.data[v] = (t.data[M++] - h[2]) * m[2], n.data[U] = B === -1 ? 255 : (t.data[B++] - h[3]) * m[3];
    } else throw new Error("Can not access image data");
    return n;
  };
});
var $t;
var an;
var un;
var fn;
var cn;
var ln;
var dn = L(() => {
  "use strict";
  Ze();
  $t = (t, r) => {
    if (t === void 0) throw new Error("Image buffer must be defined");
    if (r.height === void 0 || r.width === void 0) throw new Error("Image height and width must be defined");
    if (r.tensorLayout === "NHWC") throw new Error("NHWC Tensor layout is not supported yet");
    let { height: s, width: n } = r, a = r.norm ?? { mean: 255, bias: 0 }, c, f;
    typeof a.mean == "number" ? c = [a.mean, a.mean, a.mean, a.mean] : c = [a.mean[0], a.mean[1], a.mean[2], a.mean[3] ?? 255], typeof a.bias == "number" ? f = [a.bias, a.bias, a.bias, a.bias] : f = [a.bias[0], a.bias[1], a.bias[2], a.bias[3] ?? 0];
    let i = r.format !== void 0 ? r.format : "RGBA", d = r.tensorFormat !== void 0 && r.tensorFormat !== void 0 ? r.tensorFormat : "RGB", m = s * n, h = d === "RGBA" ? new Float32Array(m * 4) : new Float32Array(m * 3), b = 4, w = 0, y = 1, O = 2, v = 3, U = 0, S = m, T = m * 2, M = -1;
    i === "RGB" && (b = 3, w = 0, y = 1, O = 2, v = -1), d === "RGBA" ? M = m * 3 : d === "RBG" ? (U = 0, T = m, S = m * 2) : d === "BGR" && (T = 0, S = m, U = m * 2);
    for (let D = 0; D < m; D++, w += b, O += b, y += b, v += b) h[U++] = (t[w] + f[0]) / c[0], h[S++] = (t[y] + f[1]) / c[1], h[T++] = (t[O] + f[2]) / c[2], M !== -1 && v !== -1 && (h[M++] = (t[v] + f[3]) / c[3]);
    return d === "RGBA" ? new j("float32", h, [1, 4, s, n]) : new j("float32", h, [1, 3, s, n]);
  }, an = async (t, r) => {
    let s = typeof HTMLImageElement < "u" && t instanceof HTMLImageElement, n = typeof ImageData < "u" && t instanceof ImageData, a = typeof ImageBitmap < "u" && t instanceof ImageBitmap, c = typeof t == "string", f, i = r ?? {}, d = () => {
      if (typeof document < "u") return document.createElement("canvas");
      if (typeof OffscreenCanvas < "u") return new OffscreenCanvas(1, 1);
      throw new Error("Canvas is not supported");
    }, m = (h) => typeof HTMLCanvasElement < "u" && h instanceof HTMLCanvasElement || h instanceof OffscreenCanvas ? h.getContext("2d") : null;
    if (s) {
      let h = d();
      h.width = t.width, h.height = t.height;
      let b = m(h);
      if (b != null) {
        let w = t.height, y = t.width;
        if (r !== void 0 && r.resizedHeight !== void 0 && r.resizedWidth !== void 0 && (w = r.resizedHeight, y = r.resizedWidth), r !== void 0) {
          if (i = r, r.tensorFormat !== void 0) throw new Error("Image input config format must be RGBA for HTMLImageElement");
          i.tensorFormat = "RGBA", i.height = w, i.width = y;
        } else i.tensorFormat = "RGBA", i.height = w, i.width = y;
        b.drawImage(t, 0, 0), f = b.getImageData(0, 0, y, w).data;
      } else throw new Error("Can not access image data");
    } else if (n) {
      let h, b;
      if (r !== void 0 && r.resizedWidth !== void 0 && r.resizedHeight !== void 0 ? (h = r.resizedHeight, b = r.resizedWidth) : (h = t.height, b = t.width), r !== void 0 && (i = r), i.format = "RGBA", i.height = h, i.width = b, r !== void 0) {
        let w = d();
        w.width = b, w.height = h;
        let y = m(w);
        if (y != null) y.putImageData(t, 0, 0), f = y.getImageData(0, 0, b, h).data;
        else throw new Error("Can not access image data");
      } else f = t.data;
    } else if (a) {
      if (r === void 0) throw new Error("Please provide image config with format for Imagebitmap");
      let h = d();
      h.width = t.width, h.height = t.height;
      let b = m(h);
      if (b != null) {
        let w = t.height, y = t.width;
        return b.drawImage(t, 0, 0, y, w), f = b.getImageData(0, 0, y, w).data, i.height = w, i.width = y, $t(f, i);
      } else throw new Error("Can not access image data");
    } else {
      if (c) return new Promise((h, b) => {
        let w = d(), y = m(w);
        if (!t || !y) return b();
        let O = new Image();
        O.crossOrigin = "Anonymous", O.src = t, O.onload = () => {
          w.width = O.width, w.height = O.height, y.drawImage(O, 0, 0, w.width, w.height);
          let v = y.getImageData(0, 0, w.width, w.height);
          i.height = w.height, i.width = w.width, h($t(v.data, i));
        };
      });
      throw new Error("Input data provided is not supported - aborted tensor creation");
    }
    if (f !== void 0) return $t(f, i);
    throw new Error("Input data provided is not supported - aborted tensor creation");
  }, un = (t, r) => {
    let { width: s, height: n, download: a, dispose: c } = r, f = [1, n, s, 4];
    return new j({ location: "texture", type: "float32", texture: t, dims: f, download: a, dispose: c });
  }, fn = (t, r) => {
    let { dataType: s, dims: n, download: a, dispose: c } = r;
    return new j({ location: "gpu-buffer", type: s ?? "float32", gpuBuffer: t, dims: n, download: a, dispose: c });
  }, cn = (t, r) => {
    let { dataType: s, dims: n, download: a, dispose: c } = r;
    return new j({ location: "ml-tensor", type: s ?? "float32", mlTensor: t, dims: n, download: a, dispose: c });
  }, ln = (t, r, s) => new j({ location: "cpu-pinned", type: t, data: r, dims: s ?? [r.length] });
});
var be;
var $e;
var pn;
var mn;
var hn = L(() => {
  "use strict";
  be = /* @__PURE__ */ new Map([["float32", Float32Array], ["uint8", Uint8Array], ["int8", Int8Array], ["uint16", Uint16Array], ["int16", Int16Array], ["int32", Int32Array], ["bool", Uint8Array], ["float64", Float64Array], ["uint32", Uint32Array], ["int4", Uint8Array], ["uint4", Uint8Array]]), $e = /* @__PURE__ */ new Map([[Float32Array, "float32"], [Uint8Array, "uint8"], [Int8Array, "int8"], [Uint16Array, "uint16"], [Int16Array, "int16"], [Int32Array, "int32"], [Float64Array, "float64"], [Uint32Array, "uint32"]]), pn = false, mn = () => {
    if (!pn) {
      pn = true;
      let t = typeof BigInt64Array < "u" && BigInt64Array.from, r = typeof BigUint64Array < "u" && BigUint64Array.from, s = globalThis.Float16Array, n = typeof s < "u" && s.from;
      t && (be.set("int64", BigInt64Array), $e.set(BigInt64Array, "int64")), r && (be.set("uint64", BigUint64Array), $e.set(BigUint64Array, "uint64")), n ? (be.set("float16", s), $e.set(s, "float16")) : be.set("float16", Uint16Array);
    }
  };
});
var wn;
var bn;
var gn = L(() => {
  "use strict";
  Ze();
  wn = (t) => {
    let r = 1;
    for (let s = 0; s < t.length; s++) {
      let n = t[s];
      if (typeof n != "number" || !Number.isSafeInteger(n)) throw new TypeError(`dims[${s}] must be an integer, got: ${n}`);
      if (n < 0) throw new RangeError(`dims[${s}] must be a non-negative integer, got: ${n}`);
      r *= n;
    }
    return r;
  }, bn = (t, r) => {
    switch (t.location) {
      case "cpu":
        return new j(t.type, t.data, r);
      case "cpu-pinned":
        return new j({ location: "cpu-pinned", data: t.data, type: t.type, dims: r });
      case "texture":
        return new j({ location: "texture", texture: t.texture, type: t.type, dims: r });
      case "gpu-buffer":
        return new j({ location: "gpu-buffer", gpuBuffer: t.gpuBuffer, type: t.type, dims: r });
      case "ml-tensor":
        return new j({ location: "ml-tensor", mlTensor: t.mlTensor, type: t.type, dims: r });
      default:
        throw new Error(`tensorReshape: tensor location ${t.location} is not supported`);
    }
  };
});
var j;
var Ze = L(() => {
  "use strict";
  sn();
  dn();
  hn();
  gn();
  j = class {
    constructor(r, s, n) {
      mn();
      let a, c;
      if (typeof r == "object" && "location" in r) switch (this.dataLocation = r.location, a = r.type, c = r.dims, r.location) {
        case "cpu-pinned": {
          let i = be.get(a);
          if (!i) throw new TypeError(`unsupported type "${a}" to create tensor from pinned buffer`);
          if (!(r.data instanceof i)) throw new TypeError(`buffer should be of type ${i.name}`);
          this.cpuData = r.data;
          break;
        }
        case "texture": {
          if (a !== "float32") throw new TypeError(`unsupported type "${a}" to create tensor from texture`);
          this.gpuTextureData = r.texture, this.downloader = r.download, this.disposer = r.dispose;
          break;
        }
        case "gpu-buffer": {
          if (a !== "float32" && a !== "float16" && a !== "int32" && a !== "int64" && a !== "uint32" && a !== "uint8" && a !== "bool" && a !== "uint4" && a !== "int4") throw new TypeError(`unsupported type "${a}" to create tensor from gpu buffer`);
          this.gpuBufferData = r.gpuBuffer, this.downloader = r.download, this.disposer = r.dispose;
          break;
        }
        case "ml-tensor": {
          if (a !== "float32" && a !== "float16" && a !== "int32" && a !== "int64" && a !== "uint32" && a !== "uint64" && a !== "int8" && a !== "uint8" && a !== "bool" && a !== "uint4" && a !== "int4") throw new TypeError(`unsupported type "${a}" to create tensor from MLTensor`);
          this.mlTensorData = r.mlTensor, this.downloader = r.download, this.disposer = r.dispose;
          break;
        }
        default:
          throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`);
      }
      else {
        let i, d;
        if (typeof r == "string") if (a = r, d = n, r === "string") {
          if (!Array.isArray(s)) throw new TypeError("A string tensor's data must be a string array.");
          i = s;
        } else {
          let m = be.get(r);
          if (m === void 0) throw new TypeError(`Unsupported tensor type: ${r}.`);
          if (Array.isArray(s)) {
            if (r === "float16" && m === Uint16Array || r === "uint4" || r === "int4") throw new TypeError(`Creating a ${r} tensor from number array is not supported. Please use ${m.name} as data.`);
            r === "uint64" || r === "int64" ? i = m.from(s, BigInt) : i = m.from(s);
          } else if (s instanceof m) i = s;
          else if (s instanceof Uint8ClampedArray) if (r === "uint8") i = Uint8Array.from(s);
          else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");
          else if (r === "float16" && s instanceof Uint16Array && m !== Uint16Array) i = new globalThis.Float16Array(s.buffer, s.byteOffset, s.length);
          else throw new TypeError(`A ${a} tensor's data must be type of ${m}`);
        }
        else if (d = s, Array.isArray(r)) {
          if (r.length === 0) throw new TypeError("Tensor type cannot be inferred from an empty array.");
          let m = typeof r[0];
          if (m === "string") a = "string", i = r;
          else if (m === "boolean") a = "bool", i = Uint8Array.from(r);
          else throw new TypeError(`Invalid element type of data array: ${m}.`);
        } else if (r instanceof Uint8ClampedArray) a = "uint8", i = Uint8Array.from(r);
        else {
          let m = $e.get(r.constructor);
          if (m === void 0) throw new TypeError(`Unsupported type for tensor data: ${r.constructor}.`);
          a = m, i = r;
        }
        if (d === void 0) d = [i.length];
        else if (!Array.isArray(d)) throw new TypeError("A tensor's dims must be a number array");
        c = d, this.cpuData = i, this.dataLocation = "cpu";
      }
      let f = wn(c);
      if (this.cpuData && f !== this.cpuData.length && !((a === "uint4" || a === "int4") && Math.ceil(f / 2) === this.cpuData.length)) throw new Error(`Tensor's size(${f}) does not match data length(${this.cpuData.length}).`);
      this.type = a, this.dims = c, this.size = f;
    }
    static async fromImage(r, s) {
      return an(r, s);
    }
    static fromTexture(r, s) {
      return un(r, s);
    }
    static fromGpuBuffer(r, s) {
      return fn(r, s);
    }
    static fromMLTensor(r, s) {
      return cn(r, s);
    }
    static fromPinnedBuffer(r, s, n) {
      return ln(r, s, n);
    }
    toDataURL(r) {
      return nn(this, r);
    }
    toImageData(r) {
      return on(this, r);
    }
    get data() {
      if (this.ensureValid(), !this.cpuData) throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");
      return this.cpuData;
    }
    get location() {
      return this.dataLocation;
    }
    get texture() {
      if (this.ensureValid(), !this.gpuTextureData) throw new Error("The data is not stored as a WebGL texture.");
      return this.gpuTextureData;
    }
    get gpuBuffer() {
      if (this.ensureValid(), !this.gpuBufferData) throw new Error("The data is not stored as a WebGPU buffer.");
      return this.gpuBufferData;
    }
    get mlTensor() {
      if (this.ensureValid(), !this.mlTensorData) throw new Error("The data is not stored as a WebNN MLTensor.");
      return this.mlTensorData;
    }
    async getData(r) {
      switch (this.ensureValid(), this.dataLocation) {
        case "cpu":
        case "cpu-pinned":
          return this.data;
        case "texture":
        case "gpu-buffer":
        case "ml-tensor": {
          if (!this.downloader) throw new Error("The current tensor is not created with a specified data downloader.");
          if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
          try {
            this.isDownloading = true;
            let s = await this.downloader();
            return this.downloader = void 0, this.dataLocation = "cpu", this.cpuData = s, r && this.disposer && (this.disposer(), this.disposer = void 0), s;
          } finally {
            this.isDownloading = false;
          }
        }
        default:
          throw new Error(`cannot get data from location: ${this.dataLocation}`);
      }
    }
    dispose() {
      if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
      this.disposer && (this.disposer(), this.disposer = void 0), this.cpuData = void 0, this.gpuTextureData = void 0, this.gpuBufferData = void 0, this.mlTensorData = void 0, this.downloader = void 0, this.isDownloading = void 0, this.dataLocation = "none";
    }
    ensureValid() {
      if (this.dataLocation === "none") throw new Error("The tensor is disposed.");
    }
    reshape(r) {
      if (this.ensureValid(), this.downloader || this.disposer) throw new Error("Cannot reshape a tensor that owns GPU resource.");
      return bn(this, r);
    }
  };
});
var ue;
var zt = L(() => {
  "use strict";
  Ze();
  ue = j;
});
var yn;
var En;
var ge;
var ye;
var Ee;
var Te;
var Ht = L(() => {
  "use strict";
  Gt();
  yn = (t, r) => {
    (typeof z.trace > "u" ? !z.wasm.trace : !z.trace) || console.timeStamp(`${t}::ORT::${r}`);
  }, En = (t, r) => {
    let s = new Error().stack?.split(/\r\n|\r|\n/g) || [], n = false;
    for (let a = 0; a < s.length; a++) {
      if (n && !s[a].includes("TRACE_FUNC")) {
        let c = `FUNC_${t}::${s[a].trim().split(" ")[1]}`;
        r && (c += `::${r}`), yn("CPU", c);
        return;
      }
      s[a].includes("TRACE_FUNC") && (n = true);
    }
  }, ge = (t) => {
    (typeof z.trace > "u" ? !z.wasm.trace : !z.trace) || En("BEGIN", t);
  }, ye = (t) => {
    (typeof z.trace > "u" ? !z.wasm.trace : !z.trace) || En("END", t);
  }, Ee = (t) => {
    (typeof z.trace > "u" ? !z.wasm.trace : !z.trace) || console.time(`ORT::${t}`);
  }, Te = (t) => {
    (typeof z.trace > "u" ? !z.wasm.trace : !z.trace) || console.timeEnd(`ORT::${t}`);
  };
});
var Ke;
var Tn = L(() => {
  "use strict";
  Wt();
  zt();
  Ht();
  Ke = class t {
    constructor(r) {
      this.handler = r;
    }
    async run(r, s, n) {
      ge(), Ee("InferenceSession.run");
      let a = {}, c = {};
      if (typeof r != "object" || r === null || r instanceof ue || Array.isArray(r)) throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");
      let f = true;
      if (typeof s == "object") {
        if (s === null) throw new TypeError("Unexpected argument[1]: cannot be null.");
        if (s instanceof ue) throw new TypeError("'fetches' cannot be a Tensor");
        if (Array.isArray(s)) {
          if (s.length === 0) throw new TypeError("'fetches' cannot be an empty array.");
          f = false;
          for (let m of s) {
            if (typeof m != "string") throw new TypeError("'fetches' must be a string array or an object.");
            if (this.outputNames.indexOf(m) === -1) throw new RangeError(`'fetches' contains invalid output name: ${m}.`);
            a[m] = null;
          }
          if (typeof n == "object" && n !== null) c = n;
          else if (typeof n < "u") throw new TypeError("'options' must be an object.");
        } else {
          let m = false, h = Object.getOwnPropertyNames(s);
          for (let b of this.outputNames) if (h.indexOf(b) !== -1) {
            let w = s[b];
            (w === null || w instanceof ue) && (m = true, f = false, a[b] = w);
          }
          if (m) {
            if (typeof n == "object" && n !== null) c = n;
            else if (typeof n < "u") throw new TypeError("'options' must be an object.");
          } else c = s;
        }
      } else if (typeof s < "u") throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");
      for (let m of this.inputNames) if (typeof r[m] > "u") throw new Error(`input '${m}' is missing in 'feeds'.`);
      if (f) for (let m of this.outputNames) a[m] = null;
      let i = await this.handler.run(r, a, c), d = {};
      for (let m in i) if (Object.hasOwnProperty.call(i, m)) {
        let h = i[m];
        h instanceof ue ? d[m] = h : d[m] = new ue(h.type, h.data, h.dims);
      }
      return Te("InferenceSession.run"), ye(), d;
    }
    async release() {
      return this.handler.dispose();
    }
    static async create(r, s, n, a) {
      ge(), Ee("InferenceSession.create");
      let c, f = {};
      if (typeof r == "string") {
        if (c = r, typeof s == "object" && s !== null) f = s;
        else if (typeof s < "u") throw new TypeError("'options' must be an object.");
      } else if (r instanceof Uint8Array) {
        if (c = r, typeof s == "object" && s !== null) f = s;
        else if (typeof s < "u") throw new TypeError("'options' must be an object.");
      } else if (r instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && r instanceof SharedArrayBuffer) {
        let h = r, b = 0, w = r.byteLength;
        if (typeof s == "object" && s !== null) f = s;
        else if (typeof s == "number") {
          if (b = s, !Number.isSafeInteger(b)) throw new RangeError("'byteOffset' must be an integer.");
          if (b < 0 || b >= h.byteLength) throw new RangeError(`'byteOffset' is out of range [0, ${h.byteLength}).`);
          if (w = r.byteLength - b, typeof n == "number") {
            if (w = n, !Number.isSafeInteger(w)) throw new RangeError("'byteLength' must be an integer.");
            if (w <= 0 || b + w > h.byteLength) throw new RangeError(`'byteLength' is out of range (0, ${h.byteLength - b}].`);
            if (typeof a == "object" && a !== null) f = a;
            else if (typeof a < "u") throw new TypeError("'options' must be an object.");
          } else if (typeof n < "u") throw new TypeError("'byteLength' must be a number.");
        } else if (typeof s < "u") throw new TypeError("'options' must be an object.");
        c = new Uint8Array(h, b, w);
      } else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");
      let [i, d] = await Qr(f), m = await i.createInferenceSessionHandler(c, d);
      return Te("InferenceSession.create"), ye(), new t(m);
    }
    startProfiling() {
      this.handler.startProfiling();
    }
    endProfiling() {
      this.handler.endProfiling();
    }
    get inputNames() {
      return this.handler.inputNames;
    }
    get outputNames() {
      return this.handler.outputNames;
    }
    get inputMetadata() {
      return this.handler.inputMetadata;
    }
    get outputMetadata() {
      return this.handler.outputMetadata;
    }
  };
});
var qo;
var Sn = L(() => {
  "use strict";
  Tn();
  qo = Ke;
});
var On = L(() => {
  "use strict";
});
var vn = L(() => {
  "use strict";
});
var An = L(() => {
  "use strict";
});
var In = L(() => {
  "use strict";
});
var Vt = {};
Xe(Vt, { InferenceSession: () => qo, TRACE: () => yn, TRACE_EVENT_BEGIN: () => Ee, TRACE_EVENT_END: () => Te, TRACE_FUNC_BEGIN: () => ge, TRACE_FUNC_END: () => ye, Tensor: () => ue, env: () => F, registerBackend: () => Ge });
var pe = L(() => {
  "use strict";
  Zr();
  rn();
  Sn();
  zt();
  On();
  vn();
  Ht();
  An();
  In();
});
var et = L(() => {
  "use strict";
});
var Dn = {};
Xe(Dn, { default: () => Jo });
var Bn;
var Ln;
var Jo;
var Pn = L(() => {
  "use strict";
  jt();
  Se();
  tt();
  Bn = "ort-wasm-proxy-worker", Ln = globalThis.self?.name === Bn;
  Ln && (self.onmessage = (t) => {
    let { type: r, in: s } = t.data;
    try {
      switch (r) {
        case "init-wasm":
          rt(s.wasm).then(() => {
            nt(s).then(() => {
              postMessage({ type: r });
            }, (n) => {
              postMessage({ type: r, err: n });
            });
          }, (n) => {
            postMessage({ type: r, err: n });
          });
          break;
        case "init-ep": {
          let { epName: n, env: a } = s;
          ot(a, n).then(() => {
            postMessage({ type: r });
          }, (c) => {
            postMessage({ type: r, err: c });
          });
          break;
        }
        case "copy-from": {
          let { buffer: n } = s, a = ze(n);
          postMessage({ type: r, out: a });
          break;
        }
        case "create": {
          let { model: n, options: a } = s;
          st(n, a).then((c) => {
            postMessage({ type: r, out: c });
          }, (c) => {
            postMessage({ type: r, err: c });
          });
          break;
        }
        case "release":
          at(s), postMessage({ type: r });
          break;
        case "run": {
          let { sessionId: n, inputIndices: a, inputs: c, outputIndices: f, options: i } = s;
          it(n, a, c, f, new Array(f.length).fill(null), i).then((d) => {
            d.some((m) => m[3] !== "cpu") ? postMessage({ type: r, err: "Proxy does not support non-cpu tensor location." }) : postMessage({ type: r, out: d }, ft([...c, ...d]));
          }, (d) => {
            postMessage({ type: r, err: d });
          });
          break;
        }
        case "end-profiling":
          ut(s), postMessage({ type: r });
          break;
        default:
      }
    } catch (n) {
      postMessage({ type: r, err: n });
    }
  });
  Jo = Ln ? null : (t) => new Worker(t ?? te, { type: "module", name: Bn });
});
var xn = {};
Xe(xn, { default: () => Xo });
var Un;
var Xo;
var Qo;
var Cn = L(() => {
  "use strict";
  Un = async function(t = {}) {
    var r, s, n = t, a = new Promise((e, o) => {
      r = e, s = o;
    }), c = typeof window == "object", f = typeof WorkerGlobalScope < "u", i = f && self.name?.startsWith("em-pthread");
    n.mountExternalData = (e, o) => {
      e.startsWith("./") && (e = e.substring(2)), (n.Sa || (n.Sa = /* @__PURE__ */ new Map())).set(e, o);
    }, n.unmountExternalData = () => {
      delete n.Sa;
    };
    var d, m, h = globalThis.SharedArrayBuffer ?? new WebAssembly.Memory({ initial: 0, maximum: 0, kb: true }).buffer.constructor, b = (e, o) => {
      throw o;
    }, w = import.meta.url, y = "";
    if (c || f) {
      try {
        y = new URL(".", w).href;
      } catch {
      }
      f && (m = (e) => {
        var o = new XMLHttpRequest();
        return o.open("GET", e, false), o.responseType = "arraybuffer", o.send(null), new Uint8Array(o.response);
      }), d = async (e) => {
        if (Re(e)) return new Promise((u, l) => {
          var p = new XMLHttpRequest();
          p.open("GET", e, true), p.responseType = "arraybuffer", p.onload = () => {
            p.status == 200 || p.status == 0 && p.response ? u(p.response) : l(p.status);
          }, p.onerror = l, p.send(null);
        });
        var o = await fetch(e, { credentials: "same-origin" });
        if (o.ok) return o.arrayBuffer();
        throw Error(o.status + " : " + o.url);
      };
    }
    var O, v, U, S, T, M, B, D, $, V, C, ce, le, X = console.log.bind(console), se = console.error.bind(console), Me = X, A = se, Q = false, Re = (e) => e.startsWith("file://");
    function Z() {
      return v.buffer != T.buffer && ee(), T;
    }
    function K() {
      return v.buffer != T.buffer && ee(), M;
    }
    function W() {
      return v.buffer != T.buffer && ee(), B;
    }
    function E() {
      return v.buffer != T.buffer && ee(), D;
    }
    function Y() {
      return v.buffer != T.buffer && ee(), $;
    }
    function Ae() {
      return v.buffer != T.buffer && ee(), V;
    }
    function fe() {
      return v.buffer != T.buffer && ee(), ce;
    }
    if (i) {
      let e = function(o) {
        try {
          var u = o.data, l = u.Ra;
          if (l === "load") {
            let p = [];
            self.onmessage = (g) => p.push(g), self.startWorker = () => {
              postMessage({ Ra: "loaded" });
              for (let g of p) e(g);
              self.onmessage = e;
            };
            for (let g of u.Za) n[g] && !n[g].proxy || (n[g] = (...I) => {
              postMessage({ Ra: "callHandler", Ya: g, args: I });
            }, g == "print" && (Me = n[g]), g == "printErr" && (A = n[g]));
            v = u.fb, ee(), le(u.gb);
          } else if (l === "run") {
            co(u.Qa), Ut(u.Qa, 0, 0, 1, 0, 0), ar(), It(u.Qa), Fe ||= true;
            try {
              lo(u.bb, u.Va);
            } catch (p) {
              if (p != "unwind") throw p;
            }
          } else u.target !== "setimmediate" && (l === "checkMailbox" ? Fe && Ye() : l && (A(`worker: received unknown command ${l}`), A(u)));
        } catch (p) {
          throw Vr(), p;
        }
      };
      var hs = e, Fe = false;
      self.onunhandledrejection = (o) => {
        throw o.reason || o;
      }, self.onmessage = e;
    }
    function ee() {
      var e = v.buffer;
      n.HEAP8 = T = new Int8Array(e), B = new Int16Array(e), n.HEAPU8 = M = new Uint8Array(e), new Uint16Array(e), n.HEAP32 = D = new Int32Array(e), n.HEAPU32 = $ = new Uint32Array(e), V = new Float32Array(e), ce = new Float64Array(e), C = new BigInt64Array(e), new BigUint64Array(e);
    }
    function ae() {
      i ? startWorker(n) : _.$();
    }
    var ne, ie = 0, N = null;
    function k() {
      if (--ie == 0 && N) {
        var e = N;
        N = null, e();
      }
    }
    function J(e) {
      throw A(e = "Aborted(" + e + ")"), Q = true, e = new WebAssembly.RuntimeError(e + ". Build with -sASSERTIONS for more info."), s(e), e;
    }
    function me() {
      return { a: { j: $o, b: mo, E: dr, f: hr, U: wr, A: br, C: gr, V: yr, S: Er, L: Tr, R: Sr, n: Or, B: vr, y: Ar, T: Ir, z: _r, _: ho, O: wo, w: bo, F: go, t: yo, i: Eo, N: It, X: To, I: So, J: Oo, K: vo, G: Ur, H: xr, u: Cr, q: Io, Z: Lo, o: Do, k: Po, Y: _o, d: Uo, W: xo, x: Co, c: Ao, e: Mo, h: Ro, v: Fo, s: No, r: ko, P: Fr, Q: kr, D: vt, g: Wr, m: Gr, M: $r, l: zr, a: v, p: Ot } };
    }
    class Ie {
      name = "ExitStatus";
      constructor(o) {
        this.message = `Program terminated with exit(${o})`, this.status = o;
      }
    }
    var Tt = (e) => {
      e.terminate(), e.onmessage = () => {
      };
    }, St = [], rr = (e) => {
      de.length == 0 && (ur(), ir(de[0]));
      var o = de.pop();
      if (!o) return 6;
      Ne.push(o), he[e.Qa] = o, o.Qa = e.Qa;
      var u = { Ra: "run", bb: e.ab, Va: e.Va, Qa: e.Qa };
      return o.postMessage(u, e.Xa), 0;
    }, _e = 0, R = (e, o, ...u) => {
      for (var l = 2 * u.length, p = Mt(), g = Ct(8 * l), I = g >>> 3, G = 0; G < u.length; G++) {
        var H = u[G];
        typeof H == "bigint" ? (C[I + 2 * G] = 1n, C[I + 2 * G + 1] = H) : (C[I + 2 * G] = 0n, fe()[I + 2 * G + 1 >>> 0] = H);
      }
      return e = jr(e, 0, l, g, o), Je(p), e;
    };
    function Ot(e) {
      if (i) return R(0, 1, e);
      if (S = e, !(0 < _e)) {
        for (var o of Ne) Tt(o);
        for (o of de) Tt(o);
        de = [], Ne = [], he = {}, Q = true;
      }
      b(0, new Ie(e));
    }
    function nr(e) {
      if (i) return R(1, 0, e);
      vt(e);
    }
    var vt = (e) => {
      if (S = e, i) throw nr(e), "unwind";
      Ot(e);
    }, de = [], Ne = [], or = [], he = {}, sr = (e) => {
      var o = e.Qa;
      delete he[o], de.push(e), Ne.splice(Ne.indexOf(e), 1), e.Qa = 0, Yr(o);
    };
    function ar() {
      or.forEach((e) => e());
    }
    var ir = (e) => new Promise((o) => {
      e.onmessage = (p) => {
        var g = (p = p.data).Ra;
        if (p.Ta && p.Ta != Pt()) {
          var I = he[p.Ta];
          I ? I.postMessage(p, p.Xa) : A(`Internal error! Worker sent a message "${g}" to target pthread ${p.Ta}, but that thread no longer exists!`);
        } else g === "checkMailbox" ? Ye() : g === "spawnThread" ? rr(p) : g === "cleanupThread" ? sr(he[p.cb]) : g === "loaded" ? (e.loaded = true, o(e)) : p.target === "setimmediate" ? e.postMessage(p) : g === "callHandler" ? n[p.Ya](...p.args) : g && A(`worker sent an unknown command ${g}`);
      }, e.onerror = (p) => {
        throw A(`worker sent an error! ${p.filename}:${p.lineno}: ${p.message}`), p;
      };
      var u, l = [];
      for (u of []) n.propertyIsEnumerable(u) && l.push(u);
      e.postMessage({ Ra: "load", Za: l, fb: v, gb: U });
    });
    function ur() {
      var e = new Worker((() => {
        let o = URL;
        return import.meta.url > "file:" && import.meta.url < "file;" ? new o("ort.wasm.bundle.min.mjs", import.meta.url) : new URL(import.meta.url);
      })(), { type: "module", workerData: "em-pthread", name: "em-pthread" });
      de.push(e);
    }
    var fr, co = (e) => {
      ee();
      var o = Y()[e + 52 >>> 2 >>> 0];
      e = Y()[e + 56 >>> 2 >>> 0], Xr(o, o - e), Je(o);
    }, cr = [], lo = (e, o) => {
      _e = 0;
      var u = cr[e];
      u || (cr[e] = u = fr.get(e)), e = u(o), 0 < _e ? S = e : xt(e);
    };
    class po {
      constructor(o) {
        this.Ua = o - 24;
      }
    }
    function mo(e, o, u) {
      var l = new po(e >>>= 0);
      throw o >>>= 0, u >>>= 0, Y()[l.Ua + 16 >>> 2 >>> 0] = 0, Y()[l.Ua + 4 >>> 2 >>> 0] = o, Y()[l.Ua + 8 >>> 2 >>> 0] = u, e;
    }
    function lr(e, o, u, l) {
      return i ? R(2, 1, e, o, u, l) : dr(e, o, u, l);
    }
    function dr(e, o, u, l) {
      if (e >>>= 0, u >>>= 0, l >>>= 0, h === void 0) return 6;
      var p = [];
      return i && p.length === 0 ? lr(e, o >>>= 0, u, l) : (e = { ab: u, Qa: e, Va: l, Xa: p }, i ? (e.Ra = "spawnThread", postMessage(e, p), 0) : rr(e));
    }
    var pr = typeof TextDecoder < "u" ? new TextDecoder() : void 0, mr = (e, o = 0, u = NaN) => {
      var l = (o >>>= 0) + u;
      for (u = o; e[u] && !(u >= l); ) ++u;
      if (16 < u - o && e.buffer && pr) return pr.decode(e.buffer instanceof ArrayBuffer ? e.subarray(o, u) : e.slice(o, u));
      for (l = ""; o < u; ) {
        var p = e[o++];
        if (128 & p) {
          var g = 63 & e[o++];
          if ((224 & p) == 192) l += String.fromCharCode((31 & p) << 6 | g);
          else {
            var I = 63 & e[o++];
            65536 > (p = (240 & p) == 224 ? (15 & p) << 12 | g << 6 | I : (7 & p) << 18 | g << 12 | I << 6 | 63 & e[o++]) ? l += String.fromCharCode(p) : (p -= 65536, l += String.fromCharCode(55296 | p >> 10, 56320 | 1023 & p));
          }
        } else l += String.fromCharCode(p);
      }
      return l;
    }, At = (e, o) => (e >>>= 0) ? mr(K(), e, o) : "";
    function hr(e, o, u) {
      return i ? R(3, 1, e, o, u) : 0;
    }
    function wr(e, o) {
      if (i) return R(4, 1, e, o);
    }
    function br(e, o) {
      if (i) return R(5, 1, e, o);
    }
    function gr(e, o, u) {
      if (i) return R(6, 1, e, o, u);
    }
    function yr(e, o, u) {
      return i ? R(7, 1, e, o, u) : 0;
    }
    function Er(e, o) {
      if (i) return R(8, 1, e, o);
    }
    function Tr(e, o, u) {
      if (i) return R(9, 1, e, o, u);
    }
    function Sr(e, o, u, l) {
      if (i) return R(10, 1, e, o, u, l);
    }
    function Or(e, o, u, l) {
      if (i) return R(11, 1, e, o, u, l);
    }
    function vr(e, o, u, l) {
      if (i) return R(12, 1, e, o, u, l);
    }
    function Ar(e) {
      if (i) return R(13, 1, e);
    }
    function Ir(e, o) {
      if (i) return R(14, 1, e, o);
    }
    function _r(e, o, u) {
      if (i) return R(15, 1, e, o, u);
    }
    var ho = () => J("");
    function wo(e) {
      Ut(e >>> 0, !f, 1, !c, 131072, false), ar();
    }
    var Br = (e) => {
      if (!Q) try {
        if (e(), !(0 < _e)) try {
          i ? xt(S) : vt(S);
        } catch (o) {
          o instanceof Ie || o == "unwind" || b(0, o);
        }
      } catch (o) {
        o instanceof Ie || o == "unwind" || b(0, o);
      }
    };
    function It(e) {
      e >>>= 0, typeof Atomics.eb == "function" && (Atomics.eb(E(), e >>> 2, e).value.then(Ye), e += 128, Atomics.store(E(), e >>> 2, 1));
    }
    var Ye = () => {
      var e = Pt();
      e && (It(e), Br(Jr));
    };
    function bo(e, o) {
      (e >>>= 0) == o >>> 0 ? setTimeout(Ye) : i ? postMessage({ Ta: e, Ra: "checkMailbox" }) : (e = he[e]) && e.postMessage({ Ra: "checkMailbox" });
    }
    var _t = [];
    function go(e, o, u, l, p) {
      for (o >>>= 0, l /= 2, _t.length = l, u = p >>> 0 >>> 3, p = 0; p < l; p++) _t[p] = C[u + 2 * p] ? C[u + 2 * p + 1] : fe()[u + 2 * p + 1 >>> 0];
      return (o ? Hr[o] : Go[e])(..._t);
    }
    var yo = () => {
      _e = 0;
    };
    function Eo(e) {
      e >>>= 0, i ? postMessage({ Ra: "cleanupThread", cb: e }) : sr(he[e]);
    }
    function To(e) {
    }
    function So(e, o) {
      e = -9007199254740992 > e || 9007199254740992 < e ? NaN : Number(e), o >>>= 0, e = new Date(1e3 * e), E()[o >>> 2 >>> 0] = e.getUTCSeconds(), E()[o + 4 >>> 2 >>> 0] = e.getUTCMinutes(), E()[o + 8 >>> 2 >>> 0] = e.getUTCHours(), E()[o + 12 >>> 2 >>> 0] = e.getUTCDate(), E()[o + 16 >>> 2 >>> 0] = e.getUTCMonth(), E()[o + 20 >>> 2 >>> 0] = e.getUTCFullYear() - 1900, E()[o + 24 >>> 2 >>> 0] = e.getUTCDay(), e = (e.getTime() - Date.UTC(e.getUTCFullYear(), 0, 1, 0, 0, 0, 0)) / 864e5 | 0, E()[o + 28 >>> 2 >>> 0] = e;
    }
    var Lr = (e) => e % 4 == 0 && (e % 100 != 0 || e % 400 == 0), Dr = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335], Pr = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    function Oo(e, o) {
      e = -9007199254740992 > e || 9007199254740992 < e ? NaN : Number(e), o >>>= 0, e = new Date(1e3 * e), E()[o >>> 2 >>> 0] = e.getSeconds(), E()[o + 4 >>> 2 >>> 0] = e.getMinutes(), E()[o + 8 >>> 2 >>> 0] = e.getHours(), E()[o + 12 >>> 2 >>> 0] = e.getDate(), E()[o + 16 >>> 2 >>> 0] = e.getMonth(), E()[o + 20 >>> 2 >>> 0] = e.getFullYear() - 1900, E()[o + 24 >>> 2 >>> 0] = e.getDay();
      var u = (Lr(e.getFullYear()) ? Dr : Pr)[e.getMonth()] + e.getDate() - 1 | 0;
      E()[o + 28 >>> 2 >>> 0] = u, E()[o + 36 >>> 2 >>> 0] = -60 * e.getTimezoneOffset(), u = new Date(e.getFullYear(), 6, 1).getTimezoneOffset();
      var l = new Date(e.getFullYear(), 0, 1).getTimezoneOffset();
      e = 0 | (u != l && e.getTimezoneOffset() == Math.min(l, u)), E()[o + 32 >>> 2 >>> 0] = e;
    }
    function vo(e) {
      e >>>= 0;
      var o = new Date(E()[e + 20 >>> 2 >>> 0] + 1900, E()[e + 16 >>> 2 >>> 0], E()[e + 12 >>> 2 >>> 0], E()[e + 8 >>> 2 >>> 0], E()[e + 4 >>> 2 >>> 0], E()[e >>> 2 >>> 0], 0), u = E()[e + 32 >>> 2 >>> 0], l = o.getTimezoneOffset(), p = new Date(o.getFullYear(), 6, 1).getTimezoneOffset(), g = new Date(o.getFullYear(), 0, 1).getTimezoneOffset(), I = Math.min(g, p);
      return 0 > u ? E()[e + 32 >>> 2 >>> 0] = +(p != g && I == l) : 0 < u != (I == l) && (p = Math.max(g, p), o.setTime(o.getTime() + 6e4 * ((0 < u ? I : p) - l))), E()[e + 24 >>> 2 >>> 0] = o.getDay(), u = (Lr(o.getFullYear()) ? Dr : Pr)[o.getMonth()] + o.getDate() - 1 | 0, E()[e + 28 >>> 2 >>> 0] = u, E()[e >>> 2 >>> 0] = o.getSeconds(), E()[e + 4 >>> 2 >>> 0] = o.getMinutes(), E()[e + 8 >>> 2 >>> 0] = o.getHours(), E()[e + 12 >>> 2 >>> 0] = o.getDate(), E()[e + 16 >>> 2 >>> 0] = o.getMonth(), E()[e + 20 >>> 2 >>> 0] = o.getYear(), e = o.getTime(), BigInt(isNaN(e) ? -1 : e / 1e3);
    }
    function Ur(e, o, u, l, p, g, I) {
      return i ? R(16, 1, e, o, u, l, p, g, I) : -52;
    }
    function xr(e, o, u, l, p, g) {
      if (i) return R(17, 1, e, o, u, l, p, g);
    }
    var ke = {}, Ao = () => performance.timeOrigin + performance.now();
    function Cr(e, o) {
      if (i) return R(18, 1, e, o);
      if (ke[e] && (clearTimeout(ke[e].id), delete ke[e]), !o) return 0;
      var u = setTimeout(() => {
        delete ke[e], Br(() => qr(e, performance.timeOrigin + performance.now()));
      }, o);
      return ke[e] = { id: u, lb: o }, 0;
    }
    var Be = (e, o, u) => {
      var l = K();
      if (o >>>= 0, 0 < u) {
        var p = o;
        u = o + u - 1;
        for (var g = 0; g < e.length; ++g) {
          var I = e.charCodeAt(g);
          if (55296 <= I && 57343 >= I && (I = 65536 + ((1023 & I) << 10) | 1023 & e.charCodeAt(++g)), 127 >= I) {
            if (o >= u) break;
            l[o++ >>> 0] = I;
          } else {
            if (2047 >= I) {
              if (o + 1 >= u) break;
              l[o++ >>> 0] = 192 | I >> 6;
            } else {
              if (65535 >= I) {
                if (o + 2 >= u) break;
                l[o++ >>> 0] = 224 | I >> 12;
              } else {
                if (o + 3 >= u) break;
                l[o++ >>> 0] = 240 | I >> 18, l[o++ >>> 0] = 128 | I >> 12 & 63;
              }
              l[o++ >>> 0] = 128 | I >> 6 & 63;
            }
            l[o++ >>> 0] = 128 | 63 & I;
          }
        }
        l[o >>> 0] = 0, e = o - p;
      } else e = 0;
      return e;
    };
    function Io(e, o, u, l) {
      e >>>= 0, o >>>= 0, u >>>= 0, l >>>= 0;
      var p = (/* @__PURE__ */ new Date()).getFullYear(), g = new Date(p, 0, 1).getTimezoneOffset();
      p = new Date(p, 6, 1).getTimezoneOffset();
      var I = Math.max(g, p);
      Y()[e >>> 2 >>> 0] = 60 * I, E()[o >>> 2 >>> 0] = +(g != p), e = (o = (G) => {
        var H = Math.abs(G);
        return `UTC${0 <= G ? "-" : "+"}${String(Math.floor(H / 60)).padStart(2, "0")}${String(H % 60).padStart(2, "0")}`;
      })(g), o = o(p), p < g ? (Be(e, u, 17), Be(o, l, 17)) : (Be(e, l, 17), Be(o, u, 17));
    }
    var _o = () => Date.now(), Bo = 1;
    function Lo(e, o, u) {
      if (!(0 <= e && 3 >= e)) return 28;
      if (e === 0) e = Date.now();
      else {
        if (!Bo) return 52;
        e = performance.timeOrigin + performance.now();
      }
      return C[u >>> 0 >>> 3] = BigInt(Math.round(1e6 * e)), 0;
    }
    var Bt = [];
    function Do(e, o, u) {
      e >>>= 0, o >>>= 0, u >>>= 0, Bt.length = 0;
      for (var l; l = K()[o++ >>> 0]; ) {
        var p = l != 105;
        u += (p &= l != 112) && u % 8 ? 4 : 0, Bt.push(l == 112 ? Y()[u >>> 2 >>> 0] : l == 106 ? C[u >>> 3] : l == 105 ? E()[u >>> 2 >>> 0] : fe()[u >>> 3 >>> 0]), u += p ? 8 : 4;
      }
      return Hr[e](...Bt);
    }
    var Po = () => {
    };
    function Uo(e, o) {
      return A(At(e >>> 0, o >>> 0));
    }
    var xo = () => {
      throw _e += 1, "unwind";
    };
    function Co() {
      return 4294901760;
    }
    var Mo = () => navigator.hardwareConcurrency;
    function Ro() {
      return J("Cannot use emscripten_pc_get_function without -sUSE_OFFSET_CONVERTER"), 0;
    }
    function Fo(e) {
      e >>>= 0;
      var o = K().length;
      if (e <= o || 4294901760 < e) return false;
      for (var u = 1; 4 >= u; u *= 2) {
        var l = o * (1 + 0.2 / u);
        l = Math.min(l, e + 100663296);
        e: {
          l = (Math.min(4294901760, 65536 * Math.ceil(Math.max(e, l) / 65536)) - v.buffer.byteLength + 65535) / 65536 | 0;
          try {
            v.grow(l), ee();
            var p = 1;
            break e;
          } catch {
          }
          p = void 0;
        }
        if (p) return true;
      }
      return false;
    }
    var qe = () => (J("Cannot use convertFrameToPC (needed by __builtin_return_address) without -sUSE_OFFSET_CONVERTER"), 0), Le = {}, Mr = (e) => {
      e.forEach((o) => {
        var u = qe();
        u && (Le[u] = o);
      });
    };
    function No() {
      var e = Error().stack.toString().split(`
`);
      return e[0] == "Error" && e.shift(), Mr(e), Le.Wa = qe(), Le.$a = e, Le.Wa;
    }
    function ko(e, o, u) {
      if (e >>>= 0, o >>>= 0, Le.Wa == e) var l = Le.$a;
      else (l = Error().stack.toString().split(`
`))[0] == "Error" && l.shift(), Mr(l);
      for (var p = 3; l[p] && qe() != e; ) ++p;
      for (e = 0; e < u && l[e + p]; ++e) E()[o + 4 * e >>> 2 >>> 0] = qe();
      return e;
    }
    var Lt, Dt = {}, Rr = () => {
      if (!Lt) {
        var e, o = { USER: "web_user", LOGNAME: "web_user", PATH: "/", PWD: "/", HOME: "/home/web_user", LANG: (typeof navigator == "object" && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8", _: "./this.program" };
        for (e in Dt) Dt[e] === void 0 ? delete o[e] : o[e] = Dt[e];
        var u = [];
        for (e in o) u.push(`${e}=${o[e]}`);
        Lt = u;
      }
      return Lt;
    };
    function Fr(e, o) {
      if (i) return R(19, 1, e, o);
      e >>>= 0, o >>>= 0;
      var u, l = 0, p = 0;
      for (u of Rr()) {
        var g = o + l;
        Y()[e + p >>> 2 >>> 0] = g, l += Be(u, g, 1 / 0) + 1, p += 4;
      }
      return 0;
    }
    var Nr = (e) => {
      for (var o = 0, u = 0; u < e.length; ++u) {
        var l = e.charCodeAt(u);
        127 >= l ? o++ : 2047 >= l ? o += 2 : 55296 <= l && 57343 >= l ? (o += 4, ++u) : o += 3;
      }
      return o;
    };
    function kr(e, o) {
      if (i) return R(20, 1, e, o);
      e >>>= 0, o >>>= 0;
      var u = Rr();
      for (var l of (Y()[e >>> 2 >>> 0] = u.length, e = 0, u)) e += Nr(l) + 1;
      return Y()[o >>> 2 >>> 0] = e, 0;
    }
    function Wr(e) {
      return i ? R(21, 1, e) : 52;
    }
    function Gr(e, o, u, l) {
      return i ? R(22, 1, e, o, u, l) : 52;
    }
    function $r(e, o, u, l) {
      return i ? R(23, 1, e, o, u, l) : 70;
    }
    var Wo = [null, [], []];
    function zr(e, o, u, l) {
      if (i) return R(24, 1, e, o, u, l);
      o >>>= 0, u >>>= 0, l >>>= 0;
      for (var p = 0, g = 0; g < u; g++) {
        var I = Y()[o >>> 2 >>> 0], G = Y()[o + 4 >>> 2 >>> 0];
        o += 8;
        for (var H = 0; H < G; H++) {
          var q = e, We = K()[I + H >>> 0], Rt = Wo[q];
          We === 0 || We === 10 ? ((q === 1 ? Me : A)(mr(Rt)), Rt.length = 0) : Rt.push(We);
        }
        p += G;
      }
      return Y()[l >>> 2 >>> 0] = p, 0;
    }
    i || (function() {
      for (var e = n.numThreads - 1; e--; ) ur();
      St.push(() => {
        ie++, (function(o) {
          i ? o() : Promise.all(de.map(ir)).then(o);
        })(() => k());
      });
    })(), i || (v = new WebAssembly.Memory({ initial: 256, maximum: 65536, shared: true }), ee()), n.wasmBinary && (O = n.wasmBinary), n.stackSave = () => Mt(), n.stackRestore = (e) => Je(e), n.stackAlloc = (e) => Ct(e), n.setValue = function(e, o, u = "i8") {
      switch (u.endsWith("*") && (u = "*"), u) {
        case "i1":
        case "i8":
          Z()[e >>> 0] = o;
          break;
        case "i16":
          W()[e >>> 1 >>> 0] = o;
          break;
        case "i32":
          E()[e >>> 2 >>> 0] = o;
          break;
        case "i64":
          C[e >>> 3] = BigInt(o);
          break;
        case "float":
          Ae()[e >>> 2 >>> 0] = o;
          break;
        case "double":
          fe()[e >>> 3 >>> 0] = o;
          break;
        case "*":
          Y()[e >>> 2 >>> 0] = o;
          break;
        default:
          J(`invalid type for setValue: ${u}`);
      }
    }, n.getValue = function(e, o = "i8") {
      switch (o.endsWith("*") && (o = "*"), o) {
        case "i1":
        case "i8":
          return Z()[e >>> 0];
        case "i16":
          return W()[e >>> 1 >>> 0];
        case "i32":
          return E()[e >>> 2 >>> 0];
        case "i64":
          return C[e >>> 3];
        case "float":
          return Ae()[e >>> 2 >>> 0];
        case "double":
          return fe()[e >>> 3 >>> 0];
        case "*":
          return Y()[e >>> 2 >>> 0];
        default:
          J(`invalid type for getValue: ${o}`);
      }
    }, n.UTF8ToString = At, n.stringToUTF8 = Be, n.lengthBytesUTF8 = Nr;
    var Go = [Ot, nr, lr, hr, wr, br, gr, yr, Er, Tr, Sr, Or, vr, Ar, Ir, _r, Ur, xr, Cr, Fr, kr, Wr, Gr, $r, zr], Hr = { 853836: (e, o, u, l, p) => {
      if (n === void 0 || !n.Sa) return 1;
      if ((e = At(Number(e >>> 0))).startsWith("./") && (e = e.substring(2)), !(e = n.Sa.get(e))) return 2;
      if (o = Number(o >>> 0), u = Number(u >>> 0), l = Number(l >>> 0), o + u > e.byteLength) return 3;
      try {
        let g = e.subarray(o, o + u);
        switch (p) {
          case 0:
            K().set(g, l >>> 0);
            break;
          case 1:
            n.hb ? n.hb(l, g) : n.jb(l, g);
            break;
          default:
            return 4;
        }
        return 0;
      } catch {
        return 4;
      }
    }, 854660: () => typeof wasmOffsetConverter < "u" };
    function $o() {
      return typeof wasmOffsetConverter < "u";
    }
    var _ = await (async function() {
      function e(l, p) {
        return _ = l.exports, _ = (function() {
          var g = _, I = (H) => () => H() >>> 0, G = (H) => (q) => H(q) >>> 0;
          return (g = Object.assign({}, g)).Aa = I(g.Aa), g.Ca = G(g.Ca), g.Oa = G(g.Oa), g.Pa = I(g.Pa), g.__cxa_get_exception_ptr = G(g.__cxa_get_exception_ptr), g;
        })(), or.push(_.Da), fr = _.Ea, U = p, k(), _;
      }
      ie++;
      var o = me();
      if (n.instantiateWasm) return new Promise((l) => {
        n.instantiateWasm(o, (p, g) => {
          l(e(p, g));
        });
      });
      if (i) return new Promise((l) => {
        le = (p) => {
          var g = new WebAssembly.Instance(p, me());
          l(e(g, p));
        };
      });
      ne ??= n.locateFile ? n.locateFile ? n.locateFile("ort-wasm-simd-threaded.wasm", y) : y + "ort-wasm-simd-threaded.wasm" : new URL("ort-wasm-simd-threaded.wasm", import.meta.url).href;
      try {
        var u = await (async function(l) {
          var p = ne;
          if (!O && typeof WebAssembly.instantiateStreaming == "function" && !Re(p)) try {
            var g = fetch(p, { credentials: "same-origin" });
            return await WebAssembly.instantiateStreaming(g, l);
          } catch (I) {
            A(`wasm streaming compile failed: ${I}`), A("falling back to ArrayBuffer instantiation");
          }
          return (async function(I, G) {
            try {
              var H = await (async function(q) {
                if (!O) try {
                  var We = await d(q);
                  return new Uint8Array(We);
                } catch {
                }
                if (q == ne && O) q = new Uint8Array(O);
                else {
                  if (!m) throw "both async and sync fetching of the wasm failed";
                  q = m(q);
                }
                return q;
              })(I);
              return await WebAssembly.instantiate(H, G);
            } catch (q) {
              A(`failed to asynchronously prepare wasm: ${q}`), J(q);
            }
          })(p, l);
        })(o);
        return e(u.instance, u.module);
      } catch (l) {
        return s(l), Promise.reject(l);
      }
    })();
    n._OrtInit = (e, o) => (n._OrtInit = _.aa)(e, o), n._OrtGetLastError = (e, o) => (n._OrtGetLastError = _.ba)(e, o), n._OrtCreateSessionOptions = (e, o, u, l, p, g, I, G, H, q) => (n._OrtCreateSessionOptions = _.ca)(e, o, u, l, p, g, I, G, H, q), n._OrtAppendExecutionProvider = (e, o, u, l, p) => (n._OrtAppendExecutionProvider = _.da)(e, o, u, l, p), n._OrtAddFreeDimensionOverride = (e, o, u) => (n._OrtAddFreeDimensionOverride = _.ea)(e, o, u), n._OrtAddSessionConfigEntry = (e, o, u) => (n._OrtAddSessionConfigEntry = _.fa)(e, o, u), n._OrtReleaseSessionOptions = (e) => (n._OrtReleaseSessionOptions = _.ga)(e), n._OrtCreateSession = (e, o, u) => (n._OrtCreateSession = _.ha)(e, o, u), n._OrtReleaseSession = (e) => (n._OrtReleaseSession = _.ia)(e), n._OrtGetInputOutputCount = (e, o, u) => (n._OrtGetInputOutputCount = _.ja)(e, o, u), n._OrtGetInputOutputMetadata = (e, o, u, l) => (n._OrtGetInputOutputMetadata = _.ka)(e, o, u, l), n._OrtFree = (e) => (n._OrtFree = _.la)(e), n._OrtCreateTensor = (e, o, u, l, p, g) => (n._OrtCreateTensor = _.ma)(e, o, u, l, p, g), n._OrtGetTensorData = (e, o, u, l, p) => (n._OrtGetTensorData = _.na)(e, o, u, l, p), n._OrtReleaseTensor = (e) => (n._OrtReleaseTensor = _.oa)(e), n._OrtCreateRunOptions = (e, o, u, l) => (n._OrtCreateRunOptions = _.pa)(e, o, u, l), n._OrtAddRunConfigEntry = (e, o, u) => (n._OrtAddRunConfigEntry = _.qa)(e, o, u), n._OrtReleaseRunOptions = (e) => (n._OrtReleaseRunOptions = _.ra)(e), n._OrtCreateBinding = (e) => (n._OrtCreateBinding = _.sa)(e), n._OrtBindInput = (e, o, u) => (n._OrtBindInput = _.ta)(e, o, u), n._OrtBindOutput = (e, o, u, l) => (n._OrtBindOutput = _.ua)(e, o, u, l), n._OrtClearBoundOutputs = (e) => (n._OrtClearBoundOutputs = _.va)(e), n._OrtReleaseBinding = (e) => (n._OrtReleaseBinding = _.wa)(e), n._OrtRunWithBinding = (e, o, u, l, p) => (n._OrtRunWithBinding = _.xa)(e, o, u, l, p), n._OrtRun = (e, o, u, l, p, g, I, G) => (n._OrtRun = _.ya)(e, o, u, l, p, g, I, G), n._OrtEndProfiling = (e) => (n._OrtEndProfiling = _.za)(e);
    var Pt = () => (Pt = _.Aa)();
    n._free = (e) => (n._free = _.Ba)(e), n._malloc = (e) => (n._malloc = _.Ca)(e);
    var Ut = (e, o, u, l, p, g) => (Ut = _.Fa)(e, o, u, l, p, g), Vr = () => (Vr = _.Ga)(), jr = (e, o, u, l, p) => (jr = _.Ha)(e, o, u, l, p), Yr = (e) => (Yr = _.Ia)(e), xt = (e) => (xt = _.Ja)(e), qr = (e, o) => (qr = _.Ka)(e, o), Jr = () => (Jr = _.La)(), Xr = (e, o) => (Xr = _.Ma)(e, o), Je = (e) => (Je = _.Na)(e), Ct = (e) => (Ct = _.Oa)(e), Mt = () => (Mt = _.Pa)();
    return (function e() {
      if (0 < ie) N = e;
      else if (i) r(n), ae();
      else {
        for (; 0 < St.length; ) St.shift()(n);
        0 < ie ? N = e : (n.calledRun = true, Q || (ae(), r(n)));
      }
    })(), n.PTR_SIZE = 4, a;
  }, Xo = Un, Qo = globalThis.self?.name?.startsWith("em-pthread");
  Qo && Un();
});
var Fn;
var qt;
var Zo;
var te;
var Nn;
var Yt;
var Ko;
var es;
var kn;
var ts;
var Mn;
var Wn;
var Rn;
var Gn;
var tt = L(() => {
  "use strict";
  et();
  Fn = typeof location > "u" ? void 0 : location.origin, qt = import.meta.url > "file:" && import.meta.url < "file;", Zo = () => {
    if (true) {
      if (qt) {
        let t = URL;
        return new URL(new t("ort.wasm.bundle.min.mjs", import.meta.url).href, Fn).href;
      }
      return import.meta.url;
    }
  }, te = Zo(), Nn = () => {
    if (te && !te.startsWith("blob:")) return te.substring(0, te.lastIndexOf("/") + 1);
  }, Yt = (t, r) => {
    try {
      let s = r ?? te;
      return (s ? new URL(t, s) : new URL(t)).origin === Fn;
    } catch {
      return false;
    }
  }, Ko = (t, r) => {
    let s = r ?? te;
    try {
      return (s ? new URL(t, s) : new URL(t)).href;
    } catch {
      return;
    }
  }, es = (t, r) => `${r ?? "./"}${t}`, kn = async (t) => {
    let s = await (await fetch(t, { credentials: "same-origin" })).blob();
    return URL.createObjectURL(s);
  }, ts = async (t) => (await import(
    /*webpackIgnore:true*/
    t
  )).default, Mn = (Pn(), kt(Dn)).default, Wn = async () => {
    if (!te) throw new Error("Failed to load proxy worker: cannot determine the script source URL.");
    if (Yt(te)) return [void 0, Mn()];
    let t = await kn(te);
    return [t, Mn(t)];
  }, Rn = (Cn(), kt(xn)).default, Gn = async (t, r, s, n) => {
    let a = Rn && !(t || r);
    if (a) if (te) a = Yt(te);
    else if (n && !s) a = true;
    else throw new Error("cannot determine the script source URL.");
    if (a) return [void 0, Rn];
    {
      let c = "ort-wasm-simd-threaded.mjs", f = t ?? Ko(c, r), i = s && f && !Yt(f, r), d = i ? await kn(f) : f ?? es(c, r);
      return [i ? d : void 0, await ts(d)];
    }
  };
});
var Jt;
var Xt;
var ct;
var $n;
var rs;
var ns;
var os;
var rt;
var x;
var Se = L(() => {
  "use strict";
  tt();
  Xt = false, ct = false, $n = false, rs = () => {
    if (typeof SharedArrayBuffer > "u") return false;
    try {
      return typeof MessageChannel < "u" && new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)), WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 5, 4, 1, 3, 1, 1, 10, 11, 1, 9, 0, 65, 0, 254, 16, 2, 0, 26, 11]));
    } catch {
      return false;
    }
  }, ns = () => {
    try {
      return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 10, 30, 1, 28, 0, 65, 0, 253, 15, 253, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 253, 186, 1, 26, 11]));
    } catch {
      return false;
    }
  }, os = () => {
    try {
      return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 19, 1, 17, 0, 65, 1, 253, 15, 65, 2, 253, 15, 65, 3, 253, 15, 253, 147, 2, 11]));
    } catch {
      return false;
    }
  }, rt = async (t) => {
    if (Xt) return Promise.resolve();
    if (ct) throw new Error("multiple calls to 'initializeWebAssembly()' detected.");
    if ($n) throw new Error("previous call to 'initializeWebAssembly()' failed.");
    ct = true;
    let r = t.initTimeout, s = t.numThreads;
    if (t.simd !== false) {
      if (t.simd === "relaxed") {
        if (!os()) throw new Error("Relaxed WebAssembly SIMD is not supported in the current environment.");
      } else if (!ns()) throw new Error("WebAssembly SIMD is not supported in the current environment.");
    }
    let n = rs();
    s > 1 && !n && (typeof self < "u" && !self.crossOriginIsolated && console.warn("env.wasm.numThreads is set to " + s + ", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."), console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."), t.numThreads = s = 1);
    let a = t.wasmPaths, c = typeof a == "string" ? a : void 0, f = a?.mjs, i = f?.href ?? f, d = a?.wasm, m = d?.href ?? d, h = t.wasmBinary, [b, w] = await Gn(i, c, s > 1, !!h || !!m), y = false, O = [];
    if (r > 0 && O.push(new Promise((v) => {
      setTimeout(() => {
        y = true, v();
      }, r);
    })), O.push(new Promise((v, U) => {
      let S = { numThreads: s };
      if (h) S.wasmBinary = h;
      else if (m || c) S.locateFile = (T) => m ?? c + T;
      else if (i && i.indexOf("blob:") !== 0) S.locateFile = (T) => new URL(T, i).href;
      else if (b) {
        let T = Nn();
        T && (S.locateFile = (M) => T + M);
      }
      w(S).then((T) => {
        ct = false, Xt = true, Jt = T, v(), b && URL.revokeObjectURL(b);
      }, (T) => {
        ct = false, $n = true, U(T);
      });
    })), await Promise.race(O), y) throw new Error(`WebAssembly backend initializing failed due to timeout: ${r}ms`);
  }, x = () => {
    if (Xt && Jt) return Jt;
    throw new Error("WebAssembly is not initialized yet.");
  };
});
var re;
var He;
var P;
var lt = L(() => {
  "use strict";
  Se();
  re = (t, r) => {
    let s = x(), n = s.lengthBytesUTF8(t) + 1, a = s._malloc(n);
    return s.stringToUTF8(t, a, n), r.push(a), a;
  }, He = (t, r, s, n) => {
    if (typeof t == "object" && t !== null) {
      if (s.has(t)) throw new Error("Circular reference in options");
      s.add(t);
    }
    Object.entries(t).forEach(([a, c]) => {
      let f = r ? r + a : a;
      if (typeof c == "object") He(c, f + ".", s, n);
      else if (typeof c == "string" || typeof c == "number") n(f, c.toString());
      else if (typeof c == "boolean") n(f, c ? "1" : "0");
      else throw new Error(`Can't handle extra config type: ${typeof c}`);
    });
  }, P = (t) => {
    let r = x(), s = r.stackSave();
    try {
      let n = r.PTR_SIZE, a = r.stackAlloc(2 * n);
      r._OrtGetLastError(a, a + n);
      let c = Number(r.getValue(a, n === 4 ? "i32" : "i64")), f = r.getValue(a + n, "*"), i = f ? r.UTF8ToString(f) : "";
      throw new Error(`${t} ERROR_CODE: ${c}, ERROR_MESSAGE: ${i}`);
    } finally {
      r.stackRestore(s);
    }
  };
});
var zn;
var Hn = L(() => {
  "use strict";
  Se();
  lt();
  zn = (t) => {
    let r = x(), s = 0, n = [], a = t || {};
    try {
      if (t?.logSeverityLevel === void 0) a.logSeverityLevel = 2;
      else if (typeof t.logSeverityLevel != "number" || !Number.isInteger(t.logSeverityLevel) || t.logSeverityLevel < 0 || t.logSeverityLevel > 4) throw new Error(`log severity level is not valid: ${t.logSeverityLevel}`);
      if (t?.logVerbosityLevel === void 0) a.logVerbosityLevel = 0;
      else if (typeof t.logVerbosityLevel != "number" || !Number.isInteger(t.logVerbosityLevel)) throw new Error(`log verbosity level is not valid: ${t.logVerbosityLevel}`);
      t?.terminate === void 0 && (a.terminate = false);
      let c = 0;
      return t?.tag !== void 0 && (c = re(t.tag, n)), s = r._OrtCreateRunOptions(a.logSeverityLevel, a.logVerbosityLevel, !!a.terminate, c), s === 0 && P("Can't create run options."), t?.extra !== void 0 && He(t.extra, "", /* @__PURE__ */ new WeakSet(), (f, i) => {
        let d = re(f, n), m = re(i, n);
        r._OrtAddRunConfigEntry(s, d, m) !== 0 && P(`Can't set a run config entry: ${f} - ${i}.`);
      }), [s, n];
    } catch (c) {
      throw s !== 0 && r._OrtReleaseRunOptions(s), n.forEach((f) => r._free(f)), c;
    }
  };
});
var ss;
var as;
var is;
var dt;
var us;
var Vn;
var jn = L(() => {
  "use strict";
  Se();
  lt();
  ss = (t) => {
    switch (t) {
      case "disabled":
        return 0;
      case "basic":
        return 1;
      case "extended":
        return 2;
      case "layout":
        return 3;
      case "all":
        return 99;
      default:
        throw new Error(`unsupported graph optimization level: ${t}`);
    }
  }, as = (t) => {
    switch (t) {
      case "sequential":
        return 0;
      case "parallel":
        return 1;
      default:
        throw new Error(`unsupported execution mode: ${t}`);
    }
  }, is = (t) => {
    t.extra || (t.extra = {}), t.extra.session || (t.extra.session = {});
    let r = t.extra.session;
    r.use_ort_model_bytes_directly || (r.use_ort_model_bytes_directly = "1"), t.executionProviders && t.executionProviders.some((s) => (typeof s == "string" ? s : s.name) === "webgpu") && (t.enableMemPattern = false);
  }, dt = (t, r, s, n) => {
    let a = re(r, n), c = re(s, n);
    x()._OrtAddSessionConfigEntry(t, a, c) !== 0 && P(`Can't set a session config entry: ${r} - ${s}.`);
  }, us = async (t, r, s) => {
    for (let n of r) {
      let a = typeof n == "string" ? n : n.name, c = [];
      switch (a) {
        case "webnn":
          if (a = "WEBNN", typeof n != "string") {
            let b = n?.deviceType;
            b && dt(t, "deviceType", b, s);
          }
          break;
        case "webgpu":
          if (a = "JS", typeof n != "string") {
            let h = n;
            if (h?.preferredLayout) {
              if (h.preferredLayout !== "NCHW" && h.preferredLayout !== "NHWC") throw new Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${h.preferredLayout}`);
              dt(t, "preferredLayout", h.preferredLayout, s);
            }
          }
          break;
        case "wasm":
        case "cpu":
          continue;
        default:
          throw new Error(`not supported execution provider: ${a}`);
      }
      let f = re(a, s), i = c.length, d = 0, m = 0;
      if (i > 0) {
        d = x()._malloc(i * x().PTR_SIZE), s.push(d), m = x()._malloc(i * x().PTR_SIZE), s.push(m);
        for (let h = 0; h < i; h++) x().setValue(d + h * x().PTR_SIZE, c[h][0], "*"), x().setValue(m + h * x().PTR_SIZE, c[h][1], "*");
      }
      await x()._OrtAppendExecutionProvider(t, f, d, m, i) !== 0 && P(`Can't append execution provider: ${a}.`);
    }
  }, Vn = async (t) => {
    let r = x(), s = 0, n = [], a = t || {};
    is(a);
    try {
      let c = ss(a.graphOptimizationLevel ?? "all"), f = as(a.executionMode ?? "sequential"), i = typeof a.logId == "string" ? re(a.logId, n) : 0, d = a.logSeverityLevel ?? 2;
      if (!Number.isInteger(d) || d < 0 || d > 4) throw new Error(`log severity level is not valid: ${d}`);
      let m = a.logVerbosityLevel ?? 0;
      if (!Number.isInteger(m) || m < 0 || m > 4) throw new Error(`log verbosity level is not valid: ${m}`);
      let h = typeof a.optimizedModelFilePath == "string" ? re(a.optimizedModelFilePath, n) : 0;
      if (s = r._OrtCreateSessionOptions(c, !!a.enableCpuMemArena, !!a.enableMemPattern, f, !!a.enableProfiling, 0, i, d, m, h), s === 0 && P("Can't create session options."), a.executionProviders && await us(s, a.executionProviders, n), a.enableGraphCapture !== void 0) {
        if (typeof a.enableGraphCapture != "boolean") throw new Error(`enableGraphCapture must be a boolean value: ${a.enableGraphCapture}`);
        dt(s, "enableGraphCapture", a.enableGraphCapture.toString(), n);
      }
      if (a.freeDimensionOverrides) for (let [b, w] of Object.entries(a.freeDimensionOverrides)) {
        if (typeof b != "string") throw new Error(`free dimension override name must be a string: ${b}`);
        if (typeof w != "number" || !Number.isInteger(w) || w < 0) throw new Error(`free dimension override value must be a non-negative integer: ${w}`);
        let y = re(b, n);
        r._OrtAddFreeDimensionOverride(s, y, w) !== 0 && P(`Can't set a free dimension override: ${b} - ${w}.`);
      }
      return a.extra !== void 0 && He(a.extra, "", /* @__PURE__ */ new WeakSet(), (b, w) => {
        dt(s, b, w, n);
      }), [s, n];
    } catch (c) {
      throw s !== 0 && r._OrtReleaseSessionOptions(s) !== 0 && P("Can't release session options."), n.forEach((f) => r._free(f)), c;
    }
  };
});
var De;
var pt;
var Pe;
var Yn;
var qn;
var mt;
var ht;
var Jn;
var Qt = L(() => {
  "use strict";
  De = (t) => {
    switch (t) {
      case "int8":
        return 3;
      case "uint8":
        return 2;
      case "bool":
        return 9;
      case "int16":
        return 5;
      case "uint16":
        return 4;
      case "int32":
        return 6;
      case "uint32":
        return 12;
      case "float16":
        return 10;
      case "float32":
        return 1;
      case "float64":
        return 11;
      case "string":
        return 8;
      case "int64":
        return 7;
      case "uint64":
        return 13;
      case "int4":
        return 22;
      case "uint4":
        return 21;
      default:
        throw new Error(`unsupported data type: ${t}`);
    }
  }, pt = (t) => {
    switch (t) {
      case 3:
        return "int8";
      case 2:
        return "uint8";
      case 9:
        return "bool";
      case 5:
        return "int16";
      case 4:
        return "uint16";
      case 6:
        return "int32";
      case 12:
        return "uint32";
      case 10:
        return "float16";
      case 1:
        return "float32";
      case 11:
        return "float64";
      case 8:
        return "string";
      case 7:
        return "int64";
      case 13:
        return "uint64";
      case 22:
        return "int4";
      case 21:
        return "uint4";
      default:
        throw new Error(`unsupported data type: ${t}`);
    }
  }, Pe = (t, r) => {
    let s = [-1, 4, 1, 1, 2, 2, 4, 8, -1, 1, 2, 8, 4, 8, -1, -1, -1, -1, -1, -1, -1, 0.5, 0.5][t], n = typeof r == "number" ? r : r.reduce((a, c) => a * c, 1);
    return s > 0 ? Math.ceil(n * s) : void 0;
  }, Yn = (t) => {
    switch (t) {
      case "float16":
        return typeof Float16Array < "u" && Float16Array.from ? Float16Array : Uint16Array;
      case "float32":
        return Float32Array;
      case "uint8":
        return Uint8Array;
      case "int8":
        return Int8Array;
      case "uint16":
        return Uint16Array;
      case "int16":
        return Int16Array;
      case "int32":
        return Int32Array;
      case "bool":
        return Uint8Array;
      case "float64":
        return Float64Array;
      case "uint32":
        return Uint32Array;
      case "int64":
        return BigInt64Array;
      case "uint64":
        return BigUint64Array;
      default:
        throw new Error(`unsupported type: ${t}`);
    }
  }, qn = (t) => {
    switch (t) {
      case "verbose":
        return 0;
      case "info":
        return 1;
      case "warning":
        return 2;
      case "error":
        return 3;
      case "fatal":
        return 4;
      default:
        throw new Error(`unsupported logging level: ${t}`);
    }
  }, mt = (t) => t === "float32" || t === "float16" || t === "int32" || t === "int64" || t === "uint32" || t === "uint8" || t === "bool" || t === "uint4" || t === "int4", ht = (t) => t === "float32" || t === "float16" || t === "int32" || t === "int64" || t === "uint32" || t === "uint64" || t === "int8" || t === "uint8" || t === "bool" || t === "uint4" || t === "int4", Jn = (t) => {
    switch (t) {
      case "none":
        return 0;
      case "cpu":
        return 1;
      case "cpu-pinned":
        return 2;
      case "texture":
        return 3;
      case "gpu-buffer":
        return 4;
      case "ml-tensor":
        return 5;
      default:
        throw new Error(`unsupported data location: ${t}`);
    }
  };
});
var Ve;
var Zt = L(() => {
  "use strict";
  et();
  Ve = async (t) => {
    if (typeof t == "string") if (false) try {
      let { readFile: r } = Nt("node:fs/promises");
      return new Uint8Array(await r(t));
    } catch (r) {
      if (r.code === "ERR_FS_FILE_TOO_LARGE") {
        let { createReadStream: s } = Nt("node:fs"), n = s(t), a = [];
        for await (let c of n) a.push(c);
        return new Uint8Array(Buffer.concat(a));
      }
      throw r;
    }
    else {
      let r = await fetch(t);
      if (!r.ok) throw new Error(`failed to load external data file: ${t}`);
      let s = r.headers.get("Content-Length"), n = s ? parseInt(s, 10) : 0;
      if (n < 1073741824) return new Uint8Array(await r.arrayBuffer());
      {
        if (!r.body) throw new Error(`failed to load external data file: ${t}, no response body.`);
        let a = r.body.getReader(), c;
        try {
          c = new ArrayBuffer(n);
        } catch (i) {
          if (i instanceof RangeError) {
            let d = Math.ceil(n / 65536);
            c = new WebAssembly.Memory({ initial: d, maximum: d }).buffer;
          } else throw i;
        }
        let f = 0;
        for (; ; ) {
          let { done: i, value: d } = await a.read();
          if (i) break;
          let m = d.byteLength;
          new Uint8Array(c, f, m).set(d), f += m;
        }
        return new Uint8Array(c, 0, n);
      }
    }
    else return t instanceof Blob ? new Uint8Array(await t.arrayBuffer()) : t instanceof Uint8Array ? t : new Uint8Array(t);
  };
});
var fs;
var nt;
var ot;
var Ue;
var cs;
var Xn;
var ze;
var st;
var at;
var Qn;
var it;
var ut;
var ft;
var jt = L(() => {
  "use strict";
  pe();
  Hn();
  jn();
  Qt();
  Se();
  lt();
  Zt();
  fs = (t, r) => {
    x()._OrtInit(t, r) !== 0 && P("Can't initialize onnxruntime.");
  }, nt = async (t) => {
    fs(t.wasm.numThreads, qn(t.logLevel));
  }, ot = async (t, r) => {
    x().asyncInit?.();
    let s = t.webgpu.adapter;
    if (r === "webgpu") {
      if (typeof navigator > "u" || !navigator.gpu) throw new Error("WebGPU is not supported in current environment");
      if (s) {
        if (typeof s.limits != "object" || typeof s.features != "object" || typeof s.requestDevice != "function") throw new Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.");
      } else {
        let n = t.webgpu.powerPreference;
        if (n !== void 0 && n !== "low-power" && n !== "high-performance") throw new Error(`Invalid powerPreference setting: "${n}"`);
        let a = t.webgpu.forceFallbackAdapter;
        if (a !== void 0 && typeof a != "boolean") throw new Error(`Invalid forceFallbackAdapter setting: "${a}"`);
        if (s = await navigator.gpu.requestAdapter({ powerPreference: n, forceFallbackAdapter: a }), !s) throw new Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.');
      }
    }
    if (r === "webnn" && (typeof navigator > "u" || !navigator.ml)) throw new Error("WebNN is not supported in current environment");
  }, Ue = /* @__PURE__ */ new Map(), cs = (t) => {
    let r = x(), s = r.stackSave();
    try {
      let n = r.PTR_SIZE, a = r.stackAlloc(2 * n);
      r._OrtGetInputOutputCount(t, a, a + n) !== 0 && P("Can't get session input/output count.");
      let f = n === 4 ? "i32" : "i64";
      return [Number(r.getValue(a, f)), Number(r.getValue(a + n, f))];
    } finally {
      r.stackRestore(s);
    }
  }, Xn = (t, r) => {
    let s = x(), n = s.stackSave(), a = 0;
    try {
      let c = s.PTR_SIZE, f = s.stackAlloc(2 * c);
      s._OrtGetInputOutputMetadata(t, r, f, f + c) !== 0 && P("Can't get session input/output metadata.");
      let d = Number(s.getValue(f, "*"));
      a = Number(s.getValue(f + c, "*"));
      let m = s.HEAP32[a / 4];
      if (m === 0) return [d, 0];
      let h = s.HEAPU32[a / 4 + 1], b = [];
      for (let w = 0; w < h; w++) {
        let y = Number(s.getValue(a + 8 + w * c, "*"));
        b.push(y !== 0 ? s.UTF8ToString(y) : Number(s.getValue(a + 8 + (w + h) * c, "*")));
      }
      return [d, m, b];
    } finally {
      s.stackRestore(n), a !== 0 && s._OrtFree(a);
    }
  }, ze = (t) => {
    let r = x(), s = r._malloc(t.byteLength);
    if (s === 0) throw new Error(`Can't create a session. failed to allocate a buffer of size ${t.byteLength}.`);
    return r.HEAPU8.set(t, s), [s, t.byteLength];
  }, st = async (t, r) => {
    let s, n, a = x();
    Array.isArray(t) ? [s, n] = t : t.buffer === a.HEAPU8.buffer ? [s, n] = [t.byteOffset, t.byteLength] : [s, n] = ze(t);
    let c = 0, f = 0, i = 0, d = [], m = [], h = [];
    try {
      if ([f, d] = await Vn(r), r?.externalData && a.mountExternalData) {
        let B = [];
        for (let D of r.externalData) {
          let $ = typeof D == "string" ? D : D.path;
          B.push(Ve(typeof D == "string" ? D : D.data).then((V) => {
            a.mountExternalData($, V);
          }));
        }
        await Promise.all(B);
      }
      for (let B of r?.executionProviders ?? []) if ((typeof B == "string" ? B : B.name) === "webnn") {
        if (a.shouldTransferToMLTensor = false, typeof B != "string") {
          let $ = B, V = $?.context, C = $?.gpuDevice, ce = $?.deviceType, le = $?.powerPreference;
          V ? a.currentContext = V : C ? a.currentContext = await a.webnnCreateMLContext(C) : a.currentContext = await a.webnnCreateMLContext({ deviceType: ce, powerPreference: le });
        } else a.currentContext = await a.webnnCreateMLContext();
        break;
      }
      c = await a._OrtCreateSession(s, n, f), a.webgpuOnCreateSession?.(c), c === 0 && P("Can't create a session."), a.jsepOnCreateSession?.(), a.currentContext && (a.webnnRegisterMLContext(c, a.currentContext), a.currentContext = void 0, a.shouldTransferToMLTensor = true);
      let [b, w] = cs(c), y = !!r?.enableGraphCapture, O = [], v = [], U = [], S = [], T = [];
      for (let B = 0; B < b; B++) {
        let [D, $, V] = Xn(c, B);
        D === 0 && P("Can't get an input name."), m.push(D);
        let C = a.UTF8ToString(D);
        O.push(C), U.push($ === 0 ? { name: C, isTensor: false } : { name: C, isTensor: true, type: pt($), shape: V });
      }
      for (let B = 0; B < w; B++) {
        let [D, $, V] = Xn(c, B + b);
        D === 0 && P("Can't get an output name."), h.push(D);
        let C = a.UTF8ToString(D);
        v.push(C), S.push($ === 0 ? { name: C, isTensor: false } : { name: C, isTensor: true, type: pt($), shape: V });
      }
      return Ue.set(c, [c, m, h, null, y, false]), [c, O, v, U, S];
    } catch (b) {
      throw m.forEach((w) => a._OrtFree(w)), h.forEach((w) => a._OrtFree(w)), i !== 0 && a._OrtReleaseBinding(i) !== 0 && P("Can't release IO binding."), c !== 0 && a._OrtReleaseSession(c) !== 0 && P("Can't release session."), b;
    } finally {
      a._free(s), f !== 0 && a._OrtReleaseSessionOptions(f) !== 0 && P("Can't release session options."), d.forEach((b) => a._free(b)), a.unmountExternalData?.();
    }
  }, at = (t) => {
    let r = x(), s = Ue.get(t);
    if (!s) throw new Error(`cannot release session. invalid session id: ${t}`);
    let [n, a, c, f, i] = s;
    f && (i && r._OrtClearBoundOutputs(f.handle) !== 0 && P("Can't clear bound outputs."), r._OrtReleaseBinding(f.handle) !== 0 && P("Can't release IO binding.")), r.jsepOnReleaseSession?.(t), r.webnnOnReleaseSession?.(t), r.webgpuOnReleaseSession?.(t), a.forEach((d) => r._OrtFree(d)), c.forEach((d) => r._OrtFree(d)), r._OrtReleaseSession(n) !== 0 && P("Can't release session."), Ue.delete(t);
  }, Qn = async (t, r, s, n, a, c, f = false) => {
    if (!t) {
      r.push(0);
      return;
    }
    let i = x(), d = i.PTR_SIZE, m = t[0], h = t[1], b = t[3], w = b, y, O;
    if (m === "string" && (b === "gpu-buffer" || b === "ml-tensor")) throw new Error("String tensor is not supported on GPU.");
    if (f && b !== "gpu-buffer") throw new Error(`External buffer must be provided for input/output index ${c} when enableGraphCapture is true.`);
    if (b === "gpu-buffer") {
      let S = t[2].gpuBuffer;
      O = Pe(De(m), h);
      {
        let T = i.jsepRegisterBuffer;
        if (!T) throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');
        y = T(n, c, S, O);
      }
    } else if (b === "ml-tensor") {
      let S = t[2].mlTensor;
      O = Pe(De(m), h);
      let T = i.webnnRegisterMLTensor;
      if (!T) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
      y = T(n, S, De(m), h);
    } else {
      let S = t[2];
      if (Array.isArray(S)) {
        O = d * S.length, y = i._malloc(O), s.push(y);
        for (let T = 0; T < S.length; T++) {
          if (typeof S[T] != "string") throw new TypeError(`tensor data at index ${T} is not a string`);
          i.setValue(y + T * d, re(S[T], s), "*");
        }
      } else {
        let T = i.webnnIsGraphInput, M = i.webnnIsGraphOutput;
        if (m !== "string" && T && M) {
          let B = i.UTF8ToString(a);
          if (T(n, B) || M(n, B)) {
            let D = De(m);
            O = Pe(D, h), w = "ml-tensor";
            let $ = i.webnnCreateTemporaryTensor, V = i.webnnUploadTensor;
            if (!$ || !V) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
            let C = await $(n, D, h);
            V(C, new Uint8Array(S.buffer, S.byteOffset, S.byteLength)), y = C;
          } else O = S.byteLength, y = i._malloc(O), s.push(y), i.HEAPU8.set(new Uint8Array(S.buffer, S.byteOffset, O), y);
        } else O = S.byteLength, y = i._malloc(O), s.push(y), i.HEAPU8.set(new Uint8Array(S.buffer, S.byteOffset, O), y);
      }
    }
    let v = i.stackSave(), U = i.stackAlloc(4 * h.length);
    try {
      h.forEach((T, M) => i.setValue(U + M * d, T, d === 4 ? "i32" : "i64"));
      let S = i._OrtCreateTensor(De(m), y, O, U, h.length, Jn(w));
      S === 0 && P(`Can't create tensor for input/output. session=${n}, index=${c}.`), r.push(S);
    } finally {
      i.stackRestore(v);
    }
  }, it = async (t, r, s, n, a, c) => {
    let f = x(), i = f.PTR_SIZE, d = Ue.get(t);
    if (!d) throw new Error(`cannot run inference. invalid session id: ${t}`);
    let m = d[0], h = d[1], b = d[2], w = d[3], y = d[4], O = d[5], v = r.length, U = n.length, S = 0, T = [], M = [], B = [], D = [], $ = f.stackSave(), V = f.stackAlloc(v * i), C = f.stackAlloc(v * i), ce = f.stackAlloc(U * i), le = f.stackAlloc(U * i);
    try {
      [S, T] = zn(c), Ee("wasm prepareInputOutputTensor");
      for (let A = 0; A < v; A++) await Qn(s[A], M, D, t, h[r[A]], r[A], y);
      for (let A = 0; A < U; A++) await Qn(a[A], B, D, t, b[n[A]], v + n[A], y);
      Te("wasm prepareInputOutputTensor");
      for (let A = 0; A < v; A++) f.setValue(V + A * i, M[A], "*"), f.setValue(C + A * i, h[r[A]], "*");
      for (let A = 0; A < U; A++) f.setValue(ce + A * i, B[A], "*"), f.setValue(le + A * i, b[n[A]], "*");
      f.jsepOnRunStart?.(m), f.webnnOnRunStart?.(m);
      let X;
      X = await f._OrtRun(m, C, V, v, le, U, ce, S), X !== 0 && P("failed to call OrtRun().");
      let se = [], Me = [];
      Ee("wasm ProcessOutputTensor");
      for (let A = 0; A < U; A++) {
        let Q = Number(f.getValue(ce + A * i, "*"));
        if (Q === B[A]) {
          se.push(a[A]);
          continue;
        }
        let Re = f.stackSave(), Z = f.stackAlloc(4 * i), K = false, W, E = 0;
        try {
          f._OrtGetTensorData(Q, Z, Z + i, Z + 2 * i, Z + 3 * i) !== 0 && P(`Can't access output tensor data on index ${A}.`);
          let Ae = i === 4 ? "i32" : "i64", fe = Number(f.getValue(Z, Ae));
          E = f.getValue(Z + i, "*");
          let Fe = f.getValue(Z + i * 2, "*"), ee = Number(f.getValue(Z + i * 3, Ae)), ae = [];
          for (let N = 0; N < ee; N++) ae.push(Number(f.getValue(Fe + N * i, Ae)));
          f._OrtFree(Fe) !== 0 && P("Can't free memory for tensor dims.");
          let ne = ae.reduce((N, k) => N * k, 1);
          W = pt(fe);
          let ie = w?.outputPreferredLocations[n[A]];
          if (W === "string") {
            if (ie === "gpu-buffer" || ie === "ml-tensor") throw new Error("String tensor is not supported on GPU.");
            let N = [];
            for (let k = 0; k < ne; k++) {
              let J = f.getValue(E + k * i, "*"), me = f.getValue(E + (k + 1) * i, "*"), Ie = k === ne - 1 ? void 0 : me - J;
              N.push(f.UTF8ToString(J, Ie));
            }
            se.push([W, ae, N, "cpu"]);
          } else if (ie === "gpu-buffer" && ne > 0) {
            let N = f.jsepGetBuffer;
            if (!N) throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');
            let k = N(E), J = Pe(fe, ne);
            if (J === void 0 || !mt(W)) throw new Error(`Unsupported data type: ${W}`);
            K = true, se.push([W, ae, { gpuBuffer: k, download: f.jsepCreateDownloader(k, J, W), dispose: () => {
              f._OrtReleaseTensor(Q) !== 0 && P("Can't release tensor.");
            } }, "gpu-buffer"]);
          } else if (ie === "ml-tensor" && ne > 0) {
            let N = f.webnnEnsureTensor, k = f.webnnIsGraphInputOutputTypeSupported;
            if (!N || !k) throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');
            if (Pe(fe, ne) === void 0 || !ht(W)) throw new Error(`Unsupported data type: ${W}`);
            if (!k(t, W, false)) throw new Error(`preferredLocation "ml-tensor" for ${W} output is not supported by current WebNN Context.`);
            let me = await N(t, E, fe, ae, false);
            K = true, se.push([W, ae, { mlTensor: me, download: f.webnnCreateMLTensorDownloader(E, W), dispose: () => {
              f.webnnReleaseTensorId(E), f._OrtReleaseTensor(Q);
            } }, "ml-tensor"]);
          } else if (ie === "ml-tensor-cpu-output" && ne > 0) {
            let N = f.webnnCreateMLTensorDownloader(E, W)(), k = se.length;
            K = true, Me.push((async () => {
              let J = [k, await N];
              return f.webnnReleaseTensorId(E), f._OrtReleaseTensor(Q), J;
            })()), se.push([W, ae, [], "cpu"]);
          } else {
            let N = Yn(W), k = new N(ne);
            new Uint8Array(k.buffer, k.byteOffset, k.byteLength).set(f.HEAPU8.subarray(E, E + k.byteLength)), se.push([W, ae, k, "cpu"]);
          }
        } finally {
          f.stackRestore(Re), W === "string" && E && f._free(E), K || f._OrtReleaseTensor(Q);
        }
      }
      w && !y && (f._OrtClearBoundOutputs(w.handle) !== 0 && P("Can't clear bound outputs."), Ue.set(t, [m, h, b, w, y, false]));
      for (let [A, Q] of await Promise.all(Me)) se[A][2] = Q;
      return Te("wasm ProcessOutputTensor"), se;
    } finally {
      f.webnnOnRunEnd?.(m), f.stackRestore($), M.forEach((X) => f._OrtReleaseTensor(X)), B.forEach((X) => f._OrtReleaseTensor(X)), D.forEach((X) => f._free(X)), S !== 0 && f._OrtReleaseRunOptions(S), T.forEach((X) => f._free(X));
    }
  }, ut = (t) => {
    let r = x(), s = Ue.get(t);
    if (!s) throw new Error("invalid session id");
    let n = s[0], a = r._OrtEndProfiling(n);
    a === 0 && P("Can't get an profile file name."), r._OrtFree(a);
  }, ft = (t) => {
    let r = [];
    for (let s of t) {
      let n = s[2];
      !Array.isArray(n) && "buffer" in n && r.push(n.buffer);
    }
    return r;
  };
});
var ve;
var oe;
var je;
var bt;
var gt;
var wt;
var Kt;
var er;
var xe;
var Ce;
var ds;
var Zn;
var Kn;
var eo;
var to;
var ro;
var no;
var oo;
var tr = L(() => {
  "use strict";
  pe();
  jt();
  Se();
  tt();
  ve = () => !!F.wasm.proxy && typeof document < "u", je = false, bt = false, gt = false, er = /* @__PURE__ */ new Map(), xe = (t, r) => {
    let s = er.get(t);
    s ? s.push(r) : er.set(t, [r]);
  }, Ce = () => {
    if (je || !bt || gt || !oe) throw new Error("worker not ready");
  }, ds = (t) => {
    switch (t.data.type) {
      case "init-wasm":
        je = false, t.data.err ? (gt = true, Kt[1](t.data.err)) : (bt = true, Kt[0]()), wt && (URL.revokeObjectURL(wt), wt = void 0);
        break;
      case "init-ep":
      case "copy-from":
      case "create":
      case "release":
      case "run":
      case "end-profiling": {
        let r = er.get(t.data.type);
        t.data.err ? r.shift()[1](t.data.err) : r.shift()[0](t.data.out);
        break;
      }
      default:
    }
  }, Zn = async () => {
    if (!bt) {
      if (je) throw new Error("multiple calls to 'initWasm()' detected.");
      if (gt) throw new Error("previous call to 'initWasm()' failed.");
      if (je = true, ve()) return new Promise((t, r) => {
        oe?.terminate(), Wn().then(([s, n]) => {
          try {
            oe = n, oe.onerror = (c) => r(c), oe.onmessage = ds, Kt = [t, r];
            let a = { type: "init-wasm", in: F };
            !a.in.wasm.wasmPaths && (s || qt) && (a.in.wasm.wasmPaths = { wasm: new URL("ort-wasm-simd-threaded.wasm", import.meta.url).href }), oe.postMessage(a), wt = s;
          } catch (a) {
            r(a);
          }
        }, r);
      });
      try {
        await rt(F.wasm), await nt(F), bt = true;
      } catch (t) {
        throw gt = true, t;
      } finally {
        je = false;
      }
    }
  }, Kn = async (t) => {
    if (ve()) return Ce(), new Promise((r, s) => {
      xe("init-ep", [r, s]);
      let n = { type: "init-ep", in: { epName: t, env: F } };
      oe.postMessage(n);
    });
    await ot(F, t);
  }, eo = async (t) => ve() ? (Ce(), new Promise((r, s) => {
    xe("copy-from", [r, s]);
    let n = { type: "copy-from", in: { buffer: t } };
    oe.postMessage(n, [t.buffer]);
  })) : ze(t), to = async (t, r) => {
    if (ve()) {
      if (r?.preferredOutputLocation) throw new Error('session option "preferredOutputLocation" is not supported for proxy.');
      return Ce(), new Promise((s, n) => {
        xe("create", [s, n]);
        let a = { type: "create", in: { model: t, options: { ...r } } }, c = [];
        t instanceof Uint8Array && c.push(t.buffer), oe.postMessage(a, c);
      });
    } else return st(t, r);
  }, ro = async (t) => {
    if (ve()) return Ce(), new Promise((r, s) => {
      xe("release", [r, s]);
      let n = { type: "release", in: t };
      oe.postMessage(n);
    });
    at(t);
  }, no = async (t, r, s, n, a, c) => {
    if (ve()) {
      if (s.some((f) => f[3] !== "cpu")) throw new Error("input tensor on GPU is not supported for proxy.");
      if (a.some((f) => f)) throw new Error("pre-allocated output tensor is not supported for proxy.");
      return Ce(), new Promise((f, i) => {
        xe("run", [f, i]);
        let d = s, m = { type: "run", in: { sessionId: t, inputIndices: r, inputs: d, outputIndices: n, options: c } };
        oe.postMessage(m, ft(d));
      });
    } else return it(t, r, s, n, a, c);
  }, oo = async (t) => {
    if (ve()) return Ce(), new Promise((r, s) => {
      xe("end-profiling", [r, s]);
      let n = { type: "end-profiling", in: t };
      oe.postMessage(n);
    });
    ut(t);
  };
});
var so;
var ps;
var yt;
var ao = L(() => {
  "use strict";
  pe();
  tr();
  Qt();
  et();
  Zt();
  so = (t, r) => {
    switch (t.location) {
      case "cpu":
        return [t.type, t.dims, t.data, "cpu"];
      case "gpu-buffer":
        return [t.type, t.dims, { gpuBuffer: t.gpuBuffer }, "gpu-buffer"];
      case "ml-tensor":
        return [t.type, t.dims, { mlTensor: t.mlTensor }, "ml-tensor"];
      default:
        throw new Error(`invalid data location: ${t.location} for ${r()}`);
    }
  }, ps = (t) => {
    switch (t[3]) {
      case "cpu":
        return new ue(t[0], t[2], t[1]);
      case "gpu-buffer": {
        let r = t[0];
        if (!mt(r)) throw new Error(`not supported data type: ${r} for deserializing GPU tensor`);
        let { gpuBuffer: s, download: n, dispose: a } = t[2];
        return ue.fromGpuBuffer(s, { dataType: r, dims: t[1], download: n, dispose: a });
      }
      case "ml-tensor": {
        let r = t[0];
        if (!ht(r)) throw new Error(`not supported data type: ${r} for deserializing MLTensor tensor`);
        let { mlTensor: s, download: n, dispose: a } = t[2];
        return ue.fromMLTensor(s, { dataType: r, dims: t[1], download: n, dispose: a });
      }
      default:
        throw new Error(`invalid data location: ${t[3]}`);
    }
  }, yt = class {
    async fetchModelAndCopyToWasmMemory(r) {
      return eo(await Ve(r));
    }
    async loadModel(r, s) {
      ge();
      let n;
      typeof r == "string" ? n = await this.fetchModelAndCopyToWasmMemory(r) : n = r, [this.sessionId, this.inputNames, this.outputNames, this.inputMetadata, this.outputMetadata] = await to(n, s), ye();
    }
    async dispose() {
      return ro(this.sessionId);
    }
    async run(r, s, n) {
      ge();
      let a = [], c = [];
      Object.entries(r).forEach((w) => {
        let y = w[0], O = w[1], v = this.inputNames.indexOf(y);
        if (v === -1) throw new Error(`invalid input '${y}'`);
        a.push(O), c.push(v);
      });
      let f = [], i = [];
      Object.entries(s).forEach((w) => {
        let y = w[0], O = w[1], v = this.outputNames.indexOf(y);
        if (v === -1) throw new Error(`invalid output '${y}'`);
        f.push(O), i.push(v);
      });
      let d = a.map((w, y) => so(w, () => `input "${this.inputNames[c[y]]}"`)), m = f.map((w, y) => w ? so(w, () => `output "${this.outputNames[i[y]]}"`) : null), h = await no(this.sessionId, c, d, i, m, n), b = {};
      for (let w = 0; w < h.length; w++) b[this.outputNames[i[w]]] = f[w] ?? ps(h[w]);
      return ye(), b;
    }
    startProfiling() {
    }
    endProfiling() {
      oo(this.sessionId);
    }
  };
});
var uo = {};
Xe(uo, { OnnxruntimeWebAssemblyBackend: () => Et, initializeFlags: () => io, wasmBackend: () => ms });
var io;
var Et;
var ms;
var fo = L(() => {
  "use strict";
  pe();
  tr();
  ao();
  io = () => {
    (typeof F.wasm.initTimeout != "number" || F.wasm.initTimeout < 0) && (F.wasm.initTimeout = 0);
    let t = F.wasm.simd;
    if (typeof t != "boolean" && t !== void 0 && t !== "fixed" && t !== "relaxed" && (console.warn(`Property "env.wasm.simd" is set to unknown value "${t}". Reset it to \`false\` and ignore SIMD feature checking.`), F.wasm.simd = false), typeof F.wasm.proxy != "boolean" && (F.wasm.proxy = false), typeof F.wasm.trace != "boolean" && (F.wasm.trace = false), typeof F.wasm.numThreads != "number" || !Number.isInteger(F.wasm.numThreads) || F.wasm.numThreads <= 0) if (typeof self < "u" && !self.crossOriginIsolated) F.wasm.numThreads = 1;
    else {
      let r = typeof navigator > "u" ? Nt("node:os").cpus().length : navigator.hardwareConcurrency;
      F.wasm.numThreads = Math.min(4, Math.ceil((r || 1) / 2));
    }
  }, Et = class {
    async init(r) {
      io(), await Zn(), await Kn(r);
    }
    async createInferenceSessionHandler(r, s) {
      let n = new yt();
      return await n.loadModel(r, s), n;
    }
  }, ms = new Et();
});
pe();
pe();
pe();
var _n = "1.23.2";
{
  let t = (fo(), kt(uo)).wasmBackend;
  Ge("cpu", t, 10), Ge("wasm", t, 10);
}
Object.defineProperty(F.versions, "web", { value: _n, enumerable: true });

// src/ctc.js
function decodeCTC(values, dims, charset, allowed, { logits = false } = {}) {
  if (dims.length !== 3 || dims[0] !== 1 || dims[2] !== charset.length)
    throw Error("\u041D\u0435\u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u0430\u044F \u0444\u043E\u0440\u043C\u0430 CTC.");
  const n = charset.length, indices = [
    0,
    ...charset.map((c, i) => allowed.includes(c) ? i : -1).filter((i) => i > 0)
  ];
  let previous = 0, text = "", scores = [], symbols = [];
  for (let t = 0; t < dims[1]; t++) {
    const row = values.subarray(t * n, (t + 1) * n);
    let best = 0, max = -Infinity;
    for (const i of indices)
      if (row[i] > max) {
        best = i;
        max = row[i];
      }
    let p = max;
    if (logits) {
      let denom = 0;
      for (const i of indices) denom += Math.exp(row[i] - max);
      p = 1 / denom;
    }
    if (!best) previous = 0;
    else if (best !== previous) {
      text += charset[best];
      scores.push(p);
      symbols.push({ char: charset[best], confidence: 100 * p, startStep: t, endStep: t, peakStep: t });
      previous = best;
    } else {
      const symbol = symbols.at(-1);
      symbol.endStep = t;
      if (p > scores.at(-1)) {
        scores[scores.length - 1] = p;
        symbol.confidence = 100 * p;
        symbol.peakStep = t;
      }
    }
  }
  return {
    text,
    symbols,
    confidence: scores.length ? 100 * Math.min(...scores, 1) : 0,
    meanConfidence: scores.length ? 100 * scores.reduce((a, b) => a + b, 0) / scores.length : 0
  };
}
function helperTensor(rgba, width, height, targetWidth) {
  const plane = height * targetWidth, out = new Float32Array(3 * plane);
  for (let y = 0; y < height; y++)
    for (let x2 = 0; x2 < width; x2++) {
      const i = (y * width + x2) * 4, j2 = y * targetWidth + x2, a = rgba[i + 3] / 255;
      out[j2] = (rgba[i + 2] * a + 255 * (1 - a)) / 127.5 - 1;
      out[plane + j2] = (rgba[i + 1] * a + 255 * (1 - a)) / 127.5 - 1;
      out[2 * plane + j2] = (rgba[i] * a + 255 * (1 - a)) / 127.5 - 1;
    }
  return out;
}

// src/models-worker.js
F.wasm.wasmPaths = new URL("vendor/ort/", self.location.href).href;
F.wasm.numThreads = 1;
F.wasm.proxy = false;
var models = /* @__PURE__ */ new Map();
async function getModel(name) {
  if (!models.has(name))
    models.set(
      name,
      (async () => {
        const config = await (await fetch(new URL(`models/${name}.json`, self.location.href))).json();
        const session = await qo.create(
          new URL(`models/${name}.onnx`, self.location.href).href,
          { executionProviders: ["wasm"], logSeverityLevel: 3 }
        );
        return { config, session };
      })()
    );
  return models.get(name);
}
self.onmessage = async (event) => {
  const { id, name, image, alphabet } = event.data;
  try {
    const { config, session } = await getModel(name);
    if ([...alphabet].some((c) => !config.charset.includes(c)))
      throw Error(`\u0410\u043B\u0444\u0430\u0432\u0438\u0442 ${name} \u043D\u0435 \u043F\u043E\u043A\u0440\u044B\u0432\u0430\u0435\u0442 \u043F\u0440\u043E\u0444\u0438\u043B\u044C.`);
    const encoded = image.slice(image.indexOf(",") + 1), bytes = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0));
    const bitmap = await createImageBitmap(
      new Blob([bytes], { type: "image/png" })
    );
    const h = name === "helper" ? 48 : config.height, scaledWidth = Math.ceil(h * bitmap.width / bitmap.height), w = name === "helper" ? Math.min(
      3200,
      Math.max(320, Math.trunc(h * bitmap.width / bitmap.height))
    ) : Math.max(h, scaledWidth), rw = Math.min(w, scaledWidth);
    const canvas = new OffscreenCanvas(rw, h), ctx = canvas.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, rw, h);
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(bitmap, 0, 0, rw, h);
    bitmap.close();
    const rgba = ctx.getImageData(0, 0, rw, h).data;
    let data, dims;
    if (name === "helper") {
      data = helperTensor(rgba, rw, h, w);
      dims = [1, 3, h, w];
    } else {
      data = new Float32Array(h * w);
      for (let y = 0; y < h; y++)
        for (let x2 = 0; x2 < w; x2++) {
          const i = (y * rw + Math.min(x2, rw - 1)) * 4;
          data[y * w + x2] = (0.299 * rgba[i] + 0.587 * rgba[i + 1] + 0.114 * rgba[i + 2]) / 127.5 - 1;
        }
      dims = [1, 1, h, w];
    }
    const output = await session.run({
      [session.inputNames[0]]: new ue("float32", data, dims)
    }), tensor = output[session.outputNames[0]];
    const result = decodeCTC(
      tensor.data,
      tensor.dims,
      config.charset,
      alphabet,
      { logits: name !== "helper" }
    );
    self.postMessage({ id, result: { ...result, engine: name } });
  } catch (error) {
    self.postMessage({ id, error: error.message });
  }
};
/*! Bundled license information:

onnxruntime-web/dist/ort.wasm.bundle.min.mjs:
  (*!
   * ONNX Runtime Web v1.23.2
   * Copyright (c) Microsoft Corporation. All rights reserved.
   * Licensed under the MIT License.
   *)
*/
