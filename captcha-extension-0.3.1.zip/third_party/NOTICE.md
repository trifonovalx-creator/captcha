# Local OCR components

## Captcha Helper
Source: https://github.com/hongshuo-wang/local-captcha-solver
Commit: 856f339f95885f002c674a315e752be77f5eedb4 (MIT code).
Adapted: local ORT/WASM session setup, BGR CHW normalization, resize/right padding, CTC blank/repeat decoding. Our adapter uses OffscreenCanvas in a dedicated worker and strict profile alphabet compatibility.
Unmodified model/config: public/models/captcha-ctc.onnx and captcha-ctc.json from this MIT-licensed repository. Weight-specific lineage: Apache-2.0 PaddleOCR PP-OCRv6 initialization and project training; upstream model notice is reproduced in Captcha-Helper-model-NOTICE.md. No separate restrictive weight terms were found in the model notice. Dataset attribution/lineage is retained, not inferred solely from the code license.
Training-data references: MathCaptcha10k v6 (CC BY 4.0), parsasam/CAPTCHA Dataset v1 (CC0), huthayfahodeb/Captcha Dataset v2 (CC0), daniilnxy/Math problem CAPTCHA images v1 (Apache 2.0). Source catalog: https://github.com/hongshuo-wang/local-captcha-solver/blob/856f339f95885f002c674a315e752be77f5eedb4/training/ppocrv6-captcha/public-datasets.ts

## EasyOCR
Source: https://github.com/JaidedAI/EasyOCR
Commit: 363afb184047ce452e436f4224f3098422df872e; code Apache-2.0.
Official weight artifact: https://github.com/JaidedAI/EasyOCR/releases/download/v1.6.1/cyrillic_g2.zip . The released recognizer is distributed by the Apache-2.0 project; the release archive contains cyrillic_g2.pth and has no separate conflicting weight license. Official checksum in easyocr/config.py: MD5 19f85f43d9128a89ac21b8d6a06973fe, verified before conversion. Full SHA256 values are recorded in reports/iteration3/assets.json.
Adapted: recognition-only VGG + two BiLSTM + linear CTC model, grayscale height-64 resize/right edge padding, alphabet masking and greedy CTC decoding. We converted the original weights to ONNX, replacing height-only adaptive average pooling by an equivalent ReduceMean. No training or weight fitting was performed. Apache-2.0 license is included as EasyOCR-LICENSE.txt. Export parity against the original recognizer is recorded separately.

## ddddocr (evaluation only)
Source: https://github.com/sml2h3/ddddocr commit c40f56f95412e10bcb9bd0bd24411e92f896d238; pinned Python package 1.5.6.
Code: MIT, included ddddocr-LICENSE.txt. The packaged common.onnx weight is included in the MIT-distributed package, with no separate weight notice. We evaluated locally; neither ddddocr code nor its model is shipped in dist. Case-sensitive results did not outperform the selected browser models. A Pillow API alias preserved the same Lanczos resampling for compatibility.

## ONNX Runtime Web
onnxruntime-web 1.23.2, MIT. Runtime JS, .mjs loader and WASM are shipped locally. See ONNX-Runtime-LICENSE.txt and ONNX-Runtime-ThirdPartyNotices.txt. No runtime CDN or model-server calls are used.

## Tesseract
The v2 Tesseract pipeline and its upstream notices remain included. It is used first for shapes; an accepted v2 answer returns immediately. EasyOCR is attempted only on refusal and within the remaining 28-second budget.
