import { fixtures, renderFixture, instruction, cropFor } from "./fixtures.js";
let type = "shapes",
  index = 0;
const $ = (selector) => document.querySelector(selector);
export function selectSample(id) {
  const sample = fixtures.find((s) => s.id === id);
  if (!sample) throw Error("Unknown fixture");
  type = sample.type;
  index = fixtures.filter((s) => s.type === type).indexOf(sample);
  draw(sample);
}
function draw(sample) {
  renderFixture($("[data-captcha-image]"), sample);
  $("[data-captcha-instruction]").textContent = instruction(type);
  $("[data-captcha-min]").textContent = "min " + sample.min;
  $("[data-captcha-max]").textContent = "max " + sample.max;
  $("#answer").value = "";
  $("#answer").removeAttribute("minlength");
  $("#answer").removeAttribute("maxlength");
  $("#answer").maxLength = sample.max;
  $("#answer").minLength = sample.min;
  $("#sample-id").textContent = sample.id;
  $("#truth").textContent = sample.expected;
  $("#feedback").textContent =
    "Нажмите иконку расширения для ввода и проверки ответа.";
  document
    .querySelectorAll("[data-type]")
    .forEach((b) => b.classList.toggle("chosen", b.dataset.type === type));
}
$("#types").addEventListener("click", (event) => {
  const button = event.target.closest("[data-type]");
  if (!button) return;
  type = button.dataset.type;
  index = 0;
  draw(fixtures.filter((s) => s.type === type)[index]);
});
const nextSample = () => {
  const list = fixtures.filter((s) => s.type === type);
  index = (index + 1) % list.length;
  draw(list[index]);
};
$("#next").addEventListener("click", nextSample);
$("#skip").addEventListener("click", nextSample);
$("[data-captcha]").addEventListener("submit", (event) => {
  event.preventDefault();
  $("#feedback").textContent =
    $("#answer").value === $("#truth").textContent
      ? "Верно. Ответ полностью совпал с эталоном."
      : "Ответ отличается от эталона. Проверьте символы и регистр.";
});
// Demo-only API: explicit selectors, fixture selection and metadata for regression tests.
globalThis.Demo = {
  selectSample,
  fixtures,
  renderFixture,
  instruction,
  cropFor,
};
draw(fixtures[0]);
