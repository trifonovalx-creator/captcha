// Deterministic, synthetic fixtures. These are not the user's original screenshot pixels.
export const fixtures = [
  ...[
    ["КЛБВТПАЧ", [0, 1, 7]],
    ["ЖДКМНРУФ", [0, 3, 6]],
    ["АБВГДЕЖЗ", [1, 4, 7]],
    ["ЦЩКЛМПРТ", [0, 2, 5]],
    ["ЛФЦШКЯДЧ", [0, 4, 7]],
    ["БЖЫФЭЮЯА", [1, 3, 6]],
    ["ЧКЛГДРШН", [0, 2, 5]],
    ["ЯЮЭХЦЧШЩ", [1, 4, 7]],
  ].map(([letters, triangles], i) => ({
    id: `shapes-${i + 1}`,
    type: "shapes",
    split: i < 4 ? "calibration" : "holdout",
    letters,
    triangles,
    expected: triangles.map((k) => letters[k]).join(""),
    min: 3,
    max: 4,
    seed: i,
  })),
  ...[
    "ktyY3",
    "Ab3Qx",
    "mN7gR",
    "R4sWp",
    "bT6nZ",
    "sD8vK",
    "aF2hY",
    "P9qLc",
  ].map((expected, i) => ({
    id: `color-${i + 1}`,
    type: "color",
    split: i < 4 ? "calibration" : "holdout",
    expected,
    min: 5,
    max: 5,
    seed: i,
    grayIndex: i % 5,
  })),
  ...[
    "KuypB",
    "Ax7mN",
    "bTqR6",
    "Wn3vK",
    "aFy7R",
    "Vq2hZ",
    "mP6sX",
    "B7nqAc",
  ].map((expected, i) => ({
    id: `lines-${i + 1}`,
    type: "lines",
    split: i < 4 ? "calibration" : "holdout",
    expected,
    min: 5,
    max: 6,
    seed: i,
  })),
];
export function renderFixture(c, sample) {
  c.width = sample.type === "shapes" ? 400 : 310;
  c.height = sample.type === "shapes" ? 130 : 110;
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#f5f5f3";
  ctx.fillRect(0, 0, c.width, c.height);
  const colors = [
    "#3a92d2",
    "#39ae88",
    "#c59a40",
    "#bb5f70",
    "#8267be",
    "#2c9290",
    "#d67439",
    "#69a04c",
  ];
  if (sample.type === "shapes") {
    ctx.font = "38px Arial";
    ctx.fillStyle = "#4e5458";
    ctx.textAlign = "center";
    [...sample.letters].forEach((char, i) =>
      ctx.fillText(char, 25 + i * 50, 57),
    );
    for (let i = 0; i < 8; i++) {
      const x = 25 + i * 50,
        y = 99;
      ctx.fillStyle = colors[(i + sample.seed) % colors.length];
      ctx.beginPath();
      if (sample.triangles.includes(i)) {
        ctx.moveTo(x, y);
        ctx.lineTo(x - 15, y + 27);
        ctx.lineTo(x + 15, y + 27);
        ctx.closePath();
      } else if (i % 2 === 0) ctx.rect(x - 13, y + 1, 26, 26);
      else ctx.arc(x, y + 14, 13, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (sample.type === "color") {
    // Includes a gray useful glyph and a colored watermark; saturation alone loses information.
    ctx.fillStyle = "#4a4e52";
    ctx.font = "10px monospace";
    ctx.fillText("Капча для n.blsp.at", 8, 12);
    ctx.fillText("Если домен другой — возможен фишинг", 8, 106);
    const palette = ["#b5bc36", "#d67572", "#caa024", "#5368cb", "#6d7275"];
    ctx.textAlign = "center";
    [...sample.expected].forEach((char, i) => {
      ctx.font = "bold 59px Arial";
      ctx.fillStyle =
        i === sample.grayIndex ? "#727679" : palette[(i + sample.seed) % 5];
      ctx.fillText(char, 33 + i * 60, 81);
    });
    ctx.save();
    ctx.translate(124, 68);
    ctx.rotate(-0.28);
    ctx.fillStyle = "#8bb90e";
    ctx.font = "italic 16px Arial";
    ctx.fillText("n.blsp.at", 0, 0);
    ctx.restore();
  } else {
    ctx.fillStyle = "#33383a";
    ctx.textAlign = "center";
    const step = 280 / sample.expected.length;
    [...sample.expected].forEach((char, i) => {
      ctx.save();
      ctx.translate(20 + step * (i + 0.5), 67 + (i % 2) * 3);
      ctx.rotate(((i % 3) - 1) * 0.09);
      ctx.font = "italic bold 48px Arial";
      ctx.fillText(char, 0, 0);
      ctx.restore();
    });
    for (let line = 0; line < 7; line++) {
      ctx.strokeStyle = line % 2 ? "#888c8a" : "#bdc0bc";
      ctx.lineWidth = 0.7;
      ctx.beginPath();
      for (let x = 0; x <= 310; x += 5) {
        const y =
          20 + line * 10 + Math.sin((x + sample.seed * 13 + line * 5) / 24) * 4;
        x ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.stroke();
    }
  }
  return c;
}
export function instruction(type) {
  return {
    shapes:
      "Введите буквы под треугольниками. | Type letters (Cyrillic) above the triangle.",
    color:
      "Type the colored symbols. Case sensitive. Введите цветные символы с учётом регистра.",
    lines: "Type the slanted symbols with crossing lines. Сохраните регистр.",
  }[type];
}
export function cropFor(type) {
  return type === "color"
    ? { top: 0.15, bottom: 0.16, left: 0, right: 0 }
    : { top: 0, bottom: 0, left: 0, right: 0 };
}
