import {fixtures,renderFixture,instruction} from './fixtures.js';
const params=new URLSearchParams(location.search),kind=params.get('case')||'normal';
globalThis.OneClickDemo={kind,clicks:0,submits:0,inputs:0,changes:0,values:[],ready:false};
if(kind==='iframe' || kind==='cross-frame'){
 const frame=document.createElement('iframe');frame.id='trainer';frame.width='700';frame.height='700';frame.title='Форма с капчей';
 frame.src=kind==='iframe'?'/demo/one-click.html':'http://127.0.0.1:4174/demo/one-click.html';document.querySelector('#mount').append(frame);OneClickDemo.ready=true;
}else{
 const insert=()=>{
  const form=document.createElement('form');form.id='challenge-form';form.setAttribute('data-captcha','');
  form.innerHTML='<p data-captcha-instruction></p><canvas data-captcha-image></canvas><p><span data-captcha-min>min 3</span> / <span data-captcha-max>max 4</span></p><label>Ответ <input id="answer" data-captcha-answer minlength="3" maxlength="4" autocomplete="off"></label><button id="confirm" type="submit">Проверить</button><button id="skip" type="button">Пропустить</button>';
  const s=fixtures[0];renderFixture(form.querySelector('canvas'),s);form.querySelector('[data-captcha-instruction]').textContent=instruction('shapes');
  if(kind==='blank'){const c=form.querySelector('canvas');c.getContext('2d').clearRect(0,0,c.width,c.height);}
  const button=form.querySelector('#confirm');
  if(kind==='continue'){button.type='button';button.textContent='Продолжить';}
  if(kind==='accessible'){button.type='button';button.textContent='→';button.setAttribute('aria-label','Далее');}
  if(kind==='labelledby'){button.type='button';button.textContent='→';button.setAttribute('aria-labelledby','next-name');const name=document.createElement('span');name.id='next-name';name.textContent='Подтвердить';form.append(name);}
  if(kind==='ambiguous'){const second=button.cloneNode(true);second.id='confirm-2';second.textContent='Продолжить';form.append(second);}
  if(kind==='disabled')button.disabled=true;
  if(kind==='delayed-button'){
   button.disabled=true;
   form.querySelector('input').addEventListener('input',()=>setTimeout(()=>{button.disabled=false;},350));
  }
  if(kind==='unknown')button.textContent='Удалить';
  if(kind==='reset'){button.type='reset';button.textContent='Продолжить';}
  if(kind==='missing-button')button.remove();
  if(kind==='manual')form.querySelector('input').value='моё';
  if(kind==='external'){button.setAttribute('form',form.id);button.remove();}
  form.querySelector('input').addEventListener('input',()=>OneClickDemo.inputs++);
  form.querySelector('input').addEventListener('change',()=>OneClickDemo.changes++);
  button.addEventListener('click',()=>{OneClickDemo.clicks++;OneClickDemo.values.push(form.querySelector('input').value);if(button.type==='button')document.querySelector('#result').textContent='Продолжено';});
  form.addEventListener('submit',event=>{event.preventDefault();OneClickDemo.submits++;document.querySelector('#result').textContent=form.querySelector('input').value===s.expected?'Верно: '+s.expected:'Неверно';});
  document.querySelector('#mount').append(form);
  if(kind==='external')document.querySelector('#mount').append(button);
  if(kind==='multiple-images')form.append(form.querySelector('canvas').cloneNode(true));
  if(kind==='multiple-inputs')form.append(form.querySelector('input').cloneNode(true));
  if(kind==='missing')document.querySelector('#mount').replaceChildren();
  if(kind==='other-form'){const other=document.createElement('form');other.innerHTML='<button type="submit">Продолжить</button>';other.addEventListener('submit',e=>{e.preventDefault();OneClickDemo.unrelated=true;});document.querySelector('#mount').append(other);}
  if(kind==='rerender')form.querySelector('input').addEventListener('input',e=>{const replacement=e.target.cloneNode();replacement.value=e.target.value;e.target.replaceWith(replacement);});
  if(kind==='change-after-input')form.querySelector('input').addEventListener('input',()=>renderFixture(form.querySelector('canvas'),fixtures[1]));
  if(kind==='auto-submit-on-input')form.querySelector('input').addEventListener('input',()=>button.click());
  OneClickDemo.ready=true;
 };
 if(kind==='delayed')setTimeout(insert,900);else insert();
}
