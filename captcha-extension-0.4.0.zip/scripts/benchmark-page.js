import { recognize as oldRecognize } from "../tests/baseline-v1/ocr.js";
import { recognize } from "../src/ocr.js";
import { renderFresh, freshSamples } from "../tests/fresh-fixtures.js";
globalThis.Benchmark = { oldRecognize, recognize, renderFresh, freshSamples };
