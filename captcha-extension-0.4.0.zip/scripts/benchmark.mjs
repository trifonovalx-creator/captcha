import { build } from "esbuild";
import { chromium } from "playwright-core";
import { mkdtemp, mkdir, cp, writeFile, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fixtures, cropFor } from "../demo/fixtures.js";
import { freshSamples } from "../tests/fresh-fixtures.js";
import { LATIN } from "../src/decision.js";
const label = process.env.RUN_LABEL || "baseline-old",
  which = process.env.DATASET || "old",
  engine = process.env.ENGINE || "oldRecognize",
  stage = process.env.STAGE || "final";
const root = process.cwd(),
  temp = await mkdtemp(path.join(tmpdir(), "captcha-benchmark-")),
  out = path.join(root, "reports/iteration2", label);
await mkdir(out, { recursive: true });
let context;
const results = [];
try {
  const ext = path.join(temp, "extension");
  await mkdir(ext);
  await cp("dist/vendor", path.join(ext, "vendor"), { recursive: true });
  await writeFile(
    path.join(ext, "manifest.json"),
    JSON.stringify({
      manifest_version: 3,
      name: "Captcha benchmark",
      version: "1.0",
      content_security_policy: {
        extension_pages:
          "script-src 'self' 'wasm-unsafe-eval'; object-src 'self'; connect-src 'self'; worker-src 'self'",
      },
    }),
  );
  await writeFile(
    path.join(ext, "lab.html"),
    '<meta charset="utf-8"><script src="lab.js"></script>',
  );
  await build({
    entryPoints: ["scripts/benchmark-page.js"],
    outfile: path.join(ext, "lab.js"),
    bundle: true,
    platform: "browser",
    format: "iife",
  });
  context = await chromium.launchPersistentContext(path.join(temp, "profile"), {
    executablePath:
      process.env.CHROME_PATH || "/tmp/captcha-chrome/opt/google/chrome/chrome",
    headless: true,
    ignoreDefaultArgs: ["--disable-extensions"],
    viewport: { width: 1280, height: 1000 },
    deviceScaleFactor: 1,
    args: [
      "--enable-unsafe-extension-debugging",
      "--no-sandbox",
      "--disable-dev-shm-usage",
    ],
  });
  const cdp = await context.browser().newBrowserCDPSession(),
    { id } = await cdp.send("Extensions.loadUnpacked", { path: ext });
  const page = await context.newPage();
  await page.goto(`chrome-extension://${id}/lab.html`);
  await page.waitForFunction(() => !!globalThis.Benchmark);
  const warmImage =
    "data:image/png;base64," +
    (await readFile("tests/fixtures/synthetic/shapes-1.png")).toString(
      "base64",
    );
  const warm = await page.evaluate(
    async ({ image, engine }) =>
      Benchmark[engine]({ image, type: "shapes", min: 3, max: 4 }),
    { image: warmImage, engine },
  );
  console.log(
    "Warmup",
    warm.candidate,
    warm.confidence,
    warm.candidates,
    warm.debug.filter((d) => d.text),
  );
  const list =
    which === "old"
      ? fixtures.filter((s) => s.split === "holdout")
      : freshSamples.filter((s) => which === "fresh" || s.split === which);
  for (const sample of list) {
    let image;
    if (which === "old")
      image =
        "data:image/png;base64," +
        (await readFile(`tests/fixtures/synthetic/${sample.id}.png`)).toString(
          "base64",
        );
    else {
      const file = `tests/fixtures/fresh/${sample.id}.png`;
      try {
        image =
          "data:image/png;base64," + (await readFile(file)).toString("base64");
      } catch {
        image = await page.evaluate((s) => Benchmark.renderFresh(s), sample);
        await mkdir("tests/fixtures/fresh", { recursive: true });
        await writeFile(file, Buffer.from(image.split(",")[1], "base64"));
      }
    }
    const task = {
      image,
      type: sample.type,
      min: sample.min,
      max: sample.max,
      alphabet: LATIN,
      crop: sample.crop || cropFor(sample.type),
    };
    const result = await page.evaluate(
      async ({ task, engine, stage }) => Benchmark[engine](task, { stage }),
      { task, engine, stage },
    );
    const images = [];
    for (const [i, d] of (result.debug || []).entries())
      if (d.image) {
        const name = `${sample.id}-${i}.png`;
        await writeFile(
          path.join(out, name),
          Buffer.from(d.image.split(",")[1], "base64"),
        );
        images.push({ name: d.name, file: name });
      }
    await writeFile(
      path.join(out, `${sample.id}-input.png`),
      Buffer.from(image.split(",")[1], "base64"),
    );
    for (const c of result.candidates) delete c.blocks;
    const row = {
      id: sample.id,
      type: sample.type,
      source: "synthetic",
      split: sample.split,
      expected: sample.expected,
      correctAmongCandidates: result.candidates.some(
        (c) => c.text === sample.expected,
      ),
      ...result,
      debug: images,
    };
    results.push(row);
    console.log(
      sample.id,
      sample.expected,
      "=>",
      row.candidate,
      row.confidence,
      row.accepted ? "FILL" : "SKIP",
      row.correctAmongCandidates ? "correct-in-pool" : "absent",
    );
    await writeFile(
      path.join(out, "results.json"),
      JSON.stringify(
        {
          engine,
          stage,
          browser: context.browser().version(),
          samples: results,
        },
        null,
        2,
      ),
    );
  }
} finally {
  await context?.close();
  await rm(temp, { recursive: true, force: true });
}
