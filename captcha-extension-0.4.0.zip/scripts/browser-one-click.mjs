import {chromium} from 'playwright-core';
import {mkdtemp,rm,writeFile,readFile,mkdir,cp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {serve} from './serve.mjs';
import {DEFAULT_PROFILE} from '../src/profile.js';
import {v3Samples} from '../tests/v3-fixtures.js';
const temp=await mkdtemp(path.join(tmpdir(),'captcha-one-click-'));
const servers=[serve(),serve(4174)];
const report={browser:null,realSite:null,source:'synthetic local HTML',cases:[],errors:[]};
let ctx;
async function waitUntil(check,ms=35000){const end=Date.now()+ms;while(Date.now()<end){const value=await check();if(value)return value;await new Promise(r=>setTimeout(r,60));}throw Error('Condition timed out');}
async function remoteValue(cdp,targetId,expression){
 const {sessionId}=await cdp.send('Target.attachToTarget',{targetId,flatten:false});
 const result=new Promise(resolve=>{const listen=e=>{if(e.sessionId===sessionId){const m=JSON.parse(e.message);if(m.id===77){cdp.off('Target.receivedMessageFromTarget',listen);resolve(m.result?.result?.value);}}};cdp.on('Target.receivedMessageFromTarget',listen);});
 await cdp.send('Target.sendMessageToTarget',{sessionId,message:JSON.stringify({id:77,method:'Runtime.evaluate',params:{expression,returnByValue:true}})});
 const value=await result;await cdp.send('Target.detachFromTarget',{sessionId});return value;
}
async function setup(kind,{profile={},extension='dist',url}={}){
 if(ctx)await ctx.close();

 ctx=await chromium.launchPersistentContext(path.join(temp,kind),{executablePath:process.env.CHROME_PATH||'/tmp/captcha-chrome/opt/google/chrome/chrome',headless:true,ignoreDefaultArgs:['--disable-extensions'],viewport:{width:1280,height:1000},args:['--enable-unsafe-extension-debugging','--no-sandbox','--disable-dev-shm-usage']});
 ctx.on('weberror',e=>report.errors.push({kind,error:e.error().message}));
 report.browser=ctx.browser().version();
 const cdp=await ctx.browser().newBrowserCDPSession(),{id}=await cdp.send('Extensions.loadUnpacked',{path:path.resolve(extension)});
 const settings=await ctx.newPage();await settings.goto(`chrome-extension://${id}/options.html`);
 await settings.waitForFunction(()=>document.querySelector('#image')?.value);
 await settings.evaluate(p=>chrome.storage.local.set({'profile:http://127.0.0.1:4173':p}),{...DEFAULT_PROFILE,waitForMs:2500,...profile});
 const page=await ctx.newPage();await page.goto(url||`http://127.0.0.1:4173/demo/one-click.html?case=${kind}`);
 if(!url)await page.waitForFunction(()=>!!globalThis.OneClickDemo);
 await page.bringToFront();
 const tabId=await settings.evaluate(async()=>(await chrome.tabs.query({active:true,currentWindow:true}))[0].id);
 const before=await settings.evaluate(async()=>({windows:(await chrome.windows.getAll()).length,tabs:(await chrome.tabs.query({})).length}));
 async function trigger(){
  const previous=await state().catch(()=>null);
  const {targetInfos}=await cdp.send('Target.getTargets',{filter:[{type:'tab',exclude:false}]});await cdp.send('Extensions.triggerAction',{id,targetId:targetInfos.find(t=>t.url===page.url()).targetId});
  await waitUntil(async()=>{
   const s=await state().catch(()=>null);
   if(s?.id && (!previous?.id || (previous.done && s.id!==previous.id) || !previous.done))return true;
   return settings.evaluate(async tabId=>(await chrome.storage.session.get('status:'+tabId))['status:'+tabId]?.state==='error',tabId);
  });
 }
 async function state(){return settings.evaluate(async tabId=>{const route=(await chrome.storage.session.get('route:'+tabId))['route:'+tabId];return route?chrome.tabs.sendMessage(tabId,{kind:'ONE_CLICK_STATE'},{documentId:route.documentId}):null;},tabId);}
 async function done(){
  return waitUntil(async()=>{const r=await state();return r?.done?r:null;});
 }
 async function record(name,frame=page){

  const s=await done(),demo=await frame.evaluate(()=>({demo:globalThis.OneClickDemo,value:document.querySelector('#answer')?.value||''}));
  const after=await settings.evaluate(async()=>({windows:(await chrome.windows.getAll()).length,tabs:(await chrome.tabs.query({})).length}));
  assert.deepEqual(after,before,'no extra window or tab for OCR');
  const row={name,...demo,...s};for(const t of s.timings)assert.ok(t.elapsedMs<30000);
  report.cases.push(row);await save();console.log(name,s.state,demo.value,'clicks',demo.demo.clicks,s.timings.map(t=>t.elapsedMs));return row;
 }
 return {page,settings,trigger,state,done,record,tabId,id,cdp};
}
async function save(){await mkdir('reports/iteration5',{recursive:true});await writeFile('reports/iteration5/browser.json',JSON.stringify(report,null,2));}
try{
 for(const kind of (process.env.SMOKE?['normal']:['normal','delayed','delayed-button','continue','accessible','labelledby','external','other-form'])){
  const c=await setup(kind);await c.trigger();const r=await c.record(kind);assert.equal(r.value,'КЛЧ');assert.equal(r.demo.clicks,1);assert.equal(r.demo.inputs,1);assert.equal(r.demo.changes,1);assert.equal(r.state,'submitted');assert.equal(r.demo.unrelated,undefined);
  if(kind==='normal'){
   await c.page.screenshot({path:'reports/iteration5/one-click.png'});
   await c.trigger();const repeat=await c.record('repeat-click');assert.equal(repeat.demo.clicks,1);assert.equal(repeat.timings.filter(t=>t.kind==='submit').length,1);
   await c.page.locator('#answer').fill('');await c.trigger();const cleared=await c.record('repeat-after-clear');assert.equal(cleared.demo.clicks,1);assert.equal(cleared.state,'already');
  }
 }
 if(!process.env.SMOKE){
  for(const kind of ['ambiguous','disabled','unknown','reset','missing-button']){
   const c=await setup(kind);await c.trigger();const r=await c.record(kind);assert.equal(r.value,'КЛЧ');assert.equal(r.demo.clicks,0);assert.equal(r.state,'filled');
  }
  for(const kind of ['blank','multiple-images','multiple-inputs','missing','manual','rerender','change-after-input']){
   const c=await setup(kind);await c.trigger();const r=await c.record(kind);assert.equal(r.demo.clicks,0);
   if(['blank','multiple-images'].includes(kind))assert.equal(r.value,'');
   if(kind==='manual')assert.equal(r.value,'моё');
  }
  const explicit=await setup('ambiguous',{profile:{submitSelector:'#confirm'}});await explicit.trigger();assert.equal((await explicit.record('explicit-site-button')).demo.clicks,1);
  for(const type of ['color','lines']){
   const sample=v3Samples.find(s=>s.id===`eval3-${type}-1`),c=await setup('normal',{profile:{type,alphabet:sample.alphabet,crop:sample.crop}});
   const png='data:image/png;base64,'+(await readFile(`tests/fixtures/v3/${sample.id}.png`)).toString('base64');
   await c.page.evaluate(async({png,sample})=>{const img=new Image();img.src=png;await img.decode();const canvas=document.querySelector('canvas');canvas.width=img.width;canvas.height=img.height;canvas.getContext('2d').drawImage(img,0,0);document.querySelector('[data-captcha-instruction]').textContent=sample.type==='color'?'Введите цветные символы (Latin).':'Наклонные символы с линиями (Latin).';document.querySelector('[data-captcha-min]').textContent='min '+sample.min;document.querySelector('[data-captcha-max]').textContent='max '+sample.max;document.querySelector('input').maxLength=sample.max;document.querySelector('input').minLength=sample.min;},{png,sample});
   await c.trigger();const r=await c.record(type+'-existing-onnx');assert.equal(r.value,sample.expected);assert.equal(r.demo.clicks,1);
  }
  const autoSubmit=await setup('auto-submit-on-input');await autoSubmit.trigger();const ar=await autoSubmit.record('page-auto-submits-on-input');assert.equal(ar.demo.clicks,1);assert.equal(ar.timings.filter(t=>t.kind==='submit').length,0);assert.equal(ar.state,'manual');
  for(const mode of ['manual-during-ocr','image-during-ocr','manual-submit-during-ocr','double-start']){
   const c=await setup('normal');await c.trigger();
   await waitUntil(()=>c.settings.evaluate(async tabId=>(await chrome.storage.session.get('status:'+tabId))['status:'+tabId]?.state==='ocr',c.tabId));
   if(mode==='manual-during-ocr')await c.page.locator('#answer').fill('моё');
   if(mode==='image-during-ocr')await c.page.evaluate(()=>{const c=document.querySelector('canvas');c.getContext('2d').clearRect(0,0,c.width,c.height);});
   if(mode==='manual-submit-during-ocr')await c.page.locator('#confirm').click();
   if(mode==='double-start')await c.trigger();
   const r=await c.record(mode);
   assert.equal(r.demo.clicks,['double-start','manual-submit-during-ocr'].includes(mode)?1:0);
   if(mode==='manual-submit-during-ocr'){assert.equal(r.value,'');assert.equal(r.timings.length,0);}
   if(mode==='manual-during-ocr')assert.equal(r.value,'моё');
   if(mode==='image-during-ocr')assert.equal(r.value,'');
  }
  const c=await setup('iframe',{profile:{frameSelector:'#trainer'}});await c.page.locator('iframe').contentFrame().locator('#answer').waitFor();await c.trigger();const r=await c.record('same-origin-iframe',c.page.frames()[1]);assert.equal(r.demo.clicks,1);
  const cross=await setup('cross-frame',{profile:{frameSelector:'#trainer'}});await cross.page.locator('iframe').contentFrame().locator('#answer').waitFor();await cross.trigger();
  await waitUntil(()=>cross.settings.evaluate(async tabId=>(await chrome.storage.session.get('status:'+tabId))['status:'+tabId]?.state==='error',cross.tabId));
  const forbidden=await cross.settings.evaluate(async tabId=>(await chrome.storage.session.get('status:'+tabId))['status:'+tabId],cross.tabId);assert.match(forbidden.reason,/Фрейм недоступен/);report.cases.push({name:'cross-origin-iframe',...forbidden});
  const unsupported=await setup('unsupported',{url:'chrome://version/'});await unsupported.trigger();
  await waitUntil(()=>unsupported.settings.evaluate(async tabId=>(await chrome.storage.session.get('status:'+tabId))['status:'+tabId]?.state==='error',unsupported.tabId));
  const denied=await unsupported.settings.evaluate(async tabId=>({status:(await chrome.storage.session.get('status:'+tabId))['status:'+tabId],badge:await chrome.action.getBadgeText({tabId}),title:await chrome.action.getTitle({tabId})}),unsupported.tabId);assert.equal(denied.badge,'!');report.cases.push({name:'unsupported-tab',...denied});
  const slow=await setup('normal');
  await slow.page.route('**/slow.png',async route=>{await new Promise(r=>setTimeout(r,1100));await route.fulfill({contentType:'image/png',body:await readFile('tests/fixtures/synthetic/shapes-1.png')});});
  await slow.page.evaluate(()=>{const img=new Image();img.width=400;img.height=130;img.setAttribute('data-captcha-image','');img.src='/slow.png';document.querySelector('canvas').replaceWith(img);});
  await slow.trigger();const sr=await slow.record('slow-image-in-budget');assert.equal(sr.demo.clicks,1);assert.ok(sr.timings[0].elapsedMs>=800);
  const cors=await setup('normal');
  await cors.page.evaluate(async()=>{const img=new Image();img.width=400;img.height=130;img.setAttribute('data-captcha-image','');img.src='http://127.0.0.1:4174/tests/fixtures/synthetic/shapes-1.png';await img.decode();document.querySelector('canvas').replaceWith(img);});
  await cors.trigger();assert.equal((await cors.record('cors-screenshot-verification')).demo.clicks,1);
  const observed=await setup('normal',{profile:{mode:'observe'}});await observed.trigger();const ob=await observed.record('observation-no-actions');assert.equal(ob.state,'observed');assert.equal(ob.value,'');assert.equal(ob.demo.clicks,0);
  const options=observed.settings;
  await options.locator('#origin').fill('http://127.0.0.1:4173');await options.locator('#load').click();await options.waitForFunction(()=>document.querySelector('#mode').value==='observe');
  await options.locator('#waitForMs').fill('3400');await options.locator('#submitSelector').fill('#confirm');await options.locator('button[type=submit]').click();
  await options.waitForFunction(()=>document.querySelector('#saved').textContent.startsWith('Сохранено'));
  await options.reload();await options.waitForFunction(()=>document.querySelector('#waitForMs').value==='3400');assert.equal(await options.locator('#submitSelector').inputValue(),'#confirm');
  await options.screenshot({path:'reports/iteration5/options.png',fullPage:true});report.cases.push({name:'options-persist',waitForMs:3400,submitSelector:'#confirm'});
  const parity=await observed.page.evaluate(async()=>{
   const {loadImage}=await import('/src/image.js'),results=[];
   for(const file of ['synthetic/shapes-1.png','v3/eval3-color-4.png','v3/eval3-lines-2.png','v4/holdout4-color-26.png']){
    const blob=await(await fetch('/tests/fixtures/'+file)).blob();const url=await new Promise(resolve=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.readAsDataURL(blob);});
    const img=new Image();img.src=url;await img.decode();const old=document.createElement('canvas');old.width=img.width;old.height=img.height;old.getContext('2d').drawImage(img,0,0);
    const next=await loadImage(url),a=old.getContext('2d').getImageData(0,0,old.width,old.height).data,b=next.getContext('2d').getImageData(0,0,next.width,next.height).data;
    results.push({file,equal:a.length===b.length&&a.every((x,i)=>x===b[i])});
   }return results;
  });assert.ok(parity.every(r=>r.equal));report.cases.push({name:'bitmap-decoder-pixel-parity',images:parity});
  const lab=await ctx.newPage();await lab.goto(`chrome-extension://${observed.id}/controller.html`);await lab.waitForFunction(()=>document.querySelector('#status').textContent.includes('OCR-стенд'));await lab.locator('#settings > summary').click();await lab.locator('#type').selectOption('shapes');await lab.locator('details:has(#upload) > summary').click();await lab.locator('#upload').setInputFiles('tests/fixtures/synthetic/shapes-1.png');await lab.locator('#recognize-file').click();await lab.waitForFunction(()=>document.querySelector('#candidate').textContent==='КЛЧ',{},{timeout:15000});report.cases.push({name:'manual-image-lab-preserved',candidate:'КЛЧ'});
  const fault=path.join(temp,'fault-extension');await cp('dist',fault,{recursive:true});
  const faultScript=path.join(fault,'offscreen.js');
  // Test-only transport delay of a real ONNX reply; production dist is untouched.
  const prefix=`self.__held=0;self.__late=0;chrome.runtime.onMessage.addListener(m=>{if(m.kind==='RUN_OCR')self.__faultDeadline=m.startedAt+28500;});const d=Object.getOwnPropertyDescriptor(Worker.prototype,'onmessage');Object.defineProperty(Worker.prototype,'onmessage',{get:d.get,set(handler){d.set.call(this,event=>{if(event.data?.result){self.__held++;setTimeout(()=>{self.__late++;self.__lateAt=Date.now();handler(event);},Math.max(0,self.__faultDeadline-Date.now()));}else handler(event);});}});\n`;
  await writeFile(faultScript,prefix+await readFile(faultScript,'utf8'));
  const sample=v3Samples.find(s=>s.id==='eval3-color-1');const hung=await setup('normal',{extension:fault,profile:{type:'color',alphabet:sample.alphabet,crop:sample.crop}});
  const png='data:image/png;base64,'+(await readFile('tests/fixtures/v3/'+sample.id+'.png')).toString('base64');
  await hung.page.evaluate(async({png})=>{const img=new Image();img.src=png;await img.decode();const c=document.querySelector('canvas');c.width=img.width;c.height=img.height;c.getContext('2d').drawImage(img,0,0);document.querySelector('input').maxLength=5;document.querySelector('input').minLength=5;document.querySelector('[data-captcha-instruction]').textContent='Введите цветные символы (Latin).';document.querySelector('[data-captcha-min]').textContent='min 5';document.querySelector('[data-captcha-max]').textContent='max 5';},{png});
  await hung.trigger();const hr=await hung.record('hung-onnx-deadline');assert.equal(hr.state,'timeout');assert.equal(hr.demo.clicks,0);assert.equal(hr.value,'');
  const stopped=Date.now()-hr.startedAt;assert.ok(stopped>=28000 && stopped<30000);hr.stopElapsedMs=stopped;
  await new Promise(r=>setTimeout(r,2500));
  const targets=await hung.cdp.send('Target.getTargets'),target=targets.targetInfos.find(t=>t.url.endsWith('/offscreen.html'));
  const injected=JSON.parse(await remoteValue(hung.cdp,target.targetId,'JSON.stringify({held:self.__held,late:self.__late,lateAt:self.__lateAt})'));assert.ok(injected.held>0&&injected.late>0);assert.ok(injected.lateAt>=hr.startedAt+28000);
  assert.equal(await hung.page.locator('#answer').inputValue(),'');assert.equal(await hung.page.evaluate(()=>OneClickDemo.clicks),0);report.cases.push({name:'late-onnx-reply-ignored',...injected,actions:0});
  await hung.trigger();const retried=await hung.record('retry-keeps-original-deadline');assert.equal(retried.startedAt,hr.startedAt);assert.equal(retried.state,'timeout');assert.equal(retried.demo.clicks,0);assert.equal(retried.value,'');
 }
}catch(error){report.failure=error.stack;console.error(error);process.exitCode=1;}
finally{await save();await ctx?.close();servers.forEach(s=>s.close());await rm(temp,{recursive:true,force:true});console.log('Passed:',report.cases.length,'failure:',report.failure||'none');}
