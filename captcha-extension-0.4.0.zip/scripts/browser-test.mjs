// Current contracts: observation, bounded skip series, absolute deadlines and native quality checks.
import { execFileSync } from "node:child_process";
for (const script of [
  "scripts/browser-v3.mjs",
  "scripts/quality-browser-v3.mjs",
  "scripts/quality-color-browser.mjs",
])
  execFileSync(process.execPath, [script], { stdio: "inherit", env: {...process.env, REPORT_DIR: 'reports/iteration4/regressions'} });
