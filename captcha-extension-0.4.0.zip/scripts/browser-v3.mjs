import { chromium } from "playwright-core";
import { serve } from "./serve.mjs";
import { mkdtemp, rm, readFile, writeFile, mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import assert from "node:assert/strict";
import { DEFAULT_PROFILE } from "../src/profile.js";
const server = serve(),
  imageServer = serve(4174),
  temp = await mkdtemp(path.join(tmpdir(), "captcha-v3-tests-"));
const report = {
  checks: [],
  cases: [],
  quality: [],
  browser: null,
  errors: [],
};
let ctx;
async function setup(
  name,
  {
    mode = "auto",
    hang = false,
    limit = 3,
    type = "shapes",
    alphabet,
    crop,
  } = {},
) {
  if (ctx) await ctx.close();
  ctx = await chromium.launchPersistentContext(path.join(temp, name), {
    executablePath:
      process.env.CHROME_PATH || "/tmp/captcha-chrome/opt/google/chrome/chrome",
    headless: true,
    ignoreDefaultArgs: ["--disable-extensions"],
    viewport: { width: 1280, height: 1000 },
    args: [
      "--enable-unsafe-extension-debugging",
      "--no-sandbox",
      "--disable-dev-shm-usage",
    ],
  });
  report.browser = ctx.browser().version();
  if (hang)
    await ctx.addInitScript(() => {
      const d = Object.getOwnPropertyDescriptor(Worker.prototype, "onmessage");
      globalThis.heldMessages = [];
      Object.defineProperty(Worker.prototype, "onmessage", {
        get: d.get,
        set(handler) {
          d.set.call(this, (event) => {
            if (
              event.data?.action === "recognize" &&
              event.data?.status === "resolve" ||
              (event.data?.result && typeof event.data?.id === "number")
            )
              heldMessages.push(() => handler(event));
            else handler(event);
          });
        },
      });
    });
  const cdp = await ctx.browser().newBrowserCDPSession(),
    { id } = await cdp.send("Extensions.loadUnpacked", {
      path: process.cwd() + "/dist",
    });
  const settings = await ctx.newPage();
  await settings.goto(`chrome-extension://${id}/controller.html`);
  await settings.evaluate(
    async (p) =>
      chrome.storage.local.set({ "profile:http://127.0.0.1:4173": p }),
    {
      ...DEFAULT_PROFILE,
      mode,
      type,
      maxConsecutiveSkips: limit,
      ...(alphabet ? { alphabet } : {}),
      ...(crop ? { crop } : {}),
    },
  );
  await settings.close();
  const page = await ctx.newPage();
  await page.goto(`http://127.0.0.1:4173/?v3=${name}`);
  await page.waitForFunction(() => !!globalThis.Demo);
  await page.evaluate(() => {
    globalThis.clicks = 0;
    document.querySelector("#skip").addEventListener("click", () => clicks++);
  });
  const open = async () => {
    const { targetInfos } = await cdp.send("Target.getTargets", {
      filter: [{ type: "tab", exclude: false }],
    });
    const promise = ctx.waitForEvent("page", (p) =>
      p.url().includes("controller.html"),
    );
    await cdp.send("Extensions.triggerAction", {
      id,
      targetId: targetInfos.find((t) => t.url === page.url()).targetId,
    });
    const controller = await promise;
    await controller.waitForFunction(() => !!globalThis.CaptchaLab);
    return controller;
  };
  return { page, open, cdp, id };
}
async function timing(controller) {
  return controller.evaluate(async () => {
    const tabId = Number(new URLSearchParams(location.search).get("tab"));
    return (await chrome.tabs.sendMessage(tabId, { kind: "TIMING" })).value;
  });
}
async function settled(controller) {
  await controller.waitForFunction(
    () =>
      /Ответ внесён|Смена капчи подтверждена|Пауза|Наблюдение:/.test(
        document.querySelector("#status").textContent,
      ),
    {},
    { timeout: 35000 },
  );
}
try {
  let c = await setup("fast");
  let ui = await c.open();
  await settled(ui);
  assert.equal(await c.page.locator("#answer").inputValue(), "КЛЧ");
  let t = await timing(ui);
  assert.equal(t.timing.length, 1);
  assert.ok(t.timing[0].elapsedMs < 30000);
  report.cases.push({ name: "fast-correct", ...t.timing[0] });
  report.checks.push("cold fast correct response fills immediately");
  c = await setup("slow-image");
  const slowBytes = await readFile("tests/fixtures/synthetic/shapes-1.png");
  await c.page.route("**/slow-image.png", async (route) => {
    await new Promise((r) => setTimeout(r, 2200));
    await route.fulfill({
      status: 200,
      contentType: "image/png",
      body: slowBytes,
    });
  });
  await c.page.evaluate(() => {
    const old = document.querySelector("canvas"),
      img = new Image();
    img.setAttribute("data-captcha-image", "");
    img.style.width = "400px";
    img.style.height = "130px";
    img.src = "/slow-image.png";
    old.replaceWith(img);
  });
  ui = await c.open();
  await settled(ui);
  assert.equal(await c.page.locator("#answer").inputValue(), "КЛЧ");
  t = await timing(ui);
  assert.ok(t.timing[0].elapsedMs >= 1800 && t.timing[0].elapsedMs < 30000);
  report.cases.push({ name: "image-loading-in-budget", ...t.timing[0] });
  report.checks.push(
    "image loading is included in the original task timer; no timer reset when pixels become available",
  );
  c = await setup("low");
  await c.page.evaluate(() => {
    const x = document.querySelector("canvas").getContext("2d");
    x.fillStyle = "white";
    x.fillRect(0, 0, 400, 130);
  });
  ui = await c.open();
  await settled(ui);
  await ui.waitForFunction(() => CaptchaLab.stats.skips === 1);
  assert.equal(await c.page.evaluate(() => clicks), 1);
  t = await timing(ui);
  report.cases.push({ name: "low-confidence", ...t.timing[0] });
  report.checks.push(
    "completed low confidence skips immediately once and confirms change",
  );
  c = await setup("hang-late", { hang: true });
  await c.page.evaluate(async () => {
    const old = document.querySelector("canvas"),
      img = new Image();
    img.src = "http://127.0.0.1:4174/tests/fixtures/synthetic/shapes-1.png";
    img.setAttribute("data-captcha-image", "");
    img.style.width = "400px";
    await img.decode();
    old.replaceWith(img);
    document
      .querySelector("#skip")
      .addEventListener("click", () => img.replaceWith(old), {
        capture: true,
        once: true,
      });
  });
  ui = await c.open();
  await ui.waitForFunction(() => heldMessages.length > 0);
  await settled(ui);
  await ui.waitForFunction(
    () => CaptchaLab.stats.skips === 1,
    {},
    { timeout: 35000 },
  );
  t = await timing(ui);
  assert.equal(t.timing.length, 1);
  assert.equal(t.timing[0].kind, "skip");
  assert.ok(t.timing[0].elapsedMs >= 28000 && t.timing[0].elapsedMs <= 30000);
  await ui.evaluate(() => heldMessages.splice(0).forEach((f) => f()));
  await ui.waitForTimeout(500);
  assert.equal(await c.page.locator("#answer").inputValue(), "");
  assert.equal(await c.page.evaluate(() => clicks), 1);
  report.cases.push({ name: "hung-ocr-late-reply", ...t.timing[0] });
  report.checks.push(
    "28s independent watchdog verifies CORS screenshot in background, skips hung OCR, ignores delayed worker reply",
  );
  c = await setup("manual", { hang: true });
  ui = await c.open();
  await ui.waitForFunction(() => heldMessages.length > 0);
  await c.page.locator("#answer").fill("моё");
  await ui.waitForFunction(() =>
    document
      .querySelector("#status")
      .textContent.includes("Пользователь начал ввод"),
  );
  await ui.evaluate(() => heldMessages.splice(0).forEach((f) => f()));
  await ui.waitForTimeout(300);
  assert.equal(await c.page.locator("#answer").inputValue(), "моё");
  assert.equal(await c.page.evaluate(() => clicks), 0);
  assert.equal((await timing(ui)).timing.length, 0);
  report.checks.push(
    "manual input aborts OCR immediately and blocks fill/skip including late replies",
  );
  c = await setup("color-hang-late", {
    hang: true, type: "color",
    alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
    crop: {top:.15,bottom:.16,left:0,right:0},
  });
  await c.page.evaluate(() => Demo.selectSample("color-1"));
  ui = await c.open();
  await ui.waitForFunction(() => heldMessages.length > 0);
  await settled(ui);
  await ui.waitForFunction(() => CaptchaLab.stats.skips === 1, {}, {timeout:35000});
  t = await timing(ui);
  assert.equal(t.timing.length, 1);
  assert.equal(t.timing[0].kind, "skip");
  assert.ok(t.timing[0].elapsedMs >= 28000 && t.timing[0].elapsedMs <= 30000);
  await ui.evaluate(() => heldMessages.splice(0).forEach(f => f()));
  await ui.waitForTimeout(300);
  assert.equal(await c.page.locator("#answer").inputValue(), "");
  assert.equal(await c.page.evaluate(() => clicks), 1);
  report.cases.push({name:"hung-color-onnx-late-reply",...t.timing[0]});
  report.checks.push("hung ONNX color reply is skipped within 30s and a real late model reply is ignored");
  c = await setup("observe", { mode: "observe" });
  ui = await c.open();
  await ui.waitForFunction(() => CaptchaLab.observations.length === 1);
  assert.equal(await c.page.locator("#answer").inputValue(), "");
  assert.equal(await c.page.evaluate(() => clicks), 0);
  assert.equal(
    await ui.evaluate(() => CaptchaLab.observations[0].wouldFill),
    true,
  );
  await ui.locator("#observation-panel").evaluate((e) => (e.open = true));
  await ui.locator("#observations input").fill("КЛЧ");
  await ui.locator("#observations input").press("Tab");
  assert.equal(
    await ui.evaluate(() => CaptchaLab.observations[0].labelVerified),
    true,
  );
  report.checks.push(
    "observation mode logs decision/alternatives and human label without touching answer or skip",
  );
  await ui.evaluate(() => CaptchaLab.flushObservations());
  await ui.close();
  ui = await ctx.newPage();
  await ui.goto(`chrome-extension://${c.id}/controller.html`);
  await ui.waitForFunction(() => CaptchaLab?.observations.length > 0);
  assert.equal(
    await ui.evaluate(() => CaptchaLab.observations[0].answer),
    "КЛЧ",
  );
  assert.ok(
    await ui.evaluate(() =>
      CaptchaLab.observations[0].image.startsWith("data:image/png"),
    ),
  );
  report.checks.push(
    "human labels and image pixels persist in local IndexedDB across controller windows",
  );
  c = await setup("series", { limit: 2 });
  await c.page.evaluate(() => {
    let n = 0;
    const draw = () => {
      const canvas = document.querySelector("canvas"),
        x = canvas.getContext("2d");
      x.fillStyle = "white";
      x.fillRect(0, 0, 400, 130);
      x.fillStyle = "#bbb";
      x.fillRect(n + 1, 5, 2, 2);
      document.querySelector("[data-captcha-instruction]").textContent =
        "Type letters (Cyrillic) above the triangle. " + n;
    };
    const old = document.querySelector("#skip"),
      b = old.cloneNode(true);
    old.replaceWith(b);
    b.addEventListener("click", () => {
      clicks++;
      n++;
      draw();
    });
    draw();
  });
  ui = await c.open();
  await ui.locator("#auto").check();
  await ui.waitForFunction(
    () =>
      document.querySelector("#status").textContent.includes("лимит пропусков"),
    {},
    { timeout: 35000 },
  );
  assert.equal(await c.page.evaluate(() => clicks), 2);
  t = await timing(ui);
  assert.equal(t.timing.length, 2);
  report.cases.push(...t.timing.map((r, i) => ({ name: "series-" + i, ...r })));
  report.checks.push(
    "configured consecutive skip limit pauses after two confirmed skips; all-skip quality FAIL",
  );
  c = await setup("folder", { mode: "observe" });
  ui = await ctx.newPage();
  await ui.goto(`chrome-extension://${c.id}/controller.html`);
  await ui.waitForFunction(() => !!globalThis.CaptchaLab);
  await ui.locator("#observation-panel").evaluate((e) => (e.open = true));
  await ui
    .locator("#folder")
    .setInputFiles(path.resolve("tests/trainer-folder"));
  await ui.locator("#run-folder").click();
  await ui.waitForFunction(
    () =>
      CaptchaLab.observations.length === 2 &&
      document
        .querySelector("#status")
        .textContent.includes("Папка обработана"),
    {},
    { timeout: 35000 },
  );
  assert.equal(
    await ui.evaluate(() => CaptchaLab.stats.fills + CaptchaLab.stats.skips),
    0,
  );
  assert.equal(
    await ui.evaluate(() =>
      CaptchaLab.observations.every(
        (r) => r.labelVerified && r.source === "synthetic",
      ),
    ),
    true,
  );
  report.checks.push(
    "PNG directory + CSV uses the same local engines and labels; no page actions",
  );
  for (const kind of ["missing", "disabled", "unchanged"]) {
    c = await setup("button-" + kind);
    await c.page.evaluate((kind) => {
      const x = document.querySelector("canvas").getContext("2d");
      x.fillStyle = "white";
      x.fillRect(0, 0, 400, 130);
      const old = document.querySelector("#skip");
      if (kind === "missing") old.remove();
      if (kind === "disabled") old.disabled = true;
      if (kind === "unchanged") {
        const b = old.cloneNode(true);
        old.replaceWith(b);
        b.addEventListener("click", () => clicks++);
      }
    }, kind);
    ui = await c.open();
    await ui.waitForFunction(
      () =>
        /Пауза|остановлен/.test(document.querySelector("#status").textContent),
      {},
      { timeout: 35000 },
    );
    assert.equal(
      await c.page.evaluate(() => clicks),
      kind === "unchanged" ? 1 : 0,
    );
    report.checks.push(
      "button " + kind + " pauses with a reason and no repeated click",
    );
  }
} catch (e) {
  report.failure = e.stack;
  process.exitCode = 1;
  console.error(e);
} finally {
  report.maxActionMs = Math.max(0, ...report.cases.map((c) => c.elapsedMs));
  report.over30 = report.cases.filter((c) => c.elapsedMs > 30000).length;
  const reportDir = process.env.REPORT_DIR || "reports/iteration3";
  await mkdir(reportDir, { recursive: true });
  await writeFile(
    reportDir + "/browser-timing.json",
    JSON.stringify(report, null, 2),
  );
  await ctx?.close();
  server.close();
  imageServer.close();
  await rm(temp, { recursive: true, force: true });
  console.log(
    JSON.stringify({
      checks: report.checks.length,
      maxActionMs: report.maxActionMs,
      over30: report.over30,
      failure: report.failure,
    }),
  );
}
