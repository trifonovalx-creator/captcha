import { build } from "esbuild";
import { mkdir, cp, writeFile, readFile, readdir } from "node:fs/promises";
await mkdir("dist/vendor/core", { recursive: true });
await mkdir("dist/vendor/lang", { recursive: true });
await build({
  entryPoints: ["src/controller.js", "src/background.js", "src/content.js", "src/offscreen.js"],
  outdir: "dist",
  bundle: true,
  format: "iife",
  platform: "browser",
  target: "chrome120",
  legalComments: "eof",
});
await build({entryPoints:['src/options.js'],outfile:'dist/options.js',bundle:true,format:'esm',platform:'browser',target:'chrome120'});
for (const file of ["controller.html", "controller.css", "options.html", "offscreen.html"])
  await cp("src/" + file, "dist/" + file);
await cp(
  "node_modules/tesseract.js/dist/worker.min.js",
  "dist/vendor/worker.min.js",
);
for (const file of await readdir("node_modules/tesseract.js-core"))
  if (file.endsWith(".wasm") || file.endsWith(".wasm.js"))
    await cp(
      "node_modules/tesseract.js-core/" + file,
      "dist/vendor/core/" + file,
    );
for (const lang of ["eng", "rus"])
  await cp(
    `node_modules/@tesseract.js-data/${lang}/4.0.0/${lang}.traineddata.gz`,
    `dist/vendor/lang/${lang}.traineddata.gz`,
  );
const manifest = {
  manifest_version: 3,
  name: "Captcha Lab · локальный OCR",
  version: JSON.parse(await readFile("package.json")).version,
  minimum_chrome_version: "120",
  description:
    "Локальное распознавание и одно подтверждение ответа в текущей вкладке по клику на иконку.",
  permissions: ["activeTab", "scripting", "storage", "offscreen"],
  background: { service_worker: "background.js" },
  action: { default_title: "Распознать капчу в этой вкладке" },
  options_ui: {page:'options.html',open_in_tab:true},
  content_security_policy: {
    extension_pages:
      "script-src 'self' 'wasm-unsafe-eval'; object-src 'self'; worker-src 'self'; connect-src 'self'",
  },
};
await writeFile("dist/manifest.json", JSON.stringify(manifest, null, 2) + "\n");
const licenses = [];
for (const pkg of [
  "tesseract.js",
  "tesseract.js-core",
  "@tesseract.js-data/eng",
  "@tesseract.js-data/rus",
]) {
  const meta = JSON.parse(await readFile(`node_modules/${pkg}/package.json`));
  licenses.push(`${pkg}@${meta.version}: ${meta.license || "see upstream"}\n`);
  for (const name of ["LICENSE", "LICENSE.md", "LICENSE.txt"])
    try {
      licenses.push(await readFile(`node_modules/${pkg}/${name}`, "utf8"));
      break;
    } catch {}
}
await writeFile("dist/THIRD_PARTY_LICENSES.txt", licenses.join("\n"));
console.log(
  "Built dist/ with local worker, WASM, rus + eng data. No CDN needed.",
);

await build({
  entryPoints: ["src/models-worker.js"],
  outfile: "dist/models-worker.js",
  bundle: true,
  format: "esm",
  platform: "browser",
  target: "chrome120",
});
await mkdir("dist/vendor/ort", { recursive: true });
for (const ext of ["mjs", "wasm"])
  await cp(
    `node_modules/onnxruntime-web/dist/ort-wasm-simd-threaded.${ext}`,
    `dist/vendor/ort/ort-wasm-simd-threaded.${ext}`,
  );
await cp("models", "dist/models", { recursive: true });
await cp("third_party", "dist/third_party", { recursive: true });
