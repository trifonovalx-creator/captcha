import {readFile,writeFile} from 'node:fs/promises';
import {decideColor} from '../src/color-decision.js';
const input=JSON.parse(await readFile('reports/iteration4/tune-evidence/results.json','utf8'));
const task={min:5,max:5,alphabet:'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'};
function candidates(s,gray){return s.evidence.results.filter(c=>['original','contrast','easyocr-original',...(gray?['gray']:[])].includes(c.variant)).map(c=>({...c,variant:c.variant==='easyocr-original'?'easyocr-fallback':'helper-'+c.variant}));}
function score(threshold,gray){
 const rows=input.samples.map(s=>{const r=s.v3.accepted?s.v3:decideColor(task,candidates(s,gray),threshold);return {id:s.id,expected:s.expected,candidate:r.candidate,accepted:r.accepted,correct:r.accepted&&r.candidate===s.expected,incorrect:r.accepted&&r.candidate!==s.expected};});
 const correct=rows.filter(r=>r.correct).length,incorrect=rows.filter(r=>r.incorrect).length,filled=correct+incorrect;
 return {threshold,gray,n:rows.length,correct,incorrect,skipped:rows.length-filled,coverage:filled/rows.length,errorAmongFilled:filled?incorrect/filled:null,rows};
}
const report={calibrationOnly:true,real:0,thresholds:[90,92,94,96,98].map(t=>score(t,true)),ablations:[score(94,false),score(94,true)],preprocessing:input.samples[0].evidence.results.map((c,i)=>({variant:c.variant,correct:input.samples.filter(s=>s.evidence.results[i].text===s.expected).length,n:input.samples.length})),selected:94,rule:'Smallest tested threshold with zero erroneous fills on tune4; strong valid competitor ≥95 vetoes rescue; keep v3 early accept. Holdout labels not used.'};
await writeFile('reports/iteration4/calibration.json',JSON.stringify(report,null,2));
console.log(report.thresholds.map(({rows,...r})=>r));console.log(report.ablations.map(({rows,...r})=>r));
