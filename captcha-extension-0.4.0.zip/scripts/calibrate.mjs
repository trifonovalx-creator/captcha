import { readFile, writeFile } from "node:fs/promises";
import { decide, CYRILLIC, LATIN } from "../src/decision.js";
const report = JSON.parse(
  await readFile("reports/browser-calibration.json", "utf8"),
);
if (report.failure) throw Error("Calibration browser run failed");
const thresholds = {},
  evidence = {
    source: "calibration only; holdout not accessed",
    grid: [75, 78, 80, 82, 85, 88, 90, 92, 95, 98, 101],
    types: {},
  };
for (const type of ["shapes", "color", "lines"]) {
  const samples = report.samples.filter(
    (s) => s.type === type && s.split === "calibration",
  );
  if (samples.length !== 4)
    throw Error("Expected 4 calibration samples per type");
  const results = evidence.grid.map((threshold) => {
    const classified = samples.map((s) => ({
      ...s,
      ...decide(s.candidates, {
        type,
        alphabet: type === "shapes" ? CYRILLIC : LATIN,
        min: type === "shapes" ? 3 : 5,
        max: type === "color" ? 5 : type === "shapes" ? 4 : 6,
        threshold,
      }),
    }));
    return {
      threshold,
      filled: classified.filter((s) => s.accepted).length,
      wrong: classified.filter((s) => s.accepted && s.candidate !== s.expected)
        .length,
    };
  });
  const safe = results
    .filter((r) => r.wrong === 0)
    .sort((a, b) => b.filled - a.filled || b.threshold - a.threshold);
  thresholds[type] = safe[0].threshold;
  evidence.types[type] = {
    n: samples.length,
    gridResults: results,
    selected: safe[0],
  };
}
await writeFile(
  "src/thresholds.js",
  `// Selected on 4 calibration samples/type, before holdout. 101 = insufficient evidence to autofill.\nexport const THRESHOLDS = Object.freeze(${JSON.stringify(thresholds)});\n`,
);
await writeFile(
  "reports/calibration.json",
  JSON.stringify(evidence, null, 2) + "\n",
);
console.log(thresholds);
