import {recognize as v3} from '../tests/baseline-v3/pipeline.js';
import {recognize as next} from '../src/pipeline.js';
import {modelRecognize} from '../src/model-client.js';
import {loadImage,crop,transform,largeColorComponents} from '../src/image.js';
import {bridgedColor} from './color-preprocess-experiment.js';
export async function colorEvidence(task){
 const image=await loadImage(task.image),b=task.crop||{},area=crop(image,{x:image.width*(b.left||0),y:image.height*(b.top||0),width:image.width*(1-(b.left||0)-(b.right||0)),height:image.height*(1-(b.top||0)-(b.bottom||0))});
 const views=[['original',area],['contrast',transform(area,'contrast')],['gray',transform(area,'gray')],['components-color',largeColorComponents(area,false)],['components-black',largeColorComponents(area,true)],['bridged-color',bridgedColor(area)],['bridged-black',bridgedColor(area,true)]];
 const results=[];for(const [name,canvas] of views){const model=await modelRecognize('helper',canvas.toDataURL(),task.alphabet);results.push({variant:name,image:canvas.toDataURL(),...model});}
 const easy=await modelRecognize('easyocr-cyrillic',area.toDataURL(),task.alphabet);results.push({variant:'easyocr-original',image:area.toDataURL(),...easy});
 return {source:task.image,crop:area.toDataURL(),results};
}
globalThis.ColorLab={v3,next,colorEvidence};
