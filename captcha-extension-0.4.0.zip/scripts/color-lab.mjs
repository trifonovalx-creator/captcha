import {build} from 'esbuild';import {chromium} from 'playwright-core';import {mkdtemp,mkdir,cp,readFile,writeFile,rm} from 'node:fs/promises';import {tmpdir} from 'node:os';import path from 'node:path';import {v3Samples} from '../tests/v3-fixtures.js';
const label=process.env.RUN_LABEL||'seven-skips',manifest=process.env.MANIFEST;
const samples=manifest?JSON.parse(await readFile(manifest,'utf8')):v3Samples.filter(s=>s.type==='color'&&s.split==='eval3'&&[4,6,8,9,10,11,12].some(n=>s.id.endsWith('-'+n))).map(s=>({...s,file:`tests/fixtures/v3/${s.id}.png`}));
const temp=await mkdtemp(path.join(tmpdir(),'captcha-color-lab-')),out='reports/iteration4/'+label;let context;const report={real:0,samples:[]};await mkdir(out,{recursive:true});
try{
 const ext=path.join(temp,'ext');await cp('dist',ext,{recursive:true});await build({entryPoints:['scripts/color-lab-page.js'],outfile:path.join(ext,'lab.js'),bundle:true,platform:'browser',format:'iife'});await writeFile(path.join(ext,'lab.html'),'<meta charset="utf-8"><script src="lab.js"></script>');
 context=await chromium.launchPersistentContext(path.join(temp,'profile'),{executablePath:process.env.CHROME_PATH||'/tmp/captcha-chrome/opt/google/chrome/chrome',headless:true,ignoreDefaultArgs:['--disable-extensions'],args:['--enable-unsafe-extension-debugging','--no-sandbox','--disable-dev-shm-usage']});
 const cdp=await context.browser().newBrowserCDPSession(),{id}=await cdp.send('Extensions.loadUnpacked',{path:ext}),page=await context.newPage();await page.goto(`chrome-extension://${id}/lab.html`);await page.waitForFunction(()=>!!globalThis.ColorLab);report.browser=context.browser().version();
 for(const s of samples){
  const image='data:image/png;base64,'+(await readFile(s.file)).toString('base64'),task={image,type:'color',alphabet:s.alphabet||'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',min:s.min||5,max:s.max||5,crop:s.crop||{top:.15,bottom:.16,left:0,right:0}};
  const r=await page.evaluate(async task=>({v3:await ColorLab.v3(task),evidence:await ColorLab.colorEvidence(task),next:await ColorLab.next(task)}),task);
  const images={};for(const [name,data] of [['source',r.evidence.source],['crop',r.evidence.crop],...r.evidence.results.map(v=>[v.variant,v.image])]){const f=`${s.id}-${name}.png`;await writeFile(path.join(out,f),Buffer.from(data.split(',')[1],'base64'));images[name]=f;}
  for(const v of r.evidence.results)delete v.image;delete r.evidence.source;delete r.evidence.crop;
  for(const e of [r.v3,r.next]){delete e.debug;for(const c of e.candidates||[])delete c.blocks;}
  const row={...s,...r,images};report.samples.push(row);report.real=report.samples.filter(s=>s.source==='real').length;console.log(s.id,s.expected,'v3',r.v3.candidate,r.v3.accepted,...r.evidence.results.map(c=>`${c.variant}:${c.text}:${c.confidence.toFixed(2)}`));
  await writeFile(path.join(out,'results.json'),JSON.stringify(report,null,2));
 }
}finally{await context?.close();await rm(temp,{recursive:true,force:true});}
