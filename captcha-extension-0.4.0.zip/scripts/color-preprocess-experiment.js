import {canvas} from '../src/image.js';
// Experiment: join nearby pixels of similar RGB before filtering by glyph height.
// Unlike floor(RGB/40), this tolerates antialiasing and small watermark cuts.
export function bridgedColor(source, binary = false) {
 const w=source.width,h=source.height,p=source.getContext('2d',{willReadFrequently:true}).getImageData(0,0,w,h).data;
 const seen=new Uint8Array(w*h),keep=new Uint8Array(w*h);
 const distance=(a,b)=>(p[a*4]-p[b*4])**2+(p[a*4+1]-p[b*4+1])**2+(p[a*4+2]-p[b*4+2])**2;
 for(let i=0;i<seen.length;i++){
  if(seen[i]||Math.min(p[i*4],p[i*4+1],p[i*4+2])>=210)continue;
  const q=[i];seen[i]=1;let y0=h,y1=0;
  for(let j=0;j<q.length;j++){
   const a=q[j],x=a%w,y=Math.floor(a/w);y0=Math.min(y0,y);y1=Math.max(y1,y);
   for(let dy=-3;dy<=3;dy++)for(let dx=-3;dx<=3;dx++){
    const nx=x+dx,ny=y+dy,b=ny*w+nx;
    if(nx>=0&&nx<w&&ny>=0&&ny<h&&!seen[b]&&Math.min(p[b*4],p[b*4+1],p[b*4+2])<210&&distance(i,b)<45**2){seen[b]=1;q.push(b);}
   }
  }
  if(y1-y0>h*.34&&q.length>w*h*.0015)for(const a of q)keep[a]=1;
 }
 const out=canvas(w,h),ctx=out.getContext('2d'),d=ctx.createImageData(w,h);
 for(let i=0;i<keep.length;i++){for(let k=0;k<3;k++)d.data[i*4+k]=keep[i]?(binary?0:p[i*4+k]):255;d.data[i*4+3]=255;}
 ctx.putImageData(d,0,0);return out;
}
