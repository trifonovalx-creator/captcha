import {readFile,writeFile,mkdir,realpath} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {parseCSV} from '../src/observations.js';
const directory=process.argv[2],label=process.env.RUN_LABEL||'color-import';
if(!directory)throw Error('Usage: node scripts/compare-color-folder.mjs /path/to/PNG-and-labels.csv');
if(!/^[a-zA-Z0-9_-]+$/.test(label))throw Error('RUN_LABEL: letters, digits, underscore or hyphen only');
const root=await realpath(directory),rows=parseCSV(await readFile(path.join(root,'labels.csv'),'utf8'));
const samples=[];
for(const [i,r] of rows.entries()){
 if(r.type!=='color')continue;
 const file=await realpath(path.resolve(root,r.file));
 if(!file.startsWith(root+path.sep)||!file.toLowerCase().endsWith('.png'))throw Error('PNG must stay inside selected folder: '+r.file);
 const bytes=await readFile(file);
 if(!bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))throw Error('Invalid PNG: '+r.file);
 const alphabet=r.alphabet||'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',min=Number(r.min||5),max=Number(r.max||5);
 const expected=r.answer||null,verified=!!expected&&r.verified==='true';
 if(verified&&(expected.length<min||expected.length>max||[...expected].some(c=>!alphabet.includes(c))))throw Error('Verified label outside length/alphabet: '+r.file);
 samples.push({id:`import-${i+1}`,file,type:'color',source:['real','synthetic'].includes(r.source)?r.source:'unverified',expected,labelVerified:verified,min,max,alphabet,crop:{top:Number(r.crop_top||0),bottom:Number(r.crop_bottom||0),left:0,right:0}});
}
if(!samples.length)throw Error('No color PNG rows');
const out='reports/iteration4/'+label;await mkdir(out,{recursive:true});const manifest=out+'/manifest.json';await writeFile(manifest,JSON.stringify(samples,null,2));
execFileSync(process.execPath,['scripts/color-lab.mjs'],{stdio:'inherit',env:{...process.env,MANIFEST:manifest,RUN_LABEL:label}});
const report=JSON.parse(await readFile(out+'/results.json','utf8')),summary={};
for(const source of ['real','synthetic','unverified']){
 const rows=report.samples.filter(s=>s.source===source),verified=rows.filter(s=>s.labelVerified);
 summary[source]={total:rows.length,verified:verified.length,excluded:rows.length-verified.length};
 for(const engine of ['v3','next'])summary[source][engine]={correct:verified.filter(s=>s[engine].accepted&&s[engine].candidate===s.expected).length,incorrect:verified.filter(s=>s[engine].accepted&&s[engine].candidate!==s.expected).length,skipped:verified.filter(s=>!s[engine].accepted).length};
}
await writeFile(out+'/comparison.json',JSON.stringify(summary,null,2));console.log(summary);
