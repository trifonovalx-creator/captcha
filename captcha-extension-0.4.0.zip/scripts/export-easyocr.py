import json,torch,onnxruntime as ort,numpy as np
from pathlib import Path
import easyocr
from easyocr.config import imgH
root=Path('/workspace/captcha');torch.set_num_threads(2)
r=easyocr.Reader(['ru','en'],gpu=False,detector=False,model_storage_directory='/workspace/captcha-research/easyocr-weights',download_enabled=False,verbose=False,quantize=False)
class Export(torch.nn.Module):
 def __init__(self,m):super().__init__();self.m=m
 def forward(self,x):
  features=self.m.FeatureExtraction(x).mean(dim=2).transpose(1,2)
  return self.m.Prediction(self.m.SequenceModeling(features).contiguous())
m=Export(r.recognizer).eval();checks=[]
for w in [64,192,320]:
 x=torch.rand(1,1,imgH,w)*2-1
 with torch.no_grad():a=r.recognizer(x,torch.zeros(1,1,dtype=torch.long));b=m(x)
 assert torch.max(torch.abs(a-b)).item()<1e-4
 checks.append({'width':w,'torchMaxAbs':torch.max(torch.abs(a-b)).item()})
torch.onnx.export(m,torch.zeros(1,1,imgH,320),str(root/'models/easyocr-cyrillic.onnx'),input_names=['image'],output_names=['logits'],dynamic_axes={'image':{3:'width'},'logits':{1:'time'}},opset_version=17,dynamo=False)
s=ort.InferenceSession(str(root/'models/easyocr-cyrillic.onnx'),providers=['CPUExecutionProvider'])
for c in checks:
 x=torch.rand(1,1,imgH,c['width'])*2-1
 with torch.no_grad():a=m(x).numpy()
 b=s.run(None,{'image':x.numpy()})[0];c['onnxMaxAbs']=float(np.max(np.abs(a-b)));assert np.allclose(a,b,atol=2e-4)
(root/'models/easyocr-cyrillic.json').write_text(json.dumps({'charset':['']+list(r.character),'height':imgH,'layout':'NCHW','weightsMD5':'19f85f43d9128a89ac21b8d6a06973fe'}))
(root/'reports/iteration3/export-parity.json').write_text(json.dumps(checks,indent=2));print('Exported EasyOCR, height',imgH,checks)
