import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
const [file, directory] = process.argv.slice(2);
if (!file || !directory)
  throw Error(
    "Usage: node scripts/export-training-folder.mjs observations.json output-folder",
  );
const rows = JSON.parse(await readFile(file, "utf8")),
  csv = [
    [
      "file",
      "type",
      "answer",
      "source",
      "min",
      "max",
      "alphabet",
      "crop_top",
      "crop_bottom",
    ],
  ];
await mkdir(directory, { recursive: true });
for (const [i, r] of rows.entries()) {
  if (!r.image || !r.labelVerified || !r.answer) continue;
  if (!r.image.startsWith("data:image/png;base64,"))
    throw Error("Expected PNG observation");
  const name = `sample-${i + 1}.png`,
    t = r.task || {},
    crop = t.crop || {};
  await writeFile(
    path.join(directory, name),
    Buffer.from(r.image.split(",")[1], "base64"),
  );
  csv.push([
    name,
    r.type,
    r.answer,
    r.source || "unverified",
    t.min || 3,
    t.max || 6,
    t.alphabet || "",
    crop.top || 0,
    crop.bottom || 0,
  ]);
}
const quote = (v) => '"' + String(v).replaceAll('"', '""') + '"';
await writeFile(
  path.join(directory, "labels.csv"),
  csv.map((r) => r.map(quote).join(",")).join("\n") + "\n",
);
console.log("Verified observations exported:", csv.length - 1);
