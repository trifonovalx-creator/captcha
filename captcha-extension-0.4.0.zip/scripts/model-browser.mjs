import { build } from "esbuild";
import { chromium } from "playwright-core";
import { mkdtemp, mkdir, cp, writeFile, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { v3Samples } from "../tests/v3-fixtures.js";
import { parseCSV } from "../src/observations.js";
const dataset = process.env.DATASET || "diagnostics",
  label = process.env.RUN_LABEL || "model-diagnostics";
const temp = await mkdtemp(path.join(tmpdir(), "captcha-models-"));
let context;
const report = {
  dataset,
  label,
  real: 0,
  synthetic: 0,
  unverified: 0,
  samples: [],
  network: [],
};
try {
  const ext = path.join(temp, "extension");
  await cp("dist", ext, { recursive: true });
  await build({
    entryPoints: ["scripts/research-page.js"],
    outfile: path.join(ext, "research.js"),
    bundle: true,
    format: "iife",
    platform: "browser",
  });
  await writeFile(
    path.join(ext, "research.html"),
    '<meta charset="utf-8"><script src="research.js"></script>',
  );
  context = await chromium.launchPersistentContext(path.join(temp, "profile"), {
    executablePath:
      process.env.CHROME_PATH || "/tmp/captcha-chrome/opt/google/chrome/chrome",
    headless: true,
    ignoreDefaultArgs: ["--disable-extensions"],
    args: [
      "--enable-unsafe-extension-debugging",
      "--no-sandbox",
      "--disable-dev-shm-usage",
    ],
  });
  context.on("request", (r) => {
    if (!r.url().startsWith("data:")) report.network.push(r.url());
  });
  const cdp = await context.browser().newBrowserCDPSession(),
    { id } = await cdp.send("Extensions.loadUnpacked", { path: ext }),
    page = await context.newPage();
  await page.goto(`chrome-extension://${id}/research.html`);
  await page.waitForFunction(() => !!globalThis.Research);
  report.browser = context.browser().version();
  let samples;
  if (dataset === "folder") {
    const directory = process.env.DIRECTORY;
    if (!directory) throw Error("Нужен DIRECTORY с PNG и labels.csv");
    const rows = parseCSV(
      await readFile(path.join(directory, "labels.csv"), "utf8"),
    );
    for (const r of rows) {
      const f = path.resolve(directory, r.file);
      if (
        !f.startsWith(path.resolve(directory) + path.sep) ||
        !f.toLowerCase().endsWith(".png")
      )
        throw Error(
          "CSV должен ссылаться только на PNG внутри выбранной папки.",
        );
    }
    samples = rows.map((r) => ({
      id: r.file,
      file: path.resolve(directory, r.file),
      type: r.type,
      expected: r.answer || null,
      source: r.source || "unverified",
      split: "folder",
      min: Number(r.min || 3),
      max: Number(r.max || 6),
      alphabet: r.alphabet || undefined,
      crop: {
        top: Number(r.crop_top || 0),
        bottom: Number(r.crop_bottom || 0),
        left: 0,
        right: 0,
      },
    }));
  } else if (dataset === "diagnostics") {
    const meta = JSON.parse(
      await readFile("reports/iteration2/data-manifest.json"),
    );
    samples = meta.samples.filter((s) => s.split === "audit");
  } else samples = v3Samples.filter((s) => s.split === dataset);
  for (const s of samples) {
    let image;
    const file = s.file || `tests/fixtures/v3/${s.id}.png`;
    try {
      image =
        "data:image/png;base64," + (await readFile(file)).toString("base64");
    } catch {
      image = await page.evaluate((s) => Research.renderFresh(s), s);
      await mkdir("tests/fixtures/v3", { recursive: true });
      await writeFile(file, Buffer.from(image.split(",")[1], "base64"));
    }
    const task = {
      image,
      type: s.type,
      alphabet:
        s.alphabet ||
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
      min: s.min,
      max: s.max,
      crop: s.crop,
    };
    const row = {
      id: s.id,
      type: s.type,
      split: s.split,
      source: s.source,
      expected: s.expected,
      file,
      engines: {},
    };
    for (const engine of ["v2", "next"]) {
      const start = Date.now();
      try {
        const r = await page.evaluate(
          async ({ engine, task }) => {
            const result = await Research[engine](task);
            return {
              ...result,
              debug: result.debug?.map(({ image, ...r }) => r),
              candidates: result.candidates?.map(({ blocks, ...c }) => c),
            };
          },
          { engine, task },
        );
        row.engines[engine] = { ...r, ms: Date.now() - start };
      } catch (e) {
        row.engines[engine] = {
          error: e.message,
          accepted: false,
          ms: Date.now() - start,
        };
      }
    }
    report.samples.push(row);
    if (s.source === "real" || s.source === "trainer") report.real++;
    else if (s.source === "synthetic") report.synthetic++;
    else report.unverified++;
    console.log(
      s.id,
      s.expected,
      ...Object.entries(row.engines).map(
        ([k, r]) =>
          `${k}:${r.candidate} ${Math.round(r.confidence || 0)} ${r.accepted ? "FILL" : "REFUSE"} ${r.error || ""}`,
      ),
    );
    await mkdir("reports/iteration3", { recursive: true });
    await writeFile(
      `reports/iteration3/${label}.json`,
      JSON.stringify(report, null, 2),
    );
  }
} finally {
  await context?.close();
  await rm(temp, { recursive: true, force: true });
}
