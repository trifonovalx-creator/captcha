"""Package the tested extension, source, local models, demo and current report."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json

root = Path(__file__).resolve().parent.parent
version = json.loads((root / 'package.json').read_text())['version']
manifest = json.loads((root / 'dist/manifest.json').read_text())
assert manifest['version'] == version
assert 'default_popup' not in manifest['action']
tests = json.loads((root / 'reports/iteration5/browser.json').read_text())
assert not tests.get('failure'), 'Browser checks must pass before packaging'
assert len(tests['cases']) >= 5
output = root / f'captcha-extension-{version}.zip'
files = set()
for name in ['dist', 'src', 'models', 'third_party', 'demo', 'scripts', 'tests']:
    for p in (root / name).rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix == '.pyc':
            continue
        rel = p.relative_to(root).as_posix()
        if rel.startswith('tests/baseline-0.3.1/archive/'):
            continue
        files.add(p)
for name in ['README.md', 'INSTALL.md', 'package.json', 'package-lock.json', '.gitignore', 'reports/RESULTS.md']:
    files.add(root / name)
files.update(p for p in (root / 'reports/iteration5').rglob('*') if p.is_file())
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(files):
        z.write(p, p.relative_to(root).as_posix())
with ZipFile(output) as z:
    assert z.testzip() is None
    assert json.loads(z.read('dist/manifest.json'))['version'] == version
    for marker in [b'__held', b'__lateAt', b'__trace']:
        assert marker not in z.read('dist/offscreen.js'), 'Test-only hooks leaked into dist'
assert output.stat().st_size < 100 * 1024 * 1024, 'Archive exceeds GitHub file limit'
print(json.dumps({'file': output.name, 'bytes': output.stat().st_size,
                  'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                  'manifest': 'dist/manifest.json', 'version': version,
                  'files': len(files)}, indent=2))
