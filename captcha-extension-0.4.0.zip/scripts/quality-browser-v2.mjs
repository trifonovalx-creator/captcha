import { chromium } from "playwright-core";
import { serve } from "./serve.mjs";
import { mkdtemp, rm, readFile, writeFile, cp, mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import assert from "node:assert/strict";
import { v3Samples } from "../tests/v3-fixtures.js";
import { DEFAULT_PROFILE } from "../src/profile.js";
const server = serve(),
  temp = await mkdtemp(path.join(tmpdir(), "captcha-quality-v3-"));
let ctx;
const report = { real: 0, source: "synthetic", rows: [], checks: [] };
try {
  const archivePath = path.join(temp, "frozen");
  await mkdir(archivePath);
  await cp("tests/baseline-v2/extension", path.join(archivePath, "dist"), {
    recursive: true,
  });
  await cp("dist/vendor", path.join(archivePath, "dist/vendor"), {
    recursive: true,
  });
  ctx = await chromium.launchPersistentContext(temp, {
    executablePath:
      process.env.CHROME_PATH || "/tmp/captcha-chrome/opt/google/chrome/chrome",
    headless: true,
    ignoreDefaultArgs: ["--disable-extensions"],
    viewport: { width: 1280, height: 1000 },
    args: [
      "--enable-unsafe-extension-debugging",
      "--no-sandbox",
      "--disable-dev-shm-usage",
    ],
  });
  report.browser = ctx.browser().version();
  const cdp = await ctx.browser().newBrowserCDPSession(),
    { id } = await cdp.send("Extensions.loadUnpacked", {
      path: path.join(archivePath, "dist"),
    });
  const settings = await ctx.newPage();
  await settings.goto(`chrome-extension://${id}/controller.html`);
  for (const s of v3Samples.filter((s) => s.split === "eval3")) {
    await settings.evaluate(
      (p) => chrome.storage.local.set({ "profile:http://127.0.0.1:4173": p }),
      {
        ...DEFAULT_PROFILE,
        skipLowConfidence: true,
        type: s.type,
        mode: "auto",
        alphabet: s.alphabet,
        crop: s.crop,
        debug: false,
      },
    );
    const page = await ctx.newPage();
    await page.goto("http://127.0.0.1:4173/?quality=" + s.id);
    await page.waitForFunction(() => !!globalThis.Demo);
    const image =
      "data:image/png;base64," +
      (await readFile(`tests/fixtures/v3/${s.id}.png`)).toString("base64");
    await page.evaluate(
      async ({ s, image }) => {
        Demo.selectSample(s.type + "-1");
        const img = new Image();
        img.src = image;
        await img.decode();
        const c = document.querySelector("canvas");
        c.width = img.width;
        c.height = img.height;
        c.getContext("2d").drawImage(img, 0, 0);
        document.querySelector("#truth").textContent = s.expected;
        document.querySelector("#sample-id").textContent = s.id;
        document.querySelector("[data-captcha-min]").textContent =
          "min " + s.min;
        document.querySelector("[data-captcha-max]").textContent =
          "max " + s.max;
        document.querySelector("#answer").removeAttribute("minlength");
        document.querySelector("#answer").maxLength = s.max;
        document.querySelector("#answer").minLength = s.min;
      },
      { s, image },
    );
    await page.evaluate(() => {
      globalThis.actions = [];
      document
        .querySelector("#answer")
        .addEventListener("input", (e) =>
          actions.push({ kind: "fill", actionAt: Date.now() }),
        );
      document
        .querySelector("#skip")
        .addEventListener("click", () =>
          actions.push({ kind: "skip", actionAt: Date.now() }),
        );
    });
    const detectedAt = Date.now();
    const { targetInfos } = await cdp.send("Target.getTargets", {
      filter: [{ type: "tab", exclude: false }],
    });
    const ready = ctx.waitForEvent("page", (p) =>
      p.url().includes("controller.html?tab="),
    );
    await cdp.send("Extensions.triggerAction", {
      id,
      targetId: targetInfos.find((t) => t.url === page.url()).targetId,
    });
    const ui = await ready;
    await ui.waitForFunction(
      () =>
        globalThis.CaptchaLab &&
        (CaptchaLab.stats.fills + CaptchaLab.stats.skips > 0 ||
          /Пауза|ошибка|остановлен/.test(
            document.querySelector("#status").textContent,
          )),
      {},
      { timeout: 35000 },
    );
    const state = await ui.evaluate(async () => {
      const tabId = Number(new URLSearchParams(location.search).get("tab"));
      return {
        stats: CaptchaLab.stats,
        result: CaptchaLab.lastResult && {
          candidate: CaptchaLab.lastResult.candidate,
          confidence: CaptchaLab.lastResult.confidence,
          path: CaptchaLab.lastResult.path,
        },
        status: document.querySelector("#status").textContent,
      };
    });
    state.timing = {
      timing: await page.evaluate(
        (start) =>
          actions.map((a) => ({
            ...a,
            elapsedMs: a.actionAt - start,
            overrun: a.actionAt - start > 30000,
          })),
        detectedAt,
      ),
    };
    const value = await page.locator("#answer").inputValue(),
      filled = state.stats.fills === 1,
      skipped = state.stats.skips === 1;
    if (!filled && !skipped) throw Error(s.id + ": " + state.status);
    const old = JSON.parse(
      await readFile("reports/iteration3/model-evaluation.json"),
    ).samples.find((r) => r.id === s.id).engines.v2;
    const row = {
      id: s.id,
      type: s.type,
      alphabet: s.alphabet,
      source: "synthetic",
      expected: s.expected,
      value,
      candidate: state.result?.candidate,
      correct: filled && value === s.expected,
      incorrect: filled && value !== s.expected,
      skipped,
      ...state,
      baseline: {
        accepted: old.accepted,
        candidate: old.candidate,
        correct: old.accepted && old.candidate === s.expected,
        incorrect: old.accepted && old.candidate !== s.expected,
      },
    };
    assert.equal(state.timing.timing.length, 1);
    assert.ok(state.timing.timing[0].elapsedMs <= 30000);
    report.rows.push(row);
    console.log(
      s.id,
      filled ? value : "SKIP",
      state.timing.timing[0].elapsedMs,
    );
    await ui.close();
    await page.close();
    await writeFile(
      "reports/iteration3/browser-v2-quality.json",
      JSON.stringify(report, null, 2),
    );
  }
  report.summary = {};
  for (const type of ["shapes", "color", "lines"]) {
    const rows = report.rows.filter((r) => r.type === type);
    report.summary[type] = {
      n: rows.length,
      correct: rows.filter((r) => r.correct).length,
      incorrect: rows.filter((r) => r.incorrect).length,
      skipped: rows.filter((r) => r.skipped).length,
      maxActionMs: Math.max(...rows.map((r) => r.timing.timing[0].elapsedMs)),
      over30: rows.filter((r) => r.timing.timing[0].elapsedMs > 30000).length,
      baselineCorrect: rows.filter((r) => r.baseline.correct).length,
      baselineIncorrect: rows.filter((r) => r.baseline.incorrect).length,
    };
    report.summary[type].useful = report.summary[type].correct > 0;
  }
  report.checks.push(
    "Frozen v2 archive: 36 identical PNGs through native fill/skip; low-confidence auto-skip enabled; action time measured externally from icon request",
  );
} catch (e) {
  report.failure = e.stack;
  process.exitCode = 1;
  console.error(e);
} finally {
  await writeFile(
    "reports/iteration3/browser-v2-quality.json",
    JSON.stringify(report, null, 2),
  );
  await ctx?.close();
  server.close();
  await rm(temp, { recursive: true, force: true });
  console.log(report.summary || report.failure);
}
