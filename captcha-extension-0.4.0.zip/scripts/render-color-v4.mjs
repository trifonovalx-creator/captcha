import {chromium} from 'playwright-core';
import {mkdir,writeFile} from 'node:fs/promises';
import {colorV4Samples,renderColorV4} from '../tests/color-v4-fixtures.js';
const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'/tmp/captcha-chrome/opt/google/chrome/chrome',args:['--no-sandbox','--disable-dev-shm-usage']});
try {
 const page=await browser.newPage();await mkdir('tests/fixtures/v4',{recursive:true});
 for(const s of colorV4Samples){const url=await page.evaluate(`(${renderColorV4.toString()})(${JSON.stringify(s)})`);await writeFile(s.file,Buffer.from(url.split(',')[1],'base64'));}
 await mkdir('reports/iteration4',{recursive:true});
 await writeFile('reports/iteration4/data-manifest.json',JSON.stringify({real:0,samples:colorV4Samples},null,2));
 for(const split of ['tune4','holdout4']) await writeFile(`reports/iteration4/${split}.json`,JSON.stringify(colorV4Samples.filter(s=>s.split===split),null,2));
}finally{await browser.close();}
