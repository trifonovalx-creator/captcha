"""Local comparisons; these results alone never enable a browser engine."""
import os,json,io,time,hashlib
from pathlib import Path
os.environ['OMP_NUM_THREADS']='2'
import torch,numpy as np,onnxruntime as ort,easyocr,ddddocr
from PIL import Image
# API-compatible name for the pinned ddddocr release; actual Lanczos resampling retained.
if not hasattr(Image,'ANTIALIAS'):Image.ANTIALIAS=Image.Resampling.LANCZOS
root=Path('/workspace/captcha');out=root/'reports/iteration3';out.mkdir(exist_ok=True)
torch.set_num_threads(2)
reader=easyocr.Reader(['ru','en'],gpu=False,detector=False,model_storage_directory='/workspace/captcha-research/easyocr-weights',download_enabled=False,verbose=False,quantize=False)
ddd=ddddocr.DdddOcr(show_ad=False)
sess=ort.InferenceSession(str(root/'models/helper.onnx'),providers=['CPUExecutionProvider'])
charset=json.loads((root/'models/helper.json').read_text())['charset']
CYR='АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ';LAT='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
def png(im):b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()
def helper(im):
 w,h=im.size;rw=int(np.ceil(48*w/h));tw=max(320,int(48*w/h));rw=min(rw,tw)
 a=np.array(im.convert('RGB').resize((rw,48),Image.Resampling.BICUBIC))[:,:,::-1].astype('float32')/127.5-1
 x=np.zeros((1,3,48,tw),np.float32);x[0,:,:,:rw]=a.transpose(2,0,1)
 y=sess.run(None,{sess.get_inputs()[0].name:x})[0][0];last=0;text='';probs=[]
 for row in y:
  k=int(row.argmax())
  if k and k!=last:text+=charset[k];probs.append(float(row[k]))
  last=k
 return {'text':text,'confidence':min(probs,default=0)*100}
def easy(im,alphabet):
 a=np.array(im.convert('L'));h,w=a.shape
 r=reader.recognize(a,horizontal_list=[[0,w,0,h]],free_list=[],decoder='greedy',allowlist=alphabet,detail=1,paragraph=False,batch_size=1,workers=0)
 return {'text':''.join(v[1] for v in r),'confidence':min((float(v[2]) for v in r),default=0)*100}
rows=[]
manifest=os.environ.get('MANIFEST')
if manifest:samples=json.loads(Path(manifest).read_text())
else:
 base=json.loads((root/'reports/iteration2/data-manifest.json').read_text())['samples'];samples=[s for s in base if s['split']=='tune']
for s in samples:
 im=Image.open(root/s['file']).convert('RGB');t=s['type'];regions=[]
 if t=='shapes':
  for i in s['triangles']:
   regions.append(im.crop((i*50,0,(i+1)*50,95)))
 else:
  b=s['crop'];w,h=im.size;regions=[im.crop((round(w*b['left']),round(h*b['top']),round(w*(1-b['right'])),round(h*(1-b['bottom']))))]
 results={};start=time.monotonic()
 es=[easy(r,s.get('alphabet') or (CYR if t=='shapes' else LAT)) for r in regions]
 results['easyocr']={'text':''.join(r['text'] for r in es),'confidence':min(r['confidence'] for r in es)}
 if t!='shapes' and not any(c in CYR for c in s.get('alphabet','')):
  results['helper']=helper(regions[0]);results['ddddocr']={'text':ddd.classification(png(regions[0]))}
 row={**{k:s[k] for k in ['id','type','expected','source']},'engines':results,'pythonMs':(time.monotonic()-start)*1000};rows.append(row)
 print(s['id'],s['expected'],results,flush=True)
 (out/os.environ.get('OUTPUT','python-models.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2))
