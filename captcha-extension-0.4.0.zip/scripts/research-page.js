import { recognize as v2 } from "../tests/baseline-v2/ocr.js";
import { recognize as next, terminateAll } from "../src/pipeline.js";
import { modelRecognize } from "../src/model-client.js";
import { renderFresh } from "../tests/fresh-fixtures.js";
globalThis.Research = { v2, next, modelRecognize, renderFresh, terminateAll };
