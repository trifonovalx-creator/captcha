import { readFile } from "node:fs/promises";
import { evaluateObservations } from "../src/observations.js";
const file = process.argv[2];
if (!file)
  throw Error(
    "Usage: node scripts/score-observations.mjs exported-observations.json",
  );
const rows = evaluateObservations(JSON.parse(await readFile(file, "utf8"))),
  groups = {};
for (const r of rows) {
  const key = r.source + "/" + r.type;
  const g = (groups[key] ??= {
    n: 0,
    bestCorrect: 0,
    hypotheticalCorrect: 0,
    hypotheticalIncorrect: 0,
    refused: 0,
  });
  g.n++;
  g.bestCorrect += Number(r.bestCorrect);
  g.hypotheticalCorrect += Number(r.correct);
  g.hypotheticalIncorrect += Number(r.incorrect);
  g.refused += Number(r.abstained);
}
console.log(
  JSON.stringify(
    {
      mode: "observation; hypothetical decisions only, no actual fills",
      verified: rows.length,
      groups,
    },
    null,
    2,
  ),
);
