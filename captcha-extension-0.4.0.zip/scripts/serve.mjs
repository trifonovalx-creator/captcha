import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export function serve(port = 4173) {
  return http
    .createServer(async (req, res) => {
      try {
        const route = decodeURIComponent(
          new URL(req.url, "http://local").pathname,
        );
        const file = path.resolve(
          root,
          "." + (route === "/" ? "/demo/index.html" : route),
        );
        if (!file.startsWith(root + path.sep)) throw Error();
        if (!(await stat(file)).isFile()) throw Error();
        const types = {
          ".html": "text/html; charset=utf-8",
          ".js": "text/javascript",
          ".css": "text/css",
          ".json": "application/json",
          ".png": "image/png",
          ".svg": "image/svg+xml",
        };
        res.setHeader(
          "Content-Type",
          types[path.extname(file)] || "application/octet-stream",
        );
        res.end(await readFile(file));
      } catch {
        res.writeHead(404);
        res.end("Not found");
      }
    })
    .listen(port, "127.0.0.1");
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  serve(Number(process.env.PORT) || 4173);
  console.log(
    "Demo on port " +
      (process.env.PORT || 4173) +
      " (path /demo/ is /demo/index.html).",
  );
}
