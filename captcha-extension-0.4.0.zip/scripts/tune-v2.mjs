// Select only from the newly frozen tune set; never reads final evaluation results.
import { readFile, writeFile } from "node:fs/promises";
import { decide, LATIN, CYRILLIC } from "../src/decision.js";
const input = JSON.parse(
  await readFile("reports/iteration2/symbols-tune/results.json"),
);
const grid = [0, 25, 50, 65, 75, 80, 85, 90, 92, 94, 96, 98, 101],
  thresholds = {},
  report = {
    grid,
    selection:
      "maximize correct fills with zero incorrect on tune, choose highest threshold at equal coverage; color remains disabled for insufficient evidence",
    types: {},
  };
for (const type of ["shapes", "color", "lines"]) {
  const samples = input.samples.filter((s) => s.type === type);
  const rows = grid.map((threshold) => {
    const classified = samples.map((s) => ({
      ...s,
      ...decide(s.candidates, {
        type,
        alphabet: type === "shapes" ? CYRILLIC : LATIN,
        min: type === "shapes" ? 3 : 5,
        max: type === "shapes" ? 4 : type === "color" ? 5 : 6,
        shapeConfidence: s.shapeConfidence ?? 100,
        threshold,
      }),
    }));
    const correct = classified.filter(
        (s) => s.accepted && s.candidate === s.expected,
      ).length,
      incorrect = classified.filter(
        (s) => s.accepted && s.candidate !== s.expected,
      ).length;
    return {
      threshold,
      n: samples.length,
      bestCorrect: classified.filter((s) => s.candidate === s.expected).length,
      correct,
      incorrect,
      skipped: samples.length - correct - incorrect,
      coverage: (correct + incorrect) / samples.length,
      errorRate: correct + incorrect ? incorrect / (correct + incorrect) : null,
    };
  });
  const chosen = rows
    .filter((r) => !r.incorrect)
    .sort((a, b) => b.correct - a.correct || b.threshold - a.threshold)[0];
  thresholds[type] =
    type === "color" || type === "lines" ? 101 : chosen.threshold;
  report.types[type] = { rows, selected: thresholds[type] };
}
await writeFile(
  "src/thresholds.js",
  `// v2: frozen on fresh tune only (8 synthetic/type). Color remains manual candidates.\nexport const THRESHOLDS=Object.freeze(${JSON.stringify(thresholds)});\n`,
);
await writeFile(
  "reports/iteration2/tuning.json",
  JSON.stringify(report, null, 2),
);
console.log(thresholds, report.types);
