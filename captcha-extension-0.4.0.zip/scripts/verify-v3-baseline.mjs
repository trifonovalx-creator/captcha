import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const files={...JSON.parse(await readFile('tests/baseline-v3/snapshot.json','utf8')),...JSON.parse(await readFile('tests/baseline-v3/assets.json','utf8'))};
for(const [file,expected] of Object.entries(files)){
 const actual=createHash('sha256').update(await readFile(file)).digest('hex');
 if(actual!==expected)throw Error('Frozen v3 file/asset mismatch: '+file);
}
await writeFile('reports/iteration4/baseline-verification.json',JSON.stringify({checked:Object.keys(files).length,allMatch:true},null,2));
console.log('Frozen v3 code and shared assets verified:',Object.keys(files).length);
