import {DEFAULT_PROFILE} from './profile.js';
import {capturePage,verifyVisibleImage} from './screen-capture.js';
const launches=new Set(),jobs=new Map();
let creating;
let captureQueue=Promise.resolve();
async function captureSerial(operation,deadline){
  const previous=captureQueue;let release;captureQueue=new Promise(r=>release=r);
  await previous;
  try{
    const last=(await chrome.storage.session.get('lastCaptureAt')).lastCaptureAt||0;
    const delay=Math.max(0,last+550-Date.now());
    if(delay)await new Promise(r=>setTimeout(r,delay));
    if(deadline && Date.now()>=deadline)throw Error('Дедлайн захвата истёк.');
    await chrome.storage.session.set({lastCaptureAt:Date.now()});
    return await operation();
  }finally{release();}
}
async function status(tabId,state,reason) {
  const badges={waiting:'…',ocr:'OCR',submitted:'OK',filled:'?',observed:'OBS',busy:'OCR',already:'OK'};
  await chrome.storage.session.set({['status:'+tabId]:{state,reason,at:Date.now()}});
  await Promise.allSettled([
    chrome.action.setBadgeText({tabId,text:badges[state]||'!'}),
    chrome.action.setBadgeBackgroundColor({tabId,color:state==='submitted'?'#21845c':'#5753a0'}),
    chrome.action.setTitle({tabId,title:'Captcha Lab: '+reason}),
  ]);
}
async function ensureOffscreen() {
  if(creating)return creating;
  creating=(async()=>{
    const contexts=await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[chrome.runtime.getURL('offscreen.html')]});
    if(!contexts.length)await chrome.offscreen.createDocument({url:'offscreen.html',reasons:['WORKERS','BLOBS'],justification:'Локальный OCR изображения с активной вкладки: Canvas, Tesseract и ONNX Web Workers.'});
  })();
  try{await creating;}finally{creating=null;}
}
async function targetFor(tabId,profile) {
  if(!profile.frameSelector)return {frameIds:[0]};
  const nonce=crypto.randomUUID();
  const probe=await chrome.scripting.executeScript({target:{tabId},func:(selector,nonce)=>{
    try {
    let list;try{list=document.querySelectorAll(selector);}catch{throw Error('Некорректный селектор фрейма.');}
    if(list.length!==1||!(list[0] instanceof HTMLIFrameElement))throw Error('Фрейм: нужен ровно один iframe.');
    try{
      const doc=list[0].contentDocument;
      if(!doc?.documentElement)throw Error();
      doc.documentElement.setAttribute('data-captcha-frame-probe',nonce);
    }catch{throw Error('Фрейм недоступен с activeTab (другой origin или sandbox). Откройте страницу фрейма отдельно.');}
    return {ok:true};
    } catch(error) {return {ok:false,error:error.message};}
  },args:[profile.frameSelector,nonce]});
  if(!probe[0]?.result?.ok)throw Error(probe[0]?.result?.error || 'Не удалось проверить доступ к фрейму.');
  const frames=await chrome.scripting.executeScript({target:{tabId,allFrames:true},func:nonce=>{
    if(document.documentElement?.getAttribute('data-captcha-frame-probe')!==nonce)return false;
    document.documentElement.removeAttribute('data-captcha-frame-probe');return true;
  },args:[nonce]});
  const found=frames.filter(r=>r.result);
  if(found.length!==1)throw Error('Нужный фрейм не доступен для запуска с текущими разрешениями.');
  return {frameIds:[found[0].frameId]};
}
chrome.action.onClicked.addListener(async tab=>{
  if(!tab.id || launches.has(tab.id))return;
  launches.add(tab.id);
  try{
    if(!/^https?:\/\//.test(tab.url||''))throw Error('На этой служебной странице Chrome расширение не запускается. Откройте обычную HTTP(S)-страницу.');
    const origin=new URL(tab.url).origin,key='profile:'+origin;
    const saved=(await chrome.storage.local.get(key))[key];
    const profile={...DEFAULT_PROFILE,...saved,crop:{...DEFAULT_PROFILE.crop,...saved?.crop}};
    const target={tabId:tab.id,...await targetFor(tab.id,profile)};
    const injected=await chrome.scripting.executeScript({target,files:['content.js']});
    const route=injected[0];
    if(!route)throw Error('Скрипт не запустился на вкладке.');
    await chrome.storage.session.set({['route:'+tab.id]:{frameId:route.frameId,documentId:route.documentId}});
    await chrome.tabs.sendMessage(tab.id,{kind:'START_ONE_CLICK',profile},{documentId:route.documentId});
  }catch(error){await status(tab.id,'error','Нельзя запустить: '+error.message);}
  finally{launches.delete(tab.id);}
});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(sender.id!==chrome.runtime.id || m.target!=='background' || !sender.tab?.id)return;
  const tabId=sender.tab.id;
  (async()=>{
    const route=(await chrome.storage.session.get('route:'+tabId))['route:'+tabId];
    if(route?.documentId!==sender.documentId)throw Error('Сообщение от предыдущей страницы отброшено.');
    if(m.kind==='PAGE_STATUS'){await status(tabId,m.state,m.reason);return {ok:true};}
    if(m.kind==='OPEN_OPTIONS'){
      await chrome.tabs.create({url:chrome.runtime.getURL('options.html?origin='+encodeURIComponent(new URL(sender.tab.url).origin))});return {ok:true};
    }
    if(m.kind==='CANCEL_OCR'){
      await chrome.runtime.sendMessage({target:'offscreen',kind:'CANCEL_OCR',id:m.id}).catch(()=>{});return {ok:true};
    }
    if(m.kind==='CAPTURE_PAGE' || m.kind==='VERIFY_PAGE'){
      if(sender.frameId!==0)throw Error('Захват CORS-изображения во фрейме не поддержан; нужен читаемый img/canvas или отдельная вкладка фрейма.');
      if(m.kind==='CAPTURE_PAGE')return {ok:true,image:await captureSerial(()=>capturePage(tabId,m),m.deadline)};
      const ok=await captureSerial(()=>verifyVisibleImage(tabId,m),m.deadline);
      return ok ? {ok:true} : {ok:false,error:'Изображение изменилось во время OCR.'};
    }
    if(m.kind==='RUN_OCR'){
      if(jobs.has(tabId))throw Error('Для этой вкладки OCR уже запущен.');
      if(Date.now()>=m.deadline)throw Error('Бюджет OCR истёк до запуска.');
      jobs.set(tabId,m.id);
      try{
        await ensureOffscreen();
        return await chrome.runtime.sendMessage({...m,target:'offscreen',origin:new URL(sender.tab.url).origin});
      }finally{if(jobs.get(tabId)===m.id)jobs.delete(tabId);}
    }
    throw Error('Неизвестная команда.');
  })().then(reply,error=>reply({ok:false,error:error.message}));return true;
});
chrome.tabs.onRemoved.addListener(tabId=>{
  const id=jobs.get(tabId);if(id)chrome.runtime.sendMessage({target:'offscreen',kind:'CANCEL_OCR',id}).catch(()=>{});
  chrome.storage.session.remove(['route:'+tabId,'status:'+tabId]);
});
