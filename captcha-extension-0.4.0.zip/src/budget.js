export const OCR_BUDGET_MS = 28_000;
export const ACTION_DEADLINE_MS = 30_000;
export class BudgetExpired extends Error {
  constructor() {
    super("Истёк бюджет OCR (28 секунд).");
    this.name = "BudgetExpired";
  }
}
export function untilDeadline(promise, deadline, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => finish(reject, new BudgetExpired()),
      Math.max(0, deadline - Date.now()),
    );
    const abort = () =>
      finish(
        reject,
        signal.reason || new DOMException("Остановлено", "AbortError"),
      );
    let settled = false;
    function finish(fn, value) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
      fn(value);
    }
    if (signal?.aborted) return abort();
    signal?.addEventListener("abort", abort, { once: true });
    Promise.resolve(promise).then(
      (v) => finish(resolve, v),
      (e) => finish(reject, e),
    );
  });
}
