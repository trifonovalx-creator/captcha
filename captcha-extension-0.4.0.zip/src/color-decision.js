// Calibrated on tune4 only. CTC scores are engine scores, not probabilities.
export const COLOR_THRESHOLD = 94;
export function decideColor(task, candidates, threshold = COLOR_THRESHOLD) {
  const valid = (text) => text.length >= task.min && text.length <= task.max &&
    [...text].every((c) => task.alphabet.includes(c));
  const groups = new Map();
  for (const c of candidates) {
    if (!groups.has(c.text)) groups.set(c.text, []);
    groups.get(c.text).push(c);
  }
  const ranked = [...groups].map(([text, entries]) => {
    // Different views of one engine count once each, never as independent models.
    const views = new Map();
    for (const c of entries.filter((c) => /^helper-(original|contrast|gray)$/.test(c.variant)))
      views.set(c.variant, c);
    const helper = [...views.values()].sort((a, b) => b.confidence - a.confidence);
    const viewScore = helper.length >= 2 ? helper[1].confidence : 0;
    const original = views.get('helper-original');
    const easy = entries.find((c) => c.variant === 'easyocr-fallback');
    // A high contrast score alone cannot replace the untouched original when
    // using cross-engine agreement (tune4 l/1 is a confident counterexample).
    const crossScore = original && easy?.confidence >= 98 ? original.confidence : 0;
    const confidence = Math.max(viewScore, crossScore);
    return {text, confidence, votes: entries.length, viewScore, crossScore,
      evidence: crossScore > viewScore ? 'original+EasyOCR' : 'two-Helper-views'};
  }).sort((a, b) => Number(valid(b.text)) - Number(valid(a.text)) ||
    b.confidence - a.confidence || b.votes - a.votes);
  const best = ranked[0] || {text:'',confidence:0,votes:0};
  const competitor = candidates.find((c) => c.text !== best.text && valid(c.text) && c.confidence >= 95);
  const accepted = valid(best.text) && best.confidence >= threshold && !competitor;
  const reason = !valid(best.text) ? 'Цветная: нет кандидата допустимой длины и алфавита.'
    : competitor ? `Цветная: сильный конкурент ${competitor.text} (${competitor.confidence.toFixed(2)}); требуется ручная проверка.`
    : best.confidence < threshold ? `Цветная: согласованная оценка ${best.confidence.toFixed(2)} ниже ${threshold}; требуется ручная проверка.`
    : `Цветная: ${best.evidence}, оценка ${best.confidence.toFixed(2)} ≥ ${threshold}, сильных конкурентов нет.`;
  return {candidate:best.text,confidence:best.confidence,accepted,reason,ranked,
    colorPolicy:{threshold,competitor:competitor?.text||null,evidence:best.evidence}};
}
