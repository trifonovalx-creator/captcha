import {locate,pixels,MissingElement,chooseButton} from './page-dom.js';
import {inferType,inferAlphabet} from './profile.js';
import {OCR_BUDGET_MS,ACTION_DEADLINE_MS} from './budget.js';
(() => {
  if(globalThis.__captchaOneClick)return;
  let current=null,panel=null;
  const seen=new Set(),timings=[],clocks=new Map();
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  function fingerprint(text){let a=2166136261,b=5381;for(let i=0;i<text.length;i++){a=Math.imul(a^text.charCodeAt(i),16777619);b=Math.imul(b,33)^text.charCodeAt(i);}return `${text.length}:${a>>>0}:${b>>>0}`;}
  async function send(kind,data={}) {
    const response=await chrome.runtime.sendMessage({target:'background',kind,...data});
    if(!response || response.ok===false)throw Error(response?.error || 'Нет связи с расширением.');
    return response;
  }
  function show(state,reason) {
    if(!panel || !panel.isConnected){
      panel=document.createElement('div');panel.id='captcha-lab-status';
      const shadow=panel.attachShadow({mode:'open'});
      shadow.innerHTML='<style>:host{all:initial;position:fixed;right:16px;bottom:16px;z-index:2147483647;width:min(360px,90vw);font:14px/1.5 system-ui;color:#202737}section{padding:16px;background:#fff;border:1px solid #aab0c4;box-shadow:0 4px 24px #0002;border-radius:10px}p{margin:8px 0}button{font:inherit;cursor:pointer;margin-right:8px;padding:4px 8px}small{color:#627087}</style><section role="status" aria-live="polite"><b>Captcha Lab</b><p></p><small>Статус также доступен на иконке расширения.</small><p><button id="stop">Остановить</button><button id="settings">Настройки</button><button id="close" aria-label="Закрыть статус">×</button></p></section>';
      shadow.querySelector('#stop').onclick=()=>{if(current)finish(current,'stopped','Остановлено пользователем.');};
      shadow.querySelector('#settings').onclick=()=>send('OPEN_OPTIONS').catch(()=>{});
      shadow.querySelector('#close').onclick=()=>panel.remove();
      document.documentElement.append(panel);
    }
    panel.shadowRoot.querySelector('section').dataset.state=state;
    panel.shadowRoot.querySelector('section > p').textContent=reason;
    send('PAGE_STATUS',{state,reason}).catch(()=>{});
  }
  function finish(job,state,reason) {
    if(current!==job || job.done)return;
    job.done=true;clearTimeout(job.timer);clearInterval(job.poll);job.observer?.disconnect();
    for(const name of ['input','beforeinput','change','paste','compositionstart','keydown'])document.removeEventListener(name,job.manual,true);
    for(const name of ['click','submit'])document.removeEventListener(name,job.pageAction,true);
    send('CANCEL_OCR',{id:job.id}).catch(()=>{});
    job.state=state;job.reason=reason;show(state,reason);
  }
  function rectOf(image){const r=image.getBoundingClientRect();return {rect:{x:r.x,y:r.y,width:r.width,height:r.height},viewport:{width:innerWidth,height:innerHeight}};}
  function markDetected(job){
    if(job.startedAt)return;
    armClock(job,Date.now());
  }
  function armClock(job,startedAt){
    clearTimeout(job.timer);job.startedAt=startedAt;job.deadline=startedAt+ACTION_DEADLINE_MS;
    job.timer=setTimeout(()=>finish(job,'timeout','Бюджет OCR 28 секунд истёк. Ответ и кнопка не изменены.'),Math.max(0,startedAt+OCR_BUDGET_MS-Date.now()));
  }
  async function waitForPage(job,profile) {
    const until=Date.now()+Math.min(10000,Math.max(100,Number(profile.waitForMs)||5000));
    let last='Капча не найдена.';
    while(!job.done){
      try{
        // Start the budget as soon as the unique image exists, before image loading.
        const roots=profile.container?document.querySelectorAll(profile.container):[document];
        if(roots.length===1 && roots[0].querySelectorAll(profile.image).length===1)markDetected(job);
        const found=locate(profile);
        if(found.input.value)throw Error('В поле уже есть текст. Ручной ввод сохранён.');
        let image=null,fallback=false;
        try{image=pixels(found.image);}catch(error){if(error.name==='SecurityError')fallback=true;else throw error;}
        markDetected(job);return {...found,imageData:image,fallback,src:found.image.currentSrc||found.image.src||'',...rectOf(found.image)};
      }catch(error){
        if(!(error instanceof MissingElement))throw error;
        last=error.message;
        if(Date.now()>=until)throw Error(last+' Время ожидания истекло. Проверьте профиль страницы в настройках.');
        await sleep(60);
      }
    }return null;
  }
  function fresh(job,expectedValue='') {
    if(job.done || current!==job)throw Error('Задание остановлено; поздний результат отброшен.');
    if(Date.now()>=job.deadline)throw Error('Дедлайн 30 секунд истёк. Позднее действие запрещено.');
    const f=locate(job.profile),s=job.snapshot;
    if(f.root!==s.root||f.image!==s.image||f.input!==s.input||f.form!==s.form||f.instruction!==s.instruction||f.min!==s.min||f.max!==s.max||
      (f.image.currentSrc||f.image.src||'')!==s.src)throw Error('Капча, форма или поле изменились. Обработка остановлена.');
    if(f.input.value!==expectedValue)throw Error('Поле изменилось или пользователь начал вводить ответ. Текст сохранён.');
    if(!s.fallback && pixels(f.image)!==s.imageData)throw Error('Изображение сменилось во время распознавания. Ответ не отправлен.');
    return f;
  }
  function monitor(job) {
    job.pageAction=event=>{
      const s=job.snapshot;
      const button=event.composedPath().find(el=>el instanceof HTMLElement && el.matches('button,input[type="submit"],input[type="button"],input[type="image"],[role="button"]'));
      if((event.type==='submit' && event.target===s.form) ||
        (event.type==='click' && button && (s.form?button.form===s.form:s.root.contains(button))))
        finish(job,'manual','Страница уже получила нажатие или отправку. Повторное действие расширения отменено.');
    };
    for(const name of ['click','submit'])document.addEventListener(name,job.pageAction,true);
    job.manual=event=>{
      if(event.target===job.snapshot.input && !job.writing){job.manuallyEdited=true;finish(job,'manual','Пользователь начал ввод. Автоматические действия остановлены.');}
    };
    for(const name of ['input','beforeinput','change','paste','compositionstart','keydown'])document.addEventListener(name,job.manual,true);
    const check=()=>{if(!job.done && !job.writing)try{fresh(job,job.filled?job.value:'');}catch(error){finish(job,'changed',error.message);}};
    job.poll=setInterval(check,120);
    job.observer=new MutationObserver(records=>{
      if(job.done || job.writing)return;
      if(records.some(r=>r.target===job.snapshot.image && ['src','srcset','width','height'].includes(r.attributeName))){finish(job,'changed','Изображение изменилось во время OCR. Обработка остановлена.');return;}
      check();
    });
    job.observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,characterData:true});
  }
  async function verify(job) {
    const f=fresh(job,job.filled?job.value:'');
    if(job.snapshot.fallback){
      const pos=rectOf(f.image);
      if(JSON.stringify(pos)!==JSON.stringify({rect:job.snapshot.rect,viewport:job.snapshot.viewport}))throw Error('Область картинки изменилась.');
      await screenRequest(job,'VERIFY_PAGE',{image:job.snapshot.imageData,...pos});
      fresh(job,job.filled?job.value:'');
    }return f;
  }
  async function screenRequest(job,kind,data){
    const statusPanel=panel;
    statusPanel?.style.setProperty('visibility','hidden','important');
    try{await sleep(32);return await send(kind,{...data,deadline:job.deadline});}
    finally{statusPanel?.style.removeProperty('visibility');}
  }
  async function run(job) {
    try{
      show('waiting','Ищу капчу на странице…');
      const s=await waitForPage(job,job.profile);if(!s||job.done)return;
      job.snapshot=s;
      if(s.fallback){
        const style=getComputedStyle(s.image);
        if(style.transform!=='none'||['contain','cover'].includes(style.objectFit))throw Error('Для снимка object-fit/transform нужен отдельный профиль.');
        s.imageData=(await screenRequest(job,'CAPTURE_PAGE',{rect:s.rect,viewport:s.viewport})).image;
      }
      if(job.done)return;
      job.key=fingerprint(JSON.stringify([s.imageData,s.src,s.instruction,s.min,s.max]));
      if(job.done)return;
      if(clocks.has(job.key))armClock(job,clocks.get(job.key));else clocks.set(job.key,job.startedAt);
      if(seen.has(job.key)){finish(job,'already','Для этой капчи автоматическое действие уже выполнено. Повторная отправка запрещена.');return;}
      if(Date.now()>=job.startedAt+OCR_BUDGET_MS){finish(job,'timeout','Дедлайн этой капчи уже истёк. Повторный клик не обнуляет время; смените задание.');return;}
      const type=job.profile.type==='auto'?inferType(s.instruction):job.profile.type;
      if(!['shapes','color','lines'].includes(type))throw Error('Неподдерживаемый тип капчи. Проверьте настройки.');
      const task={image:s.imageData,type,alphabet:inferAlphabet(s.instruction,job.profile.alphabet),min:s.min,max:s.max,crop:job.profile.crop};
      monitor(job);show('ocr','Распознаю изображение локально…');
      const response=await send('RUN_OCR',{id:job.id,task,deadline:job.startedAt+OCR_BUDGET_MS,startedAt:job.startedAt,observe:job.profile.mode==='observe'});
      if(job.done || current!==job)return;
      job.result=response.result;
      if(Date.now()>=job.startedAt+OCR_BUDGET_MS){finish(job,'timeout','Поздний результат OCR отброшен: бюджет 28 секунд истёк.');return;}
      if(response.result.accepted && job.profile.mode!=='observe'){
        clearTimeout(job.timer);
        job.timer=setTimeout(()=>finish(job,'timeout',job.filled?'Ответ введён. Дедлайн подтверждения истёк; кнопка не нажата.':'Дедлайн действия истёк. Поле и кнопка не изменены.'),Math.max(0,job.deadline-Date.now()));
      }
      fresh(job);
      if(job.profile.mode==='observe'){finish(job,'observed',`Наблюдение: ${response.result.candidate||'нет кандидата'}. Поле и кнопка не изменены; запись сохранена в журнале.`);return;}
      if(!response.result.accepted){finish(job,'stopped','Надёжный ответ не найден. '+response.result.reason);return;}
      const value=response.result.candidate;
      if(value.length<s.min||value.length>s.max||([...value].some(c=>!task.alphabet.includes(c)) && type!=='shapes'))throw Error('Ответ не прошёл проверку длины или алфавита.');
      const f=await verify(job);
      seen.add(job.key);job.value=value;job.filled=true;job.writing=true;
      const proto=f.input instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto,'value').set.call(f.input,value);
      timings.push({kind:'fill',id:job.id,elapsedMs:Date.now()-job.startedAt});
      f.input.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:value}));
      if(!job.done)f.input.dispatchEvent(new Event('change',{bubbles:true,composed:true}));
      job.writing=false;
      if(job.done)return;
      await sleep(80);
      if(job.done)return;
      const after=fresh(job,job.value);
      let choice=chooseButton(after,job.profile);
      const waitUntil=Math.min(job.deadline-20,Date.now()+1500);
      while(!choice.ok && choice.waitable && Date.now()<waitUntil && !job.done){
        await sleep(60);const ready=fresh(job,job.value);choice=chooseButton(ready,job.profile);
      }
      if(job.done)return;
      if(!choice.ok){finish(job,'filled',choice.reason);return;}
      await verify(job);
      const last=chooseButton(locate(job.profile),job.profile);
      if(!last.ok || last.button!==choice.button || last.name!==choice.name || last.type!==choice.type){finish(job,'filled','Ответ введён. Кнопка изменилась; отправка отменена.');return;}
      if(Date.now()>=job.deadline)throw Error('Дедлайн 30 секунд истёк; отправка отменена.');
      job.clicked=true;timings.push({kind:'submit',id:job.id,elapsedMs:Date.now()-job.startedAt});
      finish(job,'submitted',`Ответ введён. «${choice.name}» нажата один раз.`);
      choice.button.click();
    }catch(error){if(!job.done)finish(job,error.name==='BudgetExpired'?'timeout':'error',`Обработка остановлена: ${error.message}`);}
  }
  chrome.runtime.onMessage.addListener((m,sender,reply)=>{
    if(sender.id!==chrome.runtime.id)return;
    if(m.kind==='START_ONE_CLICK'){
      if(current && !current.done){show('busy','Распознавание уже запущено. Повторный запуск не создаёт новую задачу.');reply({ok:true,busy:true});return;}
      const job={id:Date.now().toString(36)+'-'+Math.random().toString(36).slice(2),profile:m.profile,done:false,startedAt:null};current=job;
      run(job);reply({ok:true});return;
    }
    if(m.kind==='ONE_CLICK_STATE')reply({id:current?.id,state:current?.state||'running',reason:current?.reason,result:current?.result,startedAt:current?.startedAt,done:current?.done,clicked:!!current?.clicked,timings});
  });
  globalThis.__captchaOneClick={stop:()=>current && finish(current,'stopped','Остановлено пользователем.')};
})();
