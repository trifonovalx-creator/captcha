import { loadObservations, saveObservation } from "./observation-db.js";
import { DEFAULT_PROFILE, inferType, inferAlphabet } from "./profile.js";
import { recognize, terminateAll as terminateWorker } from "./pipeline.js";
import { untilDeadline, BudgetExpired } from "./budget.js";
import { observationRecord, parseCSV } from "./observations.js";
import { loadImage, crop } from "./image.js";
const $ = (id) => document.getElementById(id);
const tabId = Number(new URLSearchParams(location.search).get("tab")) || null;
let profile = structuredClone(DEFAULT_PROFILE),
  origin = "local",
  running = false,
  busy = false,
  dirty = false,
  generation = 0,
  seen = new Set();
let observationWrites = Promise.resolve();
function persistObservation(r) {
  observationWrites = observationWrites
    .then(() => saveObservation(r))
    .catch((e) => status("Не удалось сохранить наблюдение: " + e.message));
}
let lastResult = null;
let job = null;
const observations = [];
const processedActions = new Set();
const stats = {
  pageJobs: 0,
  fills: 0,
  skips: 0,
  skipClicks: 0,
  correct: 0,
  incorrect: 0,
};
const pendingFills = new Set();
function showCounters() {
  $("counters").textContent =
    `Заполнено: ${stats.fills} · Пропущено: ${stats.skips}` +
    (profile.feedbackSelector
      ? ` · Подтверждено сайтом: ${stats.correct} верно, ${stats.incorrect} неверно; без оценки: ${stats.fills - stats.correct - stats.incorrect}`
      : "");
}
function status(text) {
  $("status").textContent = text;
}
async function badge(text) {
  if (tabId) await chrome.action.setBadgeText({ tabId, text }).catch(() => {});
}
async function send(kind, payload = {}) {
  const response = await chrome.tabs.sendMessage(tabId, { kind, ...payload });
  if (!response)
    throw Error(
      "Нет связи со страницей. Нажмите иконку расширения на нужной вкладке.",
    );
  if (response.error) throw Error(response.error);
  return response.value;
}
const fields = {
  container: "Контейнер капчи (пусто = документ)",
  image: "Изображение <img> или <canvas>",
  instruction: "Инструкция",
  minSelector: "Ограничение min (пусто = minlength поля)",
  maxSelector: "Ограничение max (пусто = maxlength поля)",
  input: "Поле ответа",
  skipSelector: "Кнопка Пропустить (отдельный селектор)",
  feedbackSelector: "Обратная связь сайта (необязательно)",
  feedbackSuccess: "Точный текст успешной проверки",
  feedbackFailure: "Точный текст ошибки проверки",
};
for (const [key, title] of Object.entries(fields)) {
  const label = document.createElement("label");
  label.textContent = title;
  const input = document.createElement("input");
  input.id = `selector-${key}`;
  input.spellcheck = false;
  label.append(input);
  $("selectors").append(label);
}
for (const key of ["top", "bottom", "left", "right"]) {
  const label = document.createElement("label");
  label.textContent = {
    top: "Сверху",
    bottom: "Снизу",
    left: "Слева",
    right: "Справа",
  }[key];
  const input = document.createElement("input");
  input.id = `crop-${key}`;
  input.type = "number";
  input.min = 0;
  input.max = 0.9;
  input.step = 0.01;
  label.append(input);
  $("crop-fields").append(label);
}
function showProfile() {
  for (const key in fields) $(`selector-${key}`).value = profile[key];
  $("type").value = profile.type;
  $("alphabet").value = profile.alphabet;
  $("debug-mode").checked = profile.debug;
  $("skip-low").checked = true;
  $("mode").value = profile.mode;
  $("skip-limit").value = profile.maxConsecutiveSkips;
  showCounters();
  for (const key in profile.crop) $(`crop-${key}`).value = profile.crop[key];
}
function readProfile() {
  const p = { ...profile, crop: {} };
  for (const key in fields) p[key] = $(`selector-${key}`).value.trim();
  p.type = $("type").value;
  p.alphabet = $("alphabet").value.replace(/\s/g, "");
  p.debug = $("debug-mode").checked;
  p.skipLowConfidence = true;
  p.mode = $("mode").value;
  p.maxConsecutiveSkips = Number($("skip-limit").value);
  if (
    !Number.isInteger(p.maxConsecutiveSkips) ||
    p.maxConsecutiveSkips < 1 ||
    p.maxConsecutiveSkips > 100
  )
    throw Error("Лимит пропусков должен быть от 1 до 100.");
  if (
    p.feedbackSelector &&
    (!p.feedbackSuccess ||
      !p.feedbackFailure ||
      p.feedbackSuccess === p.feedbackFailure)
  )
    throw Error(
      "Для обратной связи задайте два разных непустых точных текста результата.",
    );
  if (p.skipLowConfidence && !p.skipSelector)
    throw Error("Задайте селектор кнопки Пропустить.");
  for (const key of ["top", "bottom", "left", "right"]) {
    p.crop[key] = Number($(`crop-${key}`).value);
    if (!Number.isFinite(p.crop[key]) || p.crop[key] < 0 || p.crop[key] >= 1)
      throw Error("Некорректная обрезка.");
  }
  if (p.crop.top + p.crop.bottom >= 1 || p.crop.left + p.crop.right >= 1)
    throw Error("Обрезка удаляет всё изображение.");
  return p;
}
function render(result) {
  lastResult = result;
  $("candidate").textContent = result.candidate || "—";
  $("debug").hidden = !profile.debug;
  $("variants").replaceChildren();
  if (profile.debug)
    for (const item of result.debug || [])
      if (item.image) {
        const figure = document.createElement("figure"),
          caption = document.createElement("figcaption"),
          image = document.createElement("img");
        caption.textContent = item.name;
        image.src = item.image;
        image.alt = item.name;
        figure.append(caption, image);
        $("variants").append(figure);
      }
  $("evidence").textContent = JSON.stringify(
    {
      candidate: result.candidate,
      confidence: result.confidence,
      accepted: result.accepted,
      reason: result.reason,
      candidates: result.candidates,
      shapes: result.shapes?.map(({ triangle, center, contour }) => ({
        triangle,
        center,
        vertices: contour.length,
      })),
    },
    null,
    2,
  );
}
async function capture(snapshot) {
  const r = snapshot.rect,
    v = snapshot.viewport;
  if (
    r.width <= 0 ||
    r.height <= 0 ||
    r.x < 0 ||
    r.y < 0 ||
    r.x + r.width > v.width ||
    r.y + r.height > v.height
  )
    throw Error(
      "Изображение вне видимой области. Прокрутите страницу к капче.",
    );
  const tab = await chrome.tabs.get(tabId);
  if (!tab.active)
    throw Error("Для захвата сделайте исходную вкладку активной в её окне.");
  const url = await chrome.tabs.captureVisibleTab(tab.windowId, {
    format: "png",
  });
  const latest = await chrome.tabs.get(tabId);
  if (!latest.active || !(await send("VALIDATE", { token: snapshot.token })))
    throw Error("Страница изменилась во время захвата. Повторите обработку.");
  const shot = await loadImage(url),
    sx = shot.width / v.width,
    sy = shot.height / v.height;
  return crop(shot, {
    x: r.x * sx,
    y: r.y * sy,
    width: r.width * sx,
    height: r.height * sy,
  }).toDataURL();
}
function taskFrom(snapshot, image) {
  if (!inferAlphabet(snapshot.instruction, profile.alphabet))
    throw Error(
      "Не задан допустимый алфавит. Настройте профиль; пропуск отменён.",
    );
  const type =
    profile.type === "auto" ? inferType(snapshot.instruction) : profile.type;
  return {
    type,
    image,
    min: snapshot.min,
    max: snapshot.max,
    alphabet: inferAlphabet(snapshot.instruction, profile.alphabet),
    crop: profile.crop,
  };
}
function logObservation(snapshot, task, result) {
  const record = observationRecord({
    taskId: snapshot.taskId,
    type: task.type,
    image: task.image,
    result,
    startedAt: snapshot.startedAt,
    task,
    instruction: snapshot.instruction,
    origin,
  });
  observations.push(record);
  showObservations();
  persistObservation(record);
}
function showObservations() {
  $("observations").replaceChildren();
  for (const r of observations.slice(-30).toReversed()) {
    const block = document.createElement("div"),
      text = document.createElement("p"),
      input = document.createElement("input");
    text.textContent = `${r.type}: ${r.candidate || "∅"} · ${r.confidence} · авторежим: ${r.wouldFill ? "заполнить" : "отказ"} · ${r.reason}`;
    input.placeholder = "Подтверждённый правильный ответ";
    input.value = r.answer ?? "";
    input.addEventListener("change", () => {
      r.answer = input.value;
      r.labelVerified = !!input.value;
      persistObservation(r);
    });
    block.append(text, input);
    $("observations").append(block);
  }
}
async function finishSkip(snapshot, response, run) {
  if (!response.clicked) throw Error(response.reason || "Пропуск отменён.");
  if (!processedActions.has(snapshot.taskId)) {
    processedActions.add(snapshot.taskId);
    stats.skipClicks++;
  }
  status("Пропустить нажато. Ожидание смены капчи…");
  const end = Date.now() + 4000;
  let changed = false;
  while (Date.now() < end && run === generation && running) {
    await new Promise((r) => setTimeout(r, 100));
    const next = await send("SNAPSHOT", { profile });
    if (next.manual) throw Error("После пропуска начат ручной ввод.");
    if (
      next.taskId !== snapshot.taskId ||
      next.challenge !== snapshot.challenge
    ) {
      changed = true;
      break;
    }
  }
  if (run !== generation || !running) return;
  if (!changed)
    throw Error(
      "После нажатия Пропустить капча не сменилась. Повторного нажатия не будет.",
    );
  stats.skips++;
  showCounters();
  if (response.skipsInARow >= profile.maxConsecutiveSkips) {
    await send("PAUSE", { reason: "Достигнут лимит пропусков подряд." });
    running = false;
    status("Пауза: достигнут лимит пропусков подряд.");
    return;
  }
  status("Смена капчи подтверждена.");
  if ($("auto").checked) dirty = true;
  else {
    running = false;
    await send("STOP");
  }
}
async function processLatest() {
  if (!running) return;
  if (busy) {
    dirty = true;
    return;
  }
  busy = true;
  dirty = false;
  const run = generation,
    abort = new AbortController();
  job = { abort };
  let snapshot,
    task,
    phase = "страницы / захвата";
  try {
    snapshot = await send("SNAPSHOT", { profile });
    job.taskId = snapshot.taskId;
    job.snapshot = snapshot;
    if (run !== generation || !running) return;
    if (seen.has(snapshot.taskId)) return;
    if (snapshot.manual) {
      status("В поле есть ручной текст. Он сохранён.");
      await send("PAUSE", { reason: "Ручной ввод" });
      running = false;
      return;
    }
    if (snapshot.action) {
      status("Пауза: задание уже завершено или истёк его дедлайн.");
      running = false;
      return;
    }
    seen.add(snapshot.taskId);
    stats.pageJobs++;
    const work = (async () => {
      while (snapshot.loading) {
        await new Promise((r) => setTimeout(r, 75));
        abort.signal.throwIfAborted();
        snapshot = await send("SNAPSHOT", { profile });
      }
      const image = snapshot.image || (await capture(snapshot));
      if (snapshot.fallback)
        await send("CAPTURE_BASELINE", { token: snapshot.token, image });
      task = taskFrom(snapshot, image);
      phase = "OCR";
      return recognize(task, {
        signal: abort.signal,
        deadline: snapshot.ocrDeadline,
        progress: (m) => {
          if (!abort.signal.aborted && run === generation)
            status(`OCR: ${m.status}`);
        },
      });
    })();
    const result = await untilDeadline(
      work,
      snapshot.ocrDeadline,
      abort.signal,
    );
    if (run !== generation || !running || abort.signal.aborted) return;
    if (!(await send("VALIDATE", { token: snapshot.token }))) {
      status("Капча изменилась или начат ручной ввод. Поздний ответ отброшен.");
      return;
    }
    if (snapshot.fallback) {
      const fresh = await capture(snapshot);
      if (fresh !== task.image)
        throw Error("Изображение изменилось во время OCR.");
      await send("CAPTURE_BASELINE", {
        token: snapshot.token,
        image: fresh,
        verified: true,
      });
    }
    render(result);
    if (!snapshot.auto) {
      logObservation(snapshot, task, result);
      status(`Наблюдение: ${result.reason} Поле и Пропустить не изменялись.`);
    } else if (result.accepted) {
      const filled = await send("FILL", {
        token: snapshot.token,
        taskId: snapshot.taskId,
        value: result.candidate,
      });
      if (!filled.ok) throw Error(filled.reason);
      stats.fills++;
      processedActions.add(snapshot.taskId);
      pendingFills.add(snapshot.token);
      showCounters();
      status("Ответ внесён. Отправьте форму самостоятельно.");
      await badge("OK");
    } else {
      phase = "пропуска";
      await finishSkip(
        snapshot,
        await send("SKIP", { token: snapshot.token, taskId: snapshot.taskId }),
        run,
      );
    }
    if (!$("auto").checked) {
      running = false;
      await send("STOP");
    }
  } catch (error) {
    if (error instanceof BudgetExpired) {
      abort.abort(error);
      terminateWorker();
      if (snapshot?.auto && running && run === generation) {
        try {
          const next = await send("SNAPSHOT", { profile });
          if (next.taskId !== snapshot.taskId) {
            dirty = true;
            return;
          }
          if (!next.action && !next.fallback)
            await finishSkip(
              next,
              await send("SKIP", { token: next.token, taskId: next.taskId }),
              run,
            );
          // The independent content watchdog may already have performed the single action.
        } catch (e) {
          running = false;
          status("Пауза по дедлайну: " + e.message);
          await send("PAUSE", { reason: e.message });
        }
      } else
        status(
          "Наблюдение: OCR остановлен через 28 секунд, автоматических действий нет.",
        );
    } else if (error?.name === "AbortError") {
    } else if (run === generation) {
      running = false;
      status(
        `${phase === "пропуска" ? "Пропуск остановлен" : "Техническая ошибка " + phase}: ${error.message}`,
      );
      await send("PAUSE", { reason: error.message }).catch(() => {});
    }
  } finally {
    busy = false;
    if (job?.abort === abort) job = null;
    if (dirty && running) setTimeout(processLatest, 0);
  }
}
async function start() {
  if (!tabId) {
    status(
      "Откройте это окно иконкой расширения на вкладке с капчей. Или загрузите отдельный файл ниже.",
    );
    return;
  }
  status("Проверка страницы…");
  $("candidate").textContent = "";
  try {
    job?.abort.abort(new DOMException("Перезапуск", "AbortError"));
    terminateWorker();
    generation++;
    running = false;
    await send("STOP");
    profile = readProfile();
    seen = new Set();
    await send("START", { profile, resetSeries: true });
    running = true;
    await processLatest();
  } catch (error) {
    status(error.message);
  }
}
async function stop() {
  job?.abort.abort(new DOMException("Остановлено", "AbortError"));
  terminateWorker();
  generation++;
  running = false;
  dirty = false;
  if (tabId) await send("STOP").catch(() => {});
  status("Остановлено. Новые ответы не будут внесены.");
  await badge("");
}
$("start").addEventListener("click", start);
$("stop").addEventListener("click", stop);
$("auto").addEventListener("change", () => {
  if (!$("auto").checked) stop();
});
$("settings").addEventListener("input", () => {
  if (running) stop();
});
$("save").addEventListener("click", async () => {
  try {
    profile = readProfile();
    await chrome.storage.local.set({ ["profile:" + origin]: profile });
    $("saved").textContent = "Профиль сохранён локально для " + origin;
  } catch (error) {
    $("saved").textContent = error.message;
  }
});
chrome.runtime.onMessage.addListener((message, sender) => {
  if (sender.tab?.id === tabId && message.kind === "TASK_PAUSED") {
    job?.abort.abort(new DOMException("Пауза", "AbortError"));
    terminateWorker();
    running = false;
    status("Пауза: " + message.reason);
    return;
  }
  if (sender.tab?.id === tabId && message.kind === "TASK_ACTION") {
    const snapshot = job?.snapshot;
    job?.abort.abort(new DOMException("Дедлайн", "AbortError"));
    terminateWorker();
    if (message.clicked && !processedActions.has(message.taskId)) {
      const run = generation;
      const old = { taskId: message.taskId, challenge: message.challenge };
      finishSkip(old, message, run)
        .then(() => {
          if (dirty && running) processLatest();
        })
        .catch((e) => {
          running = false;
          status("Пауза: " + e.message);
          send("PAUSE", { reason: e.message });
        });
    } else if (!message.clicked) {
      running = false;
      status("Пауза: " + message.reason);
    }
    return;
  }

  if (
    sender.tab?.id === tabId &&
    message.kind === "CAPTCHA_FEEDBACK" &&
    pendingFills.has(message.token)
  ) {
    pendingFills.delete(message.token);
    if (message.outcome === "correct") stats.correct++;
    else if (message.outcome === "incorrect") stats.incorrect++;
    showCounters();
    return;
  }
  if (
    sender.id === chrome.runtime.id &&
    message.kind === "ACTIVATE_CONTROLLER" &&
    message.tabId === tabId
  ) {
    stop().then(init);
    return;
  }
  if (
    sender.tab?.id === tabId &&
    message.kind === "CAPTCHA_CHANGED" &&
    running &&
    $("auto").checked
  ) {
    if (job && message.taskId && message.taskId !== job.taskId) {
      job.abort.abort(new DOMException("Новое задание", "AbortError"));
      terminateWorker();
    }
    processLatest();
  }
});
chrome.tabs.onRemoved.addListener((id) => {
  if (id === tabId) stop();
});
$("recognize-file").addEventListener("click", async () => {
  if (busy) {
    status("Дождитесь завершения текущего OCR.");
    return;
  }
  await stop();
  try {
    profile = readProfile();
    const file = $("upload").files[0];
    if (!file) throw Error("Выберите файл изображения.");
    if (profile.type === "auto") throw Error("Для файла выберите тип вручную.");
    const min = Number($("local-min").value),
      max = Number($("local-max").value);
    if (min < 1 || max < min || max > 64) throw Error("Проверьте min/max.");
    const run = generation;
    busy = true;
    const image = await new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = reject;
      r.readAsDataURL(file);
    });
    status("Распознавание отдельного файла…");
    const result = await recognize({
      image,
      type: profile.type,
      alphabet: profile.alphabet,
      crop: profile.crop,
      min,
      max,
    });
    if (run !== generation) return;
    render(result);
    status(`Файл: ${result.reason} Поле страницы не изменялось.`);
  } catch (error) {
    status(error.message);
  } finally {
    busy = false;
  }
});
// Public, image-only API for reproducible browser tests; same engine as page workflow.
globalThis.CaptchaLab = {
  recognize,
  stats,
  observations,
  flushObservations: () => observationWrites,
  get lastResult() {
    return lastResult;
  },
};
async function init() {
  try {
    if (tabId) {
      const tab = await chrome.tabs.get(tabId);
      origin = new URL(tab.url).origin;
    }
    const saved = await chrome.storage.local.get("profile:" + origin);
    for (const r of await loadObservations())
      if (!observations.some((x) => x.id === r.id)) observations.push(r);
    showObservations();
    profile = {
      ...DEFAULT_PROFILE,
      ...saved["profile:" + origin],
      crop: { ...DEFAULT_PROFILE.crop, ...saved["profile:" + origin]?.crop },
    };
    showProfile();
    if (tabId) await start();
    else
      status(
        "OCR-стенд: загрузите изображение или откройте иконку на странице.",
      );
  } catch (error) {
    showProfile();
    status(error.message);
  }
}
$("export-observations").addEventListener("click", () => {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(observations, null, 2)], {
      type: "application/json",
    }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = "captcha-observations.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
$("run-folder").addEventListener("click", async () => {
  await stop();
  try {
    profile = readProfile();
    const files = [...$("folder").files],
      csv = files.find((f) => /\.csv$/i.test(f.name));
    if (!csv)
      throw Error("В папке нужен CSV с колонками file,type,answer,source.");
    const rows = parseCSV(await csv.text());
    for (const row of rows) {
      const file = files.find(
        (f) =>
          f.name === row.file || f.webkitRelativePath.endsWith("/" + row.file),
      );
      if (!file) throw Error("Нет файла " + row.file);
      const image = await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result);
        r.onerror = reject;
        r.readAsDataURL(file);
      });
      const task = {
        image,
        type: row.type,
        alphabet: row.alphabet || profile.alphabet,
        min: Number(row.min || 3),
        max: Number(row.max || 6),
        crop: {
          top: Number(row.crop_top || 0),
          bottom: Number(row.crop_bottom || 0),
          left: 0,
          right: 0,
        },
      };
      const startedAt = Date.now(),
        result = await untilDeadline(recognize(task), startedAt + 28000);
      const rec = observationRecord({
        taskId: row.file,
        type: row.type,
        image,
        result,
        startedAt,
        source: row.source || "unverified",
        task,
      });
      if (row.answer) {
        rec.answer = row.answer;
        rec.labelVerified = true;
      }
      observations.push(rec);
      persistObservation(rec);
      render(result);
      showObservations();
    }
    status("Папка обработана в наблюдении; автоматических действий нет.");
  } catch (e) {
    terminateWorker();
    status("Наблюдение папки: " + e.message);
  }
});
init();
