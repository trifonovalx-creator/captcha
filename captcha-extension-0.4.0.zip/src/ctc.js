// CTC collapse and BGR normalization adapted from Captcha Helper (MIT); see third_party.
export function decodeCTC(
  values,
  dims,
  charset,
  allowed,
  { logits = false } = {},
) {
  if (dims.length !== 3 || dims[0] !== 1 || dims[2] !== charset.length)
    throw Error("Несовместимая форма CTC.");
  const n = charset.length,
    indices = [
      0,
      ...charset
        .map((c, i) => (allowed.includes(c) ? i : -1))
        .filter((i) => i > 0),
    ];
  let previous = 0,
    text = "",
    scores = [],symbols = [];
  for (let t = 0; t < dims[1]; t++) {
    const row = values.subarray(t * n, (t + 1) * n);
    let best = 0,
      max = -Infinity;
    for (const i of indices)
      if (row[i] > max) {
        best = i;
        max = row[i];
      }
    let p = max;
    if (logits) {
      let denom = 0;
      for (const i of indices) denom += Math.exp(row[i] - max);
      p = 1 / denom;
    }
    if (!best) previous = 0;
    else if (best !== previous) {
      text += charset[best];
      scores.push(p);
      symbols.push({char:charset[best],confidence:100*p,startStep:t,endStep:t,peakStep:t});
      previous = best;
    } else {
      const symbol=symbols.at(-1);symbol.endStep=t;
      if(p>scores.at(-1)){scores[scores.length-1]=p;symbol.confidence=100*p;symbol.peakStep=t;}
    }
  }
  return {
    text,symbols,
    confidence: scores.length ? 100 * Math.min(...scores, 1) : 0,
    meanConfidence: scores.length
      ? (100 * scores.reduce((a, b) => a + b, 0)) / scores.length
      : 0,
  };
}
export function helperTensor(rgba, width, height, targetWidth) {
  const plane = height * targetWidth,
    out = new Float32Array(3 * plane);
  for (let y = 0; y < height; y++)
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4,
        j = y * targetWidth + x,
        a = rgba[i + 3] / 255;
      out[j] = (rgba[i + 2] * a + 255 * (1 - a)) / 127.5 - 1;
      out[plane + j] = (rgba[i + 1] * a + 255 * (1 - a)) / 127.5 - 1;
      out[2 * plane + j] = (rgba[i] * a + 255 * (1 - a)) / 127.5 - 1;
    }
  return out;
}
