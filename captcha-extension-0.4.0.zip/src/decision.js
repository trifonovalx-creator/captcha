export const CYRILLIC = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
export const LATIN =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
import { THRESHOLDS } from "./thresholds.js";
export { THRESHOLDS } from "./thresholds.js";
export function decide(
  candidates,
  {
    type,
    alphabet,
    min,
    max,
    shapeConfidence = 100,
    threshold = THRESHOLDS[type],
  },
) {
  const valid = candidates.filter(
    (c) => c.text && Number.isFinite(c.confidence),
  );
  const groups = new Map();
  for (const c of valid) {
    const group = groups.get(c.text) || [];
    group.push(c);
    groups.set(c.text, group);
  }
  const admissible = (text) =>
    !!alphabet &&
    [...text].every((c) => alphabet.includes(c)) &&
    text.length >= min &&
    text.length <= max;
  const family = (c) =>
    c.family ||
    {
      original: "source",
      gray: "source",
      binary: "binary",
      "thin-lines": "binary",
      "tight-line": "tight",
      "tight-raw": "tight",
      "dark-line": "dark",
      "dark-raw": "dark",
      "large-components": "components",
      "large-components-color": "components",
      "symbols-tight": "tight",
      "symbols-tight-binary": "tight",
    }[c.variant] ||
    c.variant;
  const ranked = [...groups]
    .map(([text, list]) => {
      const byFamily = new Map();
      for (const c of list) {
        const f = family(c);
        byFamily.set(f, Math.max(byFamily.get(f) ?? 0, c.confidence));
      }
      const scores = [...byFamily.values()].sort((a, b) => b - a);
      return {
        text,
        confidence:
          scores.slice(0, 2).reduce((a, b) => a + b, 0) /
          Math.min(2, scores.length),
        votes: byFamily.size,
        maxConfidence: scores[0],
        admissible: admissible(text),
      };
    })
    .sort(
      (a, b) =>
        Number(b.admissible) - Number(a.admissible) ||
        b.votes - a.votes ||
        b.confidence - a.confidence,
    );
  const best = ranked[0] || { text: "", confidence: 0, votes: 0 };
  let reason = "";
  if (!alphabet) reason = "Укажите допустимый алфавит в профиле.";
  else if (!best.text) reason = "OCR не нашёл символы.";
  else if (threshold > 100)
    reason =
      "Автозаполнение этого типа отключено: проверка выявила недостаточную надёжность. Кандидат — для ручной проверки.";
  else if ([...best.text].some((c) => !alphabet.includes(c)))
    reason = "Есть символы вне допустимого алфавита.";
  else if (best.text.length < min || best.text.length > max)
    reason = `Длина ${best.text.length} вне диапазона ${min}–${max}.`;
  else if (best.votes < 2)
    reason = "Варианты обработки не согласны между собой.";
  else if (ranked[1]?.admissible && ranked[1]?.votes >= best.votes)
    reason = "Есть конкурирующие ответы с равным числом голосов.";
  else if (
    ranked
      .slice(1)
      .some(
        (r) =>
          r.admissible &&
          r.maxConfidence >= 85 &&
          r.maxConfidence >= best.confidence - 10,
      )
  )
    reason = "Есть сильный конкурирующий кандидат; уверенность неоднозначна.";
  else if (best.confidence < threshold)
    reason = "Недостаточная уверенность OCR.";
  else if (shapeConfidence < 85)
    reason = "Неуверенное сопоставление букв и фигур.";
  return {
    candidate: best.text,
    confidence: Math.round(best.confidence),
    accepted: !reason,
    reason:
      reason || "Варианты согласны; алфавит, длина и уверенность проверены.",
    ranked,
  };
}
// Never trim, substitute lookalikes, truncate or pad an OCR answer to meet a length.
export function cleanOCR(text) {
  return String(text || "").replace(/\s/g, "");
}
