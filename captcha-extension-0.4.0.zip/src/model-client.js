let worker,
  seq = 0;
const requests = new Map();
function get() {
  if (!worker) {
    worker = new Worker(chrome.runtime.getURL("models-worker.js"), {
      type: "module",
    });
    worker.onmessage = ({ data }) => {
      const r = requests.get(data.id);
      if (!r) return;
      requests.delete(data.id);
      data.error ? r.reject(Error(data.error)) : r.resolve(data.result);
    };
    worker.onerror = (e) => {
      for (const r of requests.values()) r.reject(Error(e.message));
      requests.clear();
    };
  }
  return worker;
}
export function modelRecognize(name, image, alphabet, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(signal.reason);
    const id = ++seq;
    requests.set(id, { resolve, reject });
    signal?.addEventListener(
      "abort",
      () => {
        requests.delete(id);
        reject(signal.reason);
      },
      { once: true },
    );
    get().postMessage({ id, name, image, alphabet });
  });
}
export function terminateModels() {
  worker?.terminate();
  worker = null;
  for (const r of requests.values())
    r.reject(new DOMException("Остановлено", "AbortError"));
  requests.clear();
}
