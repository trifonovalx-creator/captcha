import * as ort from "onnxruntime-web/wasm";
import { decodeCTC, helperTensor } from "./ctc.js";
ort.env.wasm.wasmPaths = new URL("vendor/ort/", self.location.href).href;
ort.env.wasm.numThreads = 1;
ort.env.wasm.proxy = false;
const models = new Map();
async function getModel(name) {
  if (!models.has(name))
    models.set(
      name,
      (async () => {
        const config = await (
          await fetch(new URL(`models/${name}.json`, self.location.href))
        ).json();
        const session = await ort.InferenceSession.create(
          new URL(`models/${name}.onnx`, self.location.href).href,
          { executionProviders: ["wasm"], logSeverityLevel: 3 },
        );
        return { config, session };
      })(),
    );
  return models.get(name);
}
self.onmessage = async (event) => {
  const { id, name, image, alphabet } = event.data;
  try {
    const { config, session } = await getModel(name);
    if ([...alphabet].some((c) => !config.charset.includes(c)))
      throw Error(`Алфавит ${name} не покрывает профиль.`);
    const encoded = image.slice(image.indexOf(",") + 1),
      bytes = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0));
    const bitmap = await createImageBitmap(
      new Blob([bytes], { type: "image/png" }),
    );
    const h = name === "helper" ? 48 : config.height,
      scaledWidth = Math.ceil((h * bitmap.width) / bitmap.height),
      w =
        name === "helper"
          ? Math.min(
              3200,
              Math.max(320, Math.trunc((h * bitmap.width) / bitmap.height)),
            )
          : Math.max(h, scaledWidth),
      rw = Math.min(w, scaledWidth);
    const canvas = new OffscreenCanvas(rw, h),
      ctx = canvas.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, rw, h);
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(bitmap, 0, 0, rw, h);
    bitmap.close();
    const rgba = ctx.getImageData(0, 0, rw, h).data;
    let data, dims;
    if (name === "helper") {
      data = helperTensor(rgba, rw, h, w);
      dims = [1, 3, h, w];
    } else {
      data = new Float32Array(h * w);
      for (let y = 0; y < h; y++)
        for (let x = 0; x < w; x++) {
          const i = (y * rw + Math.min(x, rw - 1)) * 4;
          data[y * w + x] =
            (0.299 * rgba[i] + 0.587 * rgba[i + 1] + 0.114 * rgba[i + 2]) /
              127.5 -
            1;
        }
      dims = [1, 1, h, w];
    }
    const output = await session.run({
        [session.inputNames[0]]: new ort.Tensor("float32", data, dims),
      }),
      tensor = output[session.outputNames[0]];
    const result = decodeCTC(
      tensor.data,
      tensor.dims,
      config.charset,
      alphabet,
      { logits: name !== "helper" },
    );
    self.postMessage({ id, result: { ...result, engine: name } });
  } catch (error) {
    self.postMessage({ id, error: error.message });
  }
};
