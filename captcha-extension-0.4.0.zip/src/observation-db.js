let pending;
function open() {
  if (!pending)
    pending = new Promise((resolve, reject) => {
      const req = indexedDB.open("captcha-observations", 1);
      req.onupgradeneeded = () =>
        req.result.createObjectStore("records", { keyPath: "id" });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  return pending;
}
export async function loadObservations() {
  const db = await open();
  return new Promise((resolve, reject) => {
    const req = db.transaction("records").objectStore("records").getAll();
    req.onsuccess = () =>
      resolve(
        req.result.sort((a, b) => a.createdAt.localeCompare(b.createdAt)),
      );
    req.onerror = () => reject(req.error);
  });
}
export async function saveObservation(record) {
  const db = await open();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite");
    tx.objectStore("records").put(structuredClone(record));
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}
