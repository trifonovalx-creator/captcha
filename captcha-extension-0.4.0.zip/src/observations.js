// CSV uses RFC4180-style quoting. Labels are metadata and never enter an OCR engine.
export function parseCSV(text) {
  const rows = [];
  let row = [],
    field = "",
    quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') {
        field += '"';
        i++;
      } else quoted = !quoted;
    } else if (c === "," && !quoted) {
      row.push(field);
      field = "";
    } else if ((c === "\n" || c === "\r") && !quoted) {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      if (row.some(Boolean)) rows.push(row);
      row = [];
      field = "";
    } else field += c;
  }
  if (quoted) throw Error("Незакрытая кавычка CSV.");
  if (field || row.length) {
    row.push(field);
    rows.push(row);
  }
  if (!rows.length) return [];
  const header = rows.shift().map((x) => x.replace(/^\uFEFF/, "").trim());
  return rows.map((r) =>
    Object.fromEntries(header.map((k, i) => [k, r[i] ?? ""])),
  );
}
export function observationRecord({
  taskId,
  type,
  image,
  source = "unverified",
  result,
  startedAt,
  task,
  instruction,
  origin,
}) {
  return {
    id: crypto.randomUUID(),
    taskId,
    type,
    source,
    createdAt: new Date().toISOString(),
    startedAt,
    task: task
      ? {
          type: task.type,
          alphabet: task.alphabet,
          min: task.min,
          max: task.max,
          crop: task.crop,
        }
      : undefined,
    instruction,
    origin,
    candidate: result.candidate,
    confidence: result.confidence,
    alternatives: result.ranked || [],
    candidates: (result.candidates || []).map(
      ({ text, confidence, variant, engine, symbols }) => ({
        text,
        confidence,
        variant,
        engine,
        symbols,
      }),
    ),
    wouldFill: result.accepted,
    reason: result.reason,
    answer: null,
    labelVerified: false,
    image,
  };
}
export function evaluateObservations(rows) {
  return rows
    .filter((r) => r.labelVerified && r.answer !== null)
    .map((r) => ({
      ...r,
      bestCorrect: r.candidate === r.answer,
      correct: r.wouldFill && r.candidate === r.answer,
      incorrect: r.wouldFill && r.candidate !== r.answer,
      abstained: !r.wouldFill,
    }));
}
