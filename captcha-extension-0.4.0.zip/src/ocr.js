import { createWorker, PSM } from "tesseract.js";
import { CYRILLIC, decide, cleanOCR } from "./decision.js";
import {
  loadImage,
  crop,
  transform,
  findShapes,
  shapeColumns,
  overlayShapes,
  largeColorComponents,
  normalizeInk,
  darkInk,
} from "./image.js";
let pendingWorker;
let currentLanguage = "rus+eng";
export function getWorker(progress = () => {}) {
  if (!pendingWorker)
    pendingWorker = createWorker("rus+eng", 1, {
      workerPath: chrome.runtime.getURL("vendor/worker.min.js"),
      corePath: chrome.runtime.getURL("vendor/core"),
      langPath: chrome.runtime.getURL("vendor/lang"),
      workerBlobURL: false,
      gzip: true,
      cacheMethod: "none",
      logger: progress,
    }).catch((error) => {
      pendingWorker = null;
      throw error;
    });
  return pendingWorker;
}
export function terminateWorker() {
  const old = pendingWorker;
  pendingWorker = null;
  currentLanguage = "rus+eng";
  if (old) old.then((w) => w.terminate()).catch(() => {});
}
async function read(worker, image, mode, alphabet, blocks = true) {
  await worker.setParameters({
    tessedit_pageseg_mode: mode,
    tessedit_char_whitelist: alphabet,
    preserve_interword_spaces: "0",
  });
  const { data } = await worker.recognize(
    image.toDataURL(),
    {},
    { text: true, blocks },
  );
  return {
    text: cleanOCR(data.text),
    confidence: data.confidence,
    charConfidence: (() => {
      const chars = symbols(data.blocks).filter((c) => cleanOCR(c.text));
      return chars.length &&
        chars.map((c) => cleanOCR(c.text)).join("") === cleanOCR(data.text)
        ? Math.min(...chars.map((c) => c.confidence))
        : undefined;
    })(),
    blocks: data.blocks,
  };
}
function symbols(blocks) {
  return (blocks || []).flatMap((b) =>
    (b.paragraphs || []).flatMap((p) =>
      (p.lines || []).flatMap((l) =>
        (l.words || []).flatMap((w) => w.symbols || []),
      ),
    ),
  );
}
// Replaceable engine interface: recognize({image,type,alphabet,min,max,crop}, {progress}) -> decision + evidence.
// Only image data and task metadata enter here; no page DOM dependencies.
export async function recognize(
  task,
  { progress = () => {}, engines = {}, stage = "final", signal } = {},
) {
  if (engines[task.type]) {
    const evidence = await engines[task.type](task, { progress });
    return {
      ...evidence,
      ...decide(evidence.candidates || [], {
        ...task,
        alphabet: task.type === "shapes" ? CYRILLIC : task.alphabet,
        shapeConfidence: evidence.shapeConfidence ?? 100,
      }),
    };
  }
  signal?.throwIfAborted();
  const worker = await getWorker(progress),
    source = await loadImage(task.image);
  const effectiveAlphabet = task.type === "shapes" ? CYRILLIC : task.alphabet;
  const hasCyrillic = /[А-ЯЁа-яё]/.test(effectiveAlphabet || "");
  const language = hasCyrillic
    ? /[A-Za-z]/.test(effectiveAlphabet)
      ? "rus+eng"
      : "rus"
    : "eng";
  if (currentLanguage !== language) {
    await worker.reinitialize(language, 1);
    currentLanguage = language;
  }
  const debug = [],
    candidates = [];
  const add = (name, c) => debug.push({ name, image: c.toDataURL() });
  let shapeConfidence = 100,
    shapeInfo = [];
  const alphabet = task.type === "shapes" ? CYRILLIC : task.alphabet;
  if (!alphabet)
    return { ...decide([], { ...task, alphabet }), candidates, debug };
  if (task.type === "shapes") {
    signal?.throwIfAborted();
    const shapes = shapeColumns(findShapes(source), source.width);
    shapeInfo = shapes;
    add("Контуры и границы столбцов", overlayShapes(source, shapes));
    const selected = shapes.filter((s) => s.triangle);
    if (!selected.length || shapes.length < 2)
      return {
        candidate: "",
        confidence: 0,
        accepted: false,
        reason: "Не удалось уверенно найти треугольники.",
        candidates,
        debug,
        shapes,
      };
    shapeConfidence = shapes.some(
      (s) => s.width < 8 || s.height < 8 || s.y < source.height * 0.52,
    )
      ? 65
      : 95;
    const top = Math.max(1, Math.min(...shapes.map((s) => s.y)) - 3);
    const strip = crop(
      source,
      { x: 0, y: 0, width: source.width, height: top },
      4,
    );
    add("Верхняя строка букв", strip);
    const full = await read(worker, strip, PSM.SINGLE_LINE, alphabet, true);
    const lineSymbols = symbols(full.blocks).filter((s) => cleanOCR(s.text));
    const byLine = [];
    for (const s of selected) {
      const found = lineSymbols.filter((c) => {
        const x = (c.bbox.x0 + c.bbox.x1) / 8;
        return x >= s.left && x < s.right;
      });
      if (found.length === 1) byLine.push(found[0]);
    }
    const original = [],
      binary = [],
      tight = [],
      tightBinary = [];
    for (const [index, s] of selected.entries()) {
      signal?.throwIfAborted();
      const letter = crop(
        source,
        { x: s.left, y: 0, width: s.right - s.left, height: top },
        4,
      );
      const bin = transform(letter, "binary");
      add(`Треугольник ${index + 1}: символ`, letter);
      add(`Треугольник ${index + 1}: бинаризация`, bin);
      original.push(await read(worker, letter, PSM.SINGLE_CHAR, alphabet));
      binary.push(await read(worker, bin, PSM.SINGLE_CHAR, alphabet));
      const normalized = normalizeInk(letter),
        normalizedBinary = transform(normalized, "binary");
      add(`Треугольник ${index + 1}: плотная обрезка + поля`, normalized);
      add(`Треугольник ${index + 1}: плотная бинаризация`, normalizedBinary);
      tight.push(await read(worker, normalized, PSM.SINGLE_CHAR, alphabet));
      tightBinary.push(
        await read(worker, normalizedBinary, PSM.RAW_LINE, alphabet),
      );
    }
    for (const [variant, list] of [
      ["symbols-original", original],
      ["symbols-binary", binary],
      ["symbols-tight", tight],
      ["symbols-tight-binary", tightBinary],
    ]) {
      candidates.push({
        variant,
        text: list.map((c) => c.text).join(""),
        confidence: Math.min(...list.map((c) => c.confidence)),
        charConfidence: Math.min(
          ...list.map((c) => c.charConfidence ?? c.confidence),
        ),
      });
    }
    if (byLine.length === selected.length)
      candidates.push({
        variant: "line-coordinates",
        text: byLine.map((c) => cleanOCR(c.text)).join(""),
        confidence: Math.min(...byLine.map((c) => c.confidence)),
      });
    debug.push({
      name: "OCR всей строки (не голосует без координат)",
      text: full.text,
      confidence: full.confidence,
      symbolCount: lineSymbols.length,
    });
  } else {
    const bounds = task.crop || { top: 0, bottom: 0, left: 0, right: 0 };
    for (const value of Object.values(bounds))
      if (!Number.isFinite(value) || value < 0 || value >= 1)
        throw Error("Обрезка задаётся долями от 0 до 1.");
    const area = crop(
      source,
      {
        x: source.width * (bounds.left || 0),
        y: source.height * (bounds.top || 0),
        width: source.width * (1 - (bounds.left || 0) - (bounds.right || 0)),
        height: source.height * (1 - (bounds.top || 0) - (bounds.bottom || 0)),
      },
      3,
    );
    add("Область задания ×3", area);
    const modes =
      task.type === "color"
        ? [
            "original",
            "contrast",
            "color",
            "large-components",
            "large-components-color",
          ]
        : ["original", "gray", "binary", "thin-lines"];
    for (const variant of modes) {
      const image =
        variant === "original"
          ? area
          : variant.startsWith("large-components")
            ? largeColorComponents(area, variant === "large-components")
            : transform(area, variant);
      add(variant, image);
      candidates.push({
        variant,
        ...(await read(worker, image, PSM.SINGLE_LINE, alphabet)),
      });
    }
    const normalized = normalizeInk(
      area,
      task.type === "lines" ? 100 : 200,
      96,
    );
    add("Плотная строка с белыми полями", normalized);
    candidates.push({
      variant: "tight-line",
      ...(await read(worker, normalized, PSM.SINGLE_LINE, alphabet)),
    });
    candidates.push({
      variant: "tight-raw",
      ...(await read(worker, normalized, PSM.RAW_LINE, alphabet)),
    });
    if (stage !== "crop" && task.type === "lines") {
      const denoised = normalizeInk(darkInk(area, 110), 100, 96);
      add("Тёмные штрихи; слабые линии подавлены", denoised);
      candidates.push({
        variant: "dark-line",
        ...(await read(worker, denoised, PSM.SINGLE_LINE, alphabet)),
      });
      candidates.push({
        variant: "dark-raw",
        ...(await read(worker, denoised, PSM.RAW_LINE, alphabet)),
      });
    }
    if (task.type === "lines") {
      // Segment only if full-height projection produces isolated, stable glyph regions.
      const image = transform(area, "binary"),
        ctx = image.getContext("2d"),
        data = ctx.getImageData(0, 0, image.width, image.height).data;
      const runs = [];
      let start = -1;
      for (let x = 0; x <= image.width; x++) {
        let count = 0;
        if (x < image.width)
          for (let y = 0; y < image.height; y++)
            if (data[(y * image.width + x) * 4] === 0) count++;
        if (count > 1 && start < 0) start = x;
        if (count <= 1 && start >= 0) {
          if (x - start > 4) runs.push({ start, end: x });
          start = -1;
        }
      }
      if (
        runs.length >= task.min &&
        runs.length <= task.max &&
        runs.every((r) => r.end - r.start > 10)
      ) {
        const chars = [];
        for (const r of runs)
          chars.push(
            await read(
              worker,
              crop(image, {
                x: Math.max(0, r.start - 3),
                y: 0,
                width: Math.min(image.width - r.start, r.end - r.start + 6),
                height: image.height,
              }),
              PSM.SINGLE_CHAR,
              alphabet,
            ),
          );
        candidates.push({
          variant: "stable-components",
          text: chars.map((c) => c.text).join(""),
          confidence: Math.min(...chars.map((c) => c.confidence)),
        });
      }
    }
  }
  if (stage === "symbols" || stage === "final")
    for (const c of candidates) {
      c.wordConfidence = c.confidence;
      if (Number.isFinite(c.charConfidence)) c.confidence = c.charConfidence;
    }
  signal?.throwIfAborted();
  return {
    ...decide(candidates, { ...task, alphabet, shapeConfidence }),
    candidates,
    debug,
    shapes: shapeInfo,
    shapeConfidence,
  };
}
