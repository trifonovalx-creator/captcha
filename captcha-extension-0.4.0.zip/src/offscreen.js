import {recognize, terminateAll} from './pipeline.js';
import {untilDeadline} from './budget.js';
import {observationRecord} from './observations.js';
import {saveObservation} from './observation-db.js';
let active = null;
chrome.runtime.onMessage.addListener((m,sender,reply) => {
  if (sender.id !== chrome.runtime.id || m.target !== 'offscreen') return;
  if (m.kind === 'CANCEL_OCR') {
    if (active?.id === m.id) active.abort.abort(new DOMException('Остановлено','AbortError'));
    reply({ok:true});return;
  }
  if (m.kind !== 'RUN_OCR') return;
  if (active) {reply({ok:false,error:'OCR занят другой вкладкой. Дождитесь завершения и нажмите иконку снова.'});return;}
  const job = {id:m.id,abort:new AbortController()}; active = job;
  (async () => {
    try {
      const result = await untilDeadline(recognize(m.task,{signal:job.abort.signal,deadline:m.deadline}),m.deadline,job.abort.signal);
      if (m.observe) await saveObservation(observationRecord({taskId:m.id,type:m.task.type,image:m.task.image,result,startedAt:m.startedAt,task:m.task,origin:m.origin}));
      reply({ok:true,result:{candidate:result.candidate,accepted:result.accepted,confidence:result.confidence,reason:result.reason,path:result.path,candidates:result.candidates?.map(({text,confidence,variant,engine,symbols})=>({text,confidence,variant,engine,symbols}))}});
    } catch(error) {reply({ok:false,error:error.message,name:error.name});}
    finally {job.abort.abort();terminateAll();if(active===job)active=null;}
  })(); return true;
});
