import {DEFAULT_PROFILE} from './profile.js';
const $=id=>document.getElementById(id);
const fields={container:'Блок или форма капчи (пусто — документ, нужна связь через form)',image:'Изображение: img или canvas',input:'Поле ответа',instruction:'Инструкция (можно оставить пустым при явном выборе типа)',minSelector:'Ограничение min (пусто — minlength поля)',maxSelector:'Ограничение max (пусто — maxlength поля)',submitSelector:'Подтверждающая кнопка (необязательно)',frameSelector:'iframe в основном документе (необязательно; только доступный с activeTab)'};
let profile=structuredClone(DEFAULT_PROFILE);
for(const [key,title] of Object.entries(fields)){
 const label=document.createElement('label');label.textContent=title;
 const input=document.createElement('input');input.id=key;input.spellcheck=false;label.append(input);$('selectors').append(label);
}
for(const [key,title] of Object.entries({top:'Сверху',bottom:'Снизу',left:'Слева',right:'Справа'})){
 const label=document.createElement('label');label.textContent=title;const input=document.createElement('input');input.id='crop-'+key;input.type='number';input.min=0;input.max=.9;input.step=.01;label.append(input);$('crop-fields').append(label);
}
function origin(){const url=new URL($('origin').value);if(!['https:','http:'].includes(url.protocol))throw Error('Нужен адрес HTTP(S)-сайта.');return url.origin;}
function render(){
 for(const key of [...Object.keys(fields),'type','alphabet','mode','waitForMs'])$(key).value=profile[key]??'';
 for(const key of ['top','bottom','left','right'])$('crop-'+key).value=profile.crop[key];
}
async function sites(){const all=await chrome.storage.local.get(null);$('sites').replaceChildren(new Option('Выберите профиль',''));for(const key of Object.keys(all).filter(k=>k.startsWith('profile:http')).sort())$('sites').append(new Option(key.slice(8),key.slice(8)));}
async function load(){try{const site=origin(),saved=(await chrome.storage.local.get('profile:'+site))['profile:'+site];profile={...DEFAULT_PROFILE,...saved,crop:{...DEFAULT_PROFILE.crop,...saved?.crop}};render();$('saved').textContent=saved?'Профиль загружен.':'Новый профиль: измените селекторы и сохраните.';}catch(e){$('saved').textContent=e.message;}}
$('load').onclick=load;$('sites').onchange=()=>{if($('sites').value){$('origin').value=$('sites').value;load();}};
$('profile-form').onsubmit=async event=>{
 event.preventDefault();try{
  const site=origin(),next={...profile,crop:{}};
  for(const key of Object.keys(fields)){next[key]=$(key).value.trim();if(next[key])try{document.querySelector(next[key]);}catch{throw Error('Некорректный селектор: '+fields[key]);}}
  if(!next.image||!next.input)throw Error('Нужны селекторы изображения и поля.');
  for(const key of ['type','mode'])next[key]=$(key).value;
  next.alphabet=$('alphabet').value.replace(/\s/g,'');if(!next.alphabet)throw Error('Алфавит не должен быть пустым.');
  next.waitForMs=Number($('waitForMs').value);if(!Number.isInteger(next.waitForMs)||next.waitForMs<100||next.waitForMs>10000)throw Error('Ожидание: от 100 до 10000 мс.');
  for(const key of ['top','bottom','left','right']){const value=Number($('crop-'+key).value);if(!Number.isFinite(value)||value<0||value>.9)throw Error('Некорректная обрезка.');next.crop[key]=value;}
  if(next.crop.top+next.crop.bottom>=1||next.crop.left+next.crop.right>=1)throw Error('Обрезка удаляет всё изображение.');
  await chrome.storage.local.set({['profile:'+site]:next});profile=next;await sites();$('saved').textContent='Сохранено для '+site+'. Вернитесь на сайт и нажмите иконку расширения.';
 }catch(e){$('saved').textContent=e.message;}
};
$('origin').value=new URLSearchParams(location.search).get('origin')||'http://127.0.0.1:4173';
await sites();await load();
