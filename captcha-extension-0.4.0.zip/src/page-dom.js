export class MissingElement extends Error {}
export function unique(root, selector, label, optional = false) {
  if (!selector && optional) return null;
  if (!selector) throw Error(`Не задан селектор: ${label}.`);
  let list;
  try { list = root.querySelectorAll(selector); }
  catch { throw Error(`Некорректный селектор: ${label}.`); }
  if (!list.length) throw new MissingElement(`${label}: элемент не найден.`);
  if (list.length !== 1) throw Error(`${label}: найдено ${list.length} элементов; выбор неоднозначен.`);
  return list[0];
}
export function visible(el) {
  const style = getComputedStyle(el);
  return el.getClientRects().length > 0 && style.display !== 'none' &&
    style.visibility !== 'hidden' && style.visibility !== 'collapse' && !el.closest('[inert]');
}
export function accessibleName(el) {
  const labelled = el.getAttribute('aria-labelledby')?.trim();
  if (labelled) return labelled.split(/\s+/).map(id => el.ownerDocument.getElementById(id)?.textContent || '').join(' ').trim();
  return (el.getAttribute('aria-label') ||
    (el instanceof HTMLInputElement ? el.getAttribute('alt') || el.value : el.textContent) ||
    el.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
}
export function locate(profile) {
  const root = profile.container ? unique(document, profile.container, 'Блок капчи') : document;
  const image = unique(root, profile.image, 'Изображение');
  if (!(image instanceof HTMLImageElement || image instanceof HTMLCanvasElement))
    throw Error('Изображение должно быть <img> или <canvas>.');
  if (!visible(image)) throw new MissingElement('Изображение пока скрыто.');
  const input = unique(root, profile.input, 'Поле ответа');
  if (!(input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement) ||
    (input instanceof HTMLInputElement && !['text','search','tel','url','email','password'].includes(input.type)))
    throw Error('Поле ответа не является текстовым полем.');
  if (!visible(input)) throw new MissingElement('Поле ответа пока скрыто.');
  if (input.matches(':disabled') || input.readOnly) throw Error('Поле ответа отключено или доступно только для чтения.');
  const form = input.form;
  const imageForm = image.closest('form');
  if (imageForm && imageForm !== form) throw Error('Изображение и поле относятся к разным формам.');
  if (root === document && (!form || !form.contains(image)))
    throw Error('Не удалось связать изображение и поле с одной формой. Задайте блок капчи.');
  const instruction = unique(root, profile.instruction, 'Инструкция', true)?.textContent.trim() || '';
  const bound = (selector, native, name) => {
    const el = unique(root, selector, name, true);
    const text = el ? el.getAttribute('value') || el.textContent : native;
    const numbers = String(text ?? '').match(/\d+/g);
    if (numbers?.length !== 1) throw Error(`Нужно однозначное ограничение ${name}; задайте селектор или атрибут поля.`);
    return Number(numbers[0]);
  };
  const min = bound(profile.minSelector, input.getAttribute('minlength'), 'min');
  const max = bound(profile.maxSelector, input.getAttribute('maxlength'), 'max');
  if (min < 1 || max < min || max > 64) throw Error('Некорректная длина ответа (1–64).');
  return {root, image, input, form, instruction, min, max};
}
export function pixels(image) {
  const w = image instanceof HTMLImageElement ? image.naturalWidth : image.width;
  const h = image instanceof HTMLImageElement ? image.naturalHeight : image.height;
  if (image instanceof HTMLImageElement && !image.complete) throw new MissingElement('Изображение ещё загружается.');
  if (!w || !h || w*h > 12_000_000) throw Error('Изображение пустое, не загрузилось или больше 12 Мп.');
  if (image instanceof HTMLCanvasElement) return image.toDataURL('image/png');
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  c.getContext('2d').drawImage(image,0,0); return c.toDataURL('image/png');
}
const controls = 'button,input[type="submit"],input[type="button"],input[type="image"],[role="button"]';
const supportedLabel = /^(отправить|проверить|подтвердить|далее|продолжить|submit|verify|confirm|next|continue)(?:\s|[→➜!:.]|$)/i;
function related(el, found) {
  return found.form ? (el.form === found.form || (!('form' in el) && el.closest('form') === found.form))
    : found.root.contains(el) && !el.closest('form');
}
export function chooseButton(found, profile) {
  // Form ownership includes buttons outside the form with form="...".
  const scope = found.form ? document : found.root;
  const candidates = [...scope.querySelectorAll(profile.submitSelector || controls)].filter(el => related(el,found));
  let buttons = candidates;
  if (!profile.submitSelector) buttons = buttons.filter(el => supportedLabel.test(accessibleName(el)));
  // A known skip/refresh button never becomes the confirming action through type=submit.
  buttons = buttons.filter(el => !/^(пропустить|skip|другая картинка|обновить|refresh|отмена|cancel)(?:\s|[→!:.]|$)/i.test(accessibleName(el)));
  if (buttons.length !== 1) return {ok:false,waitable:buttons.length===0,reason:buttons.length ?
    `Ответ введён. Найдено ${buttons.length} подходящих кнопок; отправка неоднозначна.` : 'Ответ введён. Подходящая кнопка не найдена.'};
  const button = buttons[0];
  if (!(button instanceof HTMLElement) || !button.matches(controls) || typeof button.click !== 'function')
    return {ok:false,reason:'Ответ введён. Выбранный элемент не является кнопкой.'};
  if (button.type === 'reset') return {ok:false,reason:'Ответ введён. Кнопка reset не подтверждает ответ.'};
  if (!visible(button) || button.matches(':disabled') || button.getAttribute('aria-disabled') === 'true')
    return {ok:false,waitable:true,reason:'Ответ введён. Кнопка скрыта или отключена.'};
  return {ok:true,button,name:accessibleName(button) || 'submit',type:button.type || button.getAttribute('role')};
}
