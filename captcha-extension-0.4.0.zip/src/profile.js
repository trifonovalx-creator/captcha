import { LATIN } from "./decision.js";
export const DEFAULT_PROFILE = {
  container: "[data-captcha]",
  image: "[data-captcha-image]",
  instruction: "[data-captcha-instruction]",
  minSelector: "[data-captcha-min]",
  maxSelector: "[data-captcha-max]",
  input: "[data-captcha-answer]",
  submitSelector: "",
  frameSelector: "",
  waitForMs: 5000,
  type: "auto",
  alphabet: LATIN,
  crop: { top: 0, bottom: 0, left: 0, right: 0 },
  debug: true,
  mode: "auto",
  maxConsecutiveSkips: 3,
  skipLowConfidence: false,
  skipSelector: "[data-captcha-skip]",
  feedbackSelector: "",
  feedbackSuccess: "",
  feedbackFailure: "",
};
export function inferType(instruction) {
  if (/треуголь|triangle/i.test(instruction)) return "shapes";
  if (/цветн|color|colour/i.test(instruction)) return "color";
  if (/наклон|пересека|slant|crossing/i.test(instruction)) return "lines";
  throw Error("Тип не определён по инструкции. Выберите его вручную.");
}
export function inferAlphabet(instruction, configured) {
  if (/кирилл|cyrillic/i.test(instruction))
    return "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
  if (/только цифр|digits only/i.test(instruction)) return "0123456789";
  return configured;
}
