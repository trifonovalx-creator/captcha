async function decodeLocalPNG(url) {
  const bytes = Uint8Array.from(atob(url.slice(url.indexOf(",") + 1)), (c) =>
    c.charCodeAt(0),
  );
  return createImageBitmap(new Blob([bytes], { type: "image/png" }));
}
export async function capturePage(tabId, {rect, viewport}) {
  const tab = await chrome.tabs.get(tabId);
  if (!tab.active) throw Error('Для захвата изображения вкладка должна оставаться активной.');
  if (!rect || !viewport || rect.width <= 0 || rect.height <= 0 || rect.x < 0 || rect.y < 0 || rect.x + rect.width > viewport.width || rect.y + rect.height > viewport.height)
    throw Error('Картинка должна быть целиком видна на экране.');
  const shot = await decodeLocalPNG(await chrome.tabs.captureVisibleTab(tab.windowId,{format:'png'}));
  const sx=shot.width/viewport.width, sy=shot.height/viewport.height;
  const w=Math.round(rect.width*sx),h=Math.round(rect.height*sy);
  const c=new OffscreenCanvas(w,h),ctx=c.getContext('2d');
  ctx.fillStyle='white';ctx.fillRect(0,0,w,h);
  ctx.drawImage(shot,Math.round(rect.x*sx),Math.round(rect.y*sy),w,h,0,0,w,h);shot.close();
  if(!(await chrome.tabs.get(tabId)).active)throw Error('Вкладка сменилась во время захвата.');
  const bytes=new Uint8Array(await (await c.convertToBlob({type:'image/png'})).arrayBuffer());
  let text='';for(let i=0;i<bytes.length;i+=8192)text+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return 'data:image/png;base64,'+btoa(text);
}
export async function verifyVisibleImage(tabId, { image, rect, viewport }) {
  const tab = await chrome.tabs.get(tabId);
  if (!tab.active) throw Error("Исходная вкладка не активна.");
  const shot = await decodeLocalPNG(
    await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" }),
  );
  const expected = await decodeLocalPNG(image),
    sx = shot.width / viewport.width,
    sy = shot.height / viewport.height;
  const x = Math.round(rect.x * sx),
    y = Math.round(rect.y * sy),
    w = Math.round(rect.width * sx),
    h = Math.round(rect.height * sy);
  if (
    rect.x < 0 ||
    rect.y < 0 ||
    rect.x + rect.width > viewport.width ||
    rect.y + rect.height > viewport.height ||
    w !== expected.width ||
    h !== expected.height
  )
    throw Error("Область изображения изменилась или вне экрана.");
  const c = new OffscreenCanvas(w, h),
    ctx = c.getContext("2d");
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(shot, x, y, w, h, 0, 0, w, h);
  const a = ctx.getImageData(0, 0, w, h).data;
  ctx.clearRect(0, 0, w, h);
  ctx.drawImage(expected, 0, 0);
  const b = ctx.getImageData(0, 0, w, h).data;
  shot.close();
  expected.close();
  if (!(await chrome.tabs.get(tabId)).active) return false;
  return a.length === b.length && a.every((v, i) => v === b[i]);
}
