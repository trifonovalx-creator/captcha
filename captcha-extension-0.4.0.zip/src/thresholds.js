// Release policy after known q/g false fills: lines and color remain manual. Shapes tuned on fresh tune only.
export const THRESHOLDS = Object.freeze({ shapes: 85, color: 101, lines: 101 });

export const AUTO_TYPES = Object.freeze(["shapes", "color", "lines"]);
