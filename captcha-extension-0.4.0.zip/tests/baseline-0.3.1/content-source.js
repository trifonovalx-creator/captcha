import { OCR_BUDGET_MS, ACTION_DEADLINE_MS } from "./budget.js";
import { AUTO_TYPES } from "./thresholds.js";
import { inferType } from "./profile.js";
(() => {
  if (globalThis.__captchaMVP) return;
  let observer,
    timer,
    epoch = 0,
    active = false,
    lastProfile,
    sequence = 0;
  let current = null,
    pendingFeedback = null;
  const skippedChallenges = new Set();
  const leases = new Map();
  const documentId =
    Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
  let lease = null,
    leaseSeq = 0;
  let skipsInARow = 0;
  const timing = [];
  const ids = new WeakMap();
  let nextId = 1;
  const id = (el) => {
    if (!ids.has(el)) ids.set(el, nextId++);
    return ids.get(el);
  };
  function unique(root, selector, label, optional = false) {
    if (!selector && optional) return null;
    if (!selector) throw Error(`Не задан селектор: ${label}.`);
    let list;
    try {
      list = root.querySelectorAll(selector);
    } catch {
      throw Error(`Некорректный селектор: ${label}.`);
    }
    if (list.length !== 1)
      throw Error(
        `${label}: найдено ${list.length} элементов; нужен ровно один.`,
      );
    return list[0];
  }
  function locate(profile) {
    const root = profile.container
      ? unique(document, profile.container, "Контейнер")
      : document;
    const image = unique(root, profile.image, "Изображение");
    if (
      !(image instanceof HTMLImageElement || image instanceof HTMLCanvasElement)
    )
      throw Error("Изображение должно быть <img> или <canvas>.");
    const input = unique(root, profile.input, "Поле ответа");
    if (
      !(
        input instanceof HTMLInputElement ||
        input instanceof HTMLTextAreaElement
      ) ||
      input.disabled ||
      input.readOnly ||
      (input instanceof HTMLInputElement &&
        !["text", "search", "tel", "url", "email", "password"].includes(
          input.type,
        ))
    )
      throw Error("Поле недоступно для текстового ввода.");
    const instruction = unique(
      root,
      profile.instruction,
      "Инструкция",
    ).textContent.trim();
    const bound = (selector, native, label) => {
      const element = unique(root, selector, label, true),
        text = element
          ? element.getAttribute("value") || element.textContent
          : native;
      if (text === null || text === undefined || text === "")
        throw Error(`Не задано ограничение ${label}.`);
      const matches = String(text).match(/\d+/g);
      if (matches?.length !== 1)
        throw Error(`Неоднозначное ограничение ${label}.`);
      return Number(matches[0]);
    };
    const min = bound(
      profile.minSelector,
      input.getAttribute("minlength"),
      "min",
    );
    const max = bound(
      profile.maxSelector,
      input.getAttribute("maxlength"),
      "max",
    );
    if (min < 1 || max < min || max > 64)
      throw Error("Некорректный диапазон длины (1–64).");
    return { image, input, instruction, min, max };
  }
  const hash = (text) => {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16);
  };
  function pixels(image) {
    if (image instanceof HTMLCanvasElement) return image.toDataURL("image/png");
    if (!image.complete || !image.naturalWidth)
      throw Error("Картинка ещё не загружена.");
    if (image.naturalWidth * image.naturalHeight > 12_000_000)
      throw Error("Изображение слишком большое.");
    const c = document.createElement("canvas");
    c.width = image.naturalWidth;
    c.height = image.naturalHeight;
    c.getContext("2d").drawImage(image, 0, 0);
    return c.toDataURL("image/png");
  }
  function state(profile) {
    const found = locate(profile);
    let imageData = null;
    try {
      imageData = pixels(found.image);
    } catch (error) {
      if (found.image instanceof HTMLImageElement && !found.image.complete) {
      } else if (error.name !== "SecurityError") throw error;
    }
    const rect = found.image.getBoundingClientRect();
    const imageStyle = getComputedStyle(found.image);
    if (
      !imageData &&
      found.image.complete !== false &&
      (imageStyle.objectFit === "contain" ||
        imageStyle.objectFit === "cover" ||
        imageStyle.transform !== "none")
    )
      throw Error(
        "Захват: object-fit/transform требуют отдельного профиля обрезки.",
      );
    const identity = JSON.stringify([
      id(found.image),
      id(found.input),
      found.image.currentSrc || found.image.src || "",
      hash(imageData || ""),
      imageData
        ? null
        : [rect.x, rect.y, rect.width, rect.height, innerWidth, innerHeight],
      found.instruction,
      found.min,
      found.max,
    ]);
    return {
      ...found,
      loading: found.image instanceof HTMLImageElement && !found.image.complete,
      challenge: JSON.stringify([
        found.image.currentSrc || found.image.src || "",
        hash(imageData || ""),
        found.instruction,
      ]),
      imageData,
      key: hash(identity),
      identity,
      rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
      viewport: { width: innerWidth, height: innerHeight },
      epoch,
    };
  }
  function notify(message) {
    chrome.runtime.sendMessage(message).catch(() => {});
  }
  function storeSnapshot(s, profile, detectedAt = Date.now()) {
    const base = JSON.stringify([
      s.image.currentSrc || s.image.src || "",
      s.instruction,
    ]);
    let next = leases.get(s.challenge);
    if (!next && lease?.loading && lease.base === base && !lease.action) {
      next = lease;
      leases.set(s.challenge, next);
    }
    if (!next) {
      const type =
        profile.type === "auto" ? inferType(s.instruction) : profile.type;
      next = {
        id: documentId + ":" + ++leaseSeq,
        base,
        startedAt: detectedAt,
        action: null,
        loading: s.loading,
        auto: profile.mode !== "observe" && AUTO_TYPES.includes(type),
        type,
        timer: null,
      };
      leases.set(s.challenge, next);
    }
    if (lease !== next) clearTimeout(lease?.timer);
    lease = next;
    lease.loading = s.loading;
    const token = `${++sequence}:${s.key}:${epoch}`;
    current = { ...s, token, profile, lease };
    if (active && !lease.action && !lease.timer) {
      const task = lease;
      task.timer = setTimeout(
        async () => {
          task.timer = null;
          if (!active || lease !== task || task.action) return;
          if (!task.auto) {
            task.action = "observed-timeout";
            notify({
              kind: "TASK_TIMEOUT",
              taskId: task.id,
              observation: true,
              startedAt: task.startedAt,
            });
            return;
          }
          try {
            if (!current.imageData && !current.loading) {
              if (!task.captureImage) {
                pause(
                  "Нет исходного снимка для перепроверки перед пропуском.",
                  task,
                );
                return;
              }
              const verification = await Promise.race([
                chrome.runtime.sendMessage({
                  kind: "VERIFY_VISIBLE_IMAGE",
                  image: task.captureImage,
                  rect: current.rect,
                  viewport: current.viewport,
                }),
                new Promise((resolve) =>
                  setTimeout(
                    () =>
                      resolve({
                        ok: false,
                        reason: "Перепроверка снимка не уложилась в дедлайн.",
                      }),
                    Math.max(
                      0,
                      task.startedAt + ACTION_DEADLINE_MS - Date.now() - 20,
                    ),
                  ),
                ),
              ]);
              if (!active || lease !== task || task.action) return;
              if (!verification.ok) {
                pause(
                  verification.reason || "Изображение изменилось во время OCR.",
                  task,
                );
                return;
              }
              task.captureVerifiedAt = Date.now();
            }
            const result = skip({ token: current.token, timeout: true });
            if (!result.clicked) {
              pause(result.reason, task);
              return;
            }
            notify({
              kind: "TASK_ACTION",
              taskId: task.id,
              startedAt: task.startedAt,
              ...result,
            });
          } catch (error) {
            pause(error.message, task);
          }
        },
        Math.max(0, lease.startedAt + OCR_BUDGET_MS - Date.now()),
      );
    }
    return current;
  }
  async function snapshot(profile) {
    const detectedAt = Date.now(),
      s = storeSnapshot(state(profile), profile, detectedAt);
    return {
      token: s.token,
      key: s.key,
      challenge: s.challenge,
      epoch: s.epoch,
      image: s.imageData,
      instruction: s.instruction,
      min: s.min,
      max: s.max,
      rect: s.rect,
      viewport: s.viewport,
      manual: !!s.input.value,
      fallback: !s.imageData && !s.loading,
      loading: s.loading,
      taskId: s.lease.id,
      startedAt: s.lease.startedAt,
      deadline: s.lease.startedAt + ACTION_DEADLINE_MS,
      ocrDeadline: s.lease.startedAt + OCR_BUDGET_MS,
      auto: s.lease.auto,
      action: s.lease.action,
    };
  }
  function pause(reason, task = lease) {
    if (task) {
      task.action = task.action || "paused";
      clearTimeout(task.timer);
      task.timer = null;
    }
    active = false;
    notify({ kind: "TASK_PAUSED", reason, taskId: task?.id });
    return { clicked: false, ok: false, reason, paused: true };
  }
  function permit(kind, message) {
    if (!active || !current)
      return { ok: false, reason: "Задача остановлена." };
    if (!lease || !lease.auto)
      return {
        ok: false,
        reason: "Режим наблюдения: автоматические действия запрещены.",
      };
    if (
      !current.imageData &&
      !current.loading &&
      (!lease.captureVerifiedAt || Date.now() - lease.captureVerifiedAt > 1000)
    )
      return {
        ok: false,
        reason: "Нужно перепроверить снимок перед действием.",
      };
    if (lease.action)
      return {
        ok: false,
        reason: "Автоматическое действие для этой капчи уже завершено.",
      };
    if (Date.now() >= lease.startedAt + ACTION_DEADLINE_MS)
      return pause("Дедлайн 30 секунд истёк; позднее действие запрещено.");
    if (message.taskId && message.taskId !== lease.id)
      return { ok: false, reason: "Ответ относится к предыдущей капче." };
    return { ok: true };
  }
  function recordAction(kind) {
    const actionAt = Date.now();
    if (actionAt >= lease.startedAt + ACTION_DEADLINE_MS) {
      timing.push({
        taskId: lease.id,
        type: lease.type,
        kind: "missed-deadline",
        elapsedMs: actionAt - lease.startedAt,
        overrun: true,
      });
      pause("Дедлайн 30 секунд истёк.");
      throw Error("Позднее действие запрещено.");
    }
    lease.action = kind;
    clearTimeout(lease.timer);
    lease.timer = null;
    const row = {
      taskId: lease.id,
      type: lease.type,
      kind,
      startedAt: lease.startedAt,
      actionAt,
      elapsedMs: actionAt - lease.startedAt,
      overrun: actionAt - lease.startedAt > ACTION_DEADLINE_MS,
    };
    timing.push(row);
    return row;
  }
  function announce() {
    if (!active) return;
    notify({
      kind: "CAPTCHA_CHANGED",
      taskId: lease?.id,
      startedAt: lease?.startedAt,
    });
  }
  function invalidated() {
    epoch++;
    clearTimeout(timer);
    timer = setTimeout(announce, 220);
  }
  function observe(profile) {
    stop();
    active = true;
    lastProfile = profile;
    snapshot(profile).catch((error) => pause(error.message));
    observer = new MutationObserver((records) => {
      // Input attributes are deliberately included: any relevant DOM change invalidates pending OCR.
      let root;
      try {
        root = lastProfile.container
          ? document.querySelector(lastProfile.container)
          : document.documentElement;
      } catch {
        invalidated();
        return;
      }
      if (
        !root ||
        records.some(
          (r) =>
            root === r.target ||
            root.contains(r.target) ||
            [...(r.removedNodes || [])].some(
              (n) => n === root || n.contains?.(root),
            ),
        )
      ) {
        invalidated();
        try {
          const detectedAt = Date.now(),
            s = state(lastProfile);
          if (current && s.challenge !== current.challenge)
            storeSnapshot(s, lastProfile, detectedAt);
        } catch {}
      }
    });
    observer.observe(document.documentElement, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: [
        "src",
        "srcset",
        "width",
        "height",
        "minlength",
        "maxlength",
        "disabled",
        "readonly",
        "value",
        "class",
        "style",
      ],
    });
    document.addEventListener("load", invalidated, true);
    document.addEventListener("input", onInput, true);
    for (const name of ["beforeinput", "compositionstart", "paste"])
      document.addEventListener(name, onInput, true);
    document.addEventListener("keydown", onKey, true);
    // Canvas drawing is not a DOM mutation; lightweight fingerprints cover canvas-only refreshes.
    globalThis.__captchaMVP.poll = setInterval(() => {
      if (!active) return;
      reportFeedback();
      try {
        const detectedAt = Date.now(),
          s = state(lastProfile);
        if (current && s.challenge !== current.challenge) {
          invalidated();
          storeSnapshot(s, lastProfile, detectedAt);
        } else if (current && s.identity !== current.identity) invalidated();
        else if (current && !s.imageData) announce();
      } catch {
        invalidated();
      }
    }, 700);
  }
  function onKey(event) {
    if (
      event.key.length === 1 ||
      event.key === "Backspace" ||
      event.key === "Delete"
    )
      onInput(event);
  }
  function onInput(event) {
    if (current?.input === event.target) {
      invalidated();
      if (active && lease?.auto && !lease.action)
        pause("Пользователь начал ввод; автоматические действия остановлены.");
    }
  }
  function stop() {
    active = false;
    epoch++;
    observer?.disconnect();
    clearTimeout(timer);
    clearInterval(globalThis.__captchaMVP?.poll);
    document.removeEventListener("load", invalidated, true);
    document.removeEventListener("input", onInput, true);
    for (const name of ["beforeinput", "compositionstart", "paste"])
      document.removeEventListener(name, onInput, true);
    document.removeEventListener("keydown", onKey, true);
    clearTimeout(lease?.timer);
    if (lease) lease.timer = null;
    current = null;
  }
  async function fill(message) {
    const permission = permit("fill", message);
    if (!permission.ok) return permission;
    if (!active || !current || message.token !== current.token)
      return { ok: false, reason: "Задача остановлена или устарела." };
    const saved = current,
      fresh = state(saved.profile);
    if (
      fresh.identity !== saved.identity ||
      fresh.imageData !== saved.imageData ||
      fresh.epoch !== saved.epoch ||
      fresh.image !== saved.image ||
      fresh.input !== saved.input
    )
      return {
        ok: false,
        reason: "Капча или поле изменились; поздний ответ отброшен.",
      };
    if (fresh.loading)
      return { ok: false, reason: "Изображение ещё загружается." };
    if (fresh.input.value)
      return { ok: false, reason: "В поле уже есть текст; он сохранён." };
    if (message.value.length < fresh.min || message.value.length > fresh.max)
      return { ok: false, reason: "Изменились ограничения длины." };
    const prototype =
      fresh.input instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
    const actionRecord = recordAction("fill");
    skipsInARow = 0;
    Object.getOwnPropertyDescriptor(prototype, "value").set.call(
      fresh.input,
      message.value,
    );
    const feedbackBefore = feedbackText(saved.profile);
    fresh.input.dispatchEvent(new Event("input", { bubbles: true }));
    await new Promise((resolve) => setTimeout(resolve, 150));
    let check;
    try {
      check = state(saved.profile);
    } catch {
      return { ok: false, reason: "Страница изменилась после input." };
    }
    if (check.identity !== saved.identity || check.input !== saved.input)
      return { ok: false, reason: "Капча сменилась после input." };
    if (check.input.value === message.value)
      pendingFeedback = {
        token: message.token,
        profile: saved.profile,
        before: feedbackBefore,
      };
    return check.input.value === message.value
      ? { ok: true, actionRecord }
      : { ok: false, reason: "Страница не сохранила введённое значение." };
  }
  function feedbackText(profile) {
    if (!profile.feedbackSelector) return null;
    try {
      const root = profile.container
        ? unique(document, profile.container, "Контейнер")
        : document;
      return unique(
        root,
        profile.feedbackSelector,
        "Обратная связь",
      ).textContent.trim();
    } catch {
      return null;
    }
  }
  function reportFeedback() {
    if (!pendingFeedback) return;
    const p = pendingFeedback,
      text = feedbackText(p.profile);
    if (text === null || text === p.before) return;
    const outcome =
      text === p.profile.feedbackSuccess
        ? "correct"
        : text === p.profile.feedbackFailure
          ? "incorrect"
          : null;
    if (outcome) {
      pendingFeedback = null;
      chrome.runtime
        .sendMessage({ kind: "CAPTCHA_FEEDBACK", token: p.token, outcome })
        .catch(() => {});
    }
  }
  function skip(message) {
    const permission = permit("skip", message);
    if (!permission.ok) return { ...permission, clicked: false };
    if (skipsInARow >= Number(current?.profile.maxConsecutiveSkips || 3))
      return pause("Достигнут лимит пропусков подряд.");
    if (!active || !current || message.token !== current.token)
      return { clicked: false, reason: "Задача остановлена или устарела." };
    const saved = current,
      fresh = state(saved.profile);
    if (
      fresh.identity !== saved.identity ||
      fresh.imageData !== saved.imageData ||
      fresh.epoch !== saved.epoch ||
      fresh.input !== saved.input
    )
      return {
        clicked: false,
        reason:
          "Капча изменилась или пользователь начал ввод; пропуск отменён.",
      };
    if (fresh.input.value)
      return {
        clicked: false,
        reason: "В поле есть ручной текст; пропуск отменён.",
      };
    if (skippedChallenges.has(fresh.challenge))
      return {
        clicked: false,
        reason:
          "Пропустить уже нажато для этой капчи. Повторное нажатие запрещено.",
      };
    const root = saved.profile.container
      ? unique(document, saved.profile.container, "Контейнер")
      : document;
    const button = unique(
      root,
      saved.profile.skipSelector,
      "Кнопка Пропустить",
    );
    if (
      !(button instanceof HTMLElement) ||
      !button.matches(
        "button,input[type=button],input[type=submit],[role=button],a[href]",
      ) ||
      typeof button.click !== "function"
    )
      return {
        clicked: false,
        reason: "Элемент Пропустить не является кнопкой.",
      };
    if (
      button.matches(":disabled") ||
      button.getAttribute("aria-disabled") === "true" ||
      button.getClientRects().length === 0 ||
      getComputedStyle(button).visibility === "hidden" ||
      button.closest("[inert]")
    )
      return {
        clicked: false,
        reason: "Кнопка Пропустить отключена или скрыта.",
      };
    skippedChallenges.add(fresh.challenge);
    const actionRecord = recordAction("skip");
    skipsInARow++;
    button.click();
    return {
      clicked: true,
      challenge: fresh.challenge,
      actionRecord,
      skipsInARow,
    };
  }
  setInterval(reportFeedback, 500);
  globalThis.__captchaMVP = { stop };
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    const run = async () => {
      if (message.kind === "START") {
        if (message.resetSeries) {
          skipsInARow = 0;
          if (lease?.action === "paused") lease.action = null;
        }
        observe(message.profile);
        return { ok: true };
      }
      if (message.kind === "STOP") {
        stop();
        return { ok: true };
      }
      if (message.kind === "CAPTURE_BASELINE") {
        if (current?.token !== message.token) return { ok: false };
        lease.captureImage = message.image;
        if (message.verified) lease.captureVerifiedAt = Date.now();
        return { ok: true };
      }
      if (message.kind === "TIMING") return { timing, skipsInARow };
      if (message.kind === "PAUSE") return pause(message.reason || "Пауза");
      if (message.kind === "SNAPSHOT") return snapshot(message.profile);
      if (message.kind === "VALIDATE")
        return (
          current?.token === message.token &&
          state(current.profile).identity === current.identity &&
          epoch === current.epoch
        );
      if (message.kind === "FILL") return fill(message);
      if (message.kind === "SKIP") return skip(message);
      if (message.kind === "FEEDBACK_POLL") {
        reportFeedback();
        return { ok: true };
      }
      return undefined;
    };
    run().then(
      (value) => reply({ value }),
      (error) => reply({ error: error.message }),
    );
    return true;
  });
})();
