export const CYRILLIC = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
export const LATIN =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
import { THRESHOLDS } from "./thresholds.js";
export { THRESHOLDS } from "./thresholds.js";
export function decide(
  candidates,
  {
    type,
    alphabet,
    min,
    max,
    shapeConfidence = 100,
    threshold = THRESHOLDS[type],
  },
) {
  const valid = candidates.filter(
    (c) => c.text && Number.isFinite(c.confidence),
  );
  const groups = new Map();
  for (const c of valid) {
    const group = groups.get(c.text) || [];
    group.push(c);
    groups.set(c.text, group);
  }
  const ranked = [...groups]
    .map(([text, list]) => ({
      text,
      confidence: list.reduce((n, c) => n + c.confidence, 0) / list.length,
      votes: new Set(list.map((c) => c.variant)).size,
    }))
    .sort((a, b) => b.votes - a.votes || b.confidence - a.confidence);
  const best = ranked[0] || { text: "", confidence: 0, votes: 0 };
  let reason = "";
  if (!alphabet) reason = "Укажите допустимый алфавит в профиле.";
  else if (!best.text) reason = "OCR не нашёл символы.";
  else if (threshold > 100)
    reason =
      "Автозаполнение этого типа отключено: калибровка не дала надёжных ответов. Кандидат — для ручной проверки.";
  else if ([...best.text].some((c) => !alphabet.includes(c)))
    reason = "Есть символы вне допустимого алфавита.";
  else if (best.text.length < min || best.text.length > max)
    reason = `Длина ${best.text.length} вне диапазона ${min}–${max}.`;
  else if (best.votes < 2)
    reason = "Варианты обработки не согласны между собой.";
  else if (ranked[1]?.votes >= best.votes)
    reason = "Есть конкурирующие ответы с равным числом голосов.";
  else if (best.confidence < threshold)
    reason = "Недостаточная уверенность OCR.";
  else if (shapeConfidence < 85)
    reason = "Неуверенное сопоставление букв и фигур.";
  return {
    candidate: best.text,
    confidence: Math.round(best.confidence),
    accepted: !reason,
    reason:
      reason || "Варианты согласны; алфавит, длина и уверенность проверены.",
    ranked,
  };
}
// Never trim, substitute lookalikes, truncate or pad an OCR answer to meet a length.
export function cleanOCR(text) {
  return String(text || "").replace(/\s/g, "");
}
