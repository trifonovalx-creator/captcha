export function canvas(width, height) {
  const c = document.createElement("canvas");
  c.width = width;
  c.height = height;
  return c;
}
export async function loadImage(url) {
  const image = new Image();
  image.src = url;
  await image.decode();
  if (image.width * image.height > 12_000_000)
    throw Error("Изображение слишком большое (максимум 12 Мп).");
  const out = canvas(image.width, image.height);
  out.getContext("2d").drawImage(image, 0, 0);
  return out;
}
export function crop(source, box, scale = 1) {
  const x = Math.max(0, Math.round(box.x)),
    y = Math.max(0, Math.round(box.y));
  const w = Math.min(source.width - x, Math.round(box.width));
  const h = Math.min(source.height - y, Math.round(box.height));
  if (w < 1 || h < 1) throw Error("Пустая область изображения.");
  const out = canvas(Math.round(w * scale), Math.round(h * scale));
  const ctx = out.getContext("2d");
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, out.width, out.height);
  ctx.drawImage(source, x, y, w, h, 0, 0, out.width, out.height);
  return out;
}
export function transform(source, mode) {
  const out = crop(source, {
    x: 0,
    y: 0,
    width: source.width,
    height: source.height,
  });
  const ctx = out.getContext("2d", { willReadFrequently: true });
  const data = ctx.getImageData(0, 0, out.width, out.height);
  for (let i = 0; i < data.data.length; i += 4) {
    const r = data.data[i],
      g = data.data[i + 1],
      b = data.data[i + 2];
    const gray = 0.299 * r + 0.587 * g + 0.114 * b;
    let value = gray;
    if (mode === "contrast")
      value = Math.max(0, Math.min(255, (gray - 170) * 2.6 + 170));
    if (mode === "binary" || mode === "thin-lines")
      value = gray < 155 ? 0 : 255;
    if (mode === "color")
      value =
        Math.max(r, g, b) - Math.min(r, g, b) > 55 && gray < 230 ? 0 : 255;
    data.data[i] = data.data[i + 1] = data.data[i + 2] = value;
  }
  if (mode === "thin-lines") {
    // Remove only narrow, long near-horizontal runs; retain the original variant for voting.
    const original = data.data.slice();
    for (let y = 1; y < out.height - 1; y++) {
      let start = -1;
      for (let x = 0; x <= out.width; x++) {
        const dark = x < out.width && original[(y * out.width + x) * 4] === 0;
        if (dark && start < 0) start = x;
        if (!dark && start >= 0) {
          if (x - start > out.width * 0.45)
            for (let k = start; k < x; k++) {
              const up = original[((y - 1) * out.width + k) * 4],
                down = original[((y + 1) * out.width + k) * 4];
              if (up === 255 || down === 255) {
                const i = (y * out.width + k) * 4;
                data.data[i] = data.data[i + 1] = data.data[i + 2] = 255;
              }
            }
          start = -1;
        }
      }
    }
  }
  ctx.putImageData(data, 0, 0);
  return out;
}
function hull(points) {
  points.sort((a, b) => a.x - b.x || a.y - b.y);
  const cross = (a, b, c) =>
    (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  const lower = [],
    upper = [];
  for (const p of points) {
    while (lower.length > 1 && cross(lower.at(-2), lower.at(-1), p) <= 0)
      lower.pop();
    lower.push(p);
  }
  for (const p of points.toReversed()) {
    while (upper.length > 1 && cross(upper.at(-2), upper.at(-1), p) <= 0)
      upper.pop();
    upper.push(p);
  }
  return lower.slice(0, -1).concat(upper.slice(0, -1));
}
function simplifyPolygon(points, tolerance) {
  const p = points.slice();
  let changed = true;
  while (changed && p.length > 3) {
    changed = false;
    for (let i = 0; i < p.length; i++) {
      const a = p[(i + p.length - 1) % p.length],
        b = p[i],
        c = p[(i + 1) % p.length];
      const distance =
        Math.abs(
          (c.y - a.y) * b.x - (c.x - a.x) * b.y + c.x * a.y - c.y * a.x,
        ) / (Math.hypot(c.x - a.x, c.y - a.y) || 1);
      if (distance < tolerance) {
        p.splice(i, 1);
        changed = true;
        break;
      }
    }
  }
  return p;
}
export function findShapes(source) {
  const { width: w, height: h } = source;
  const pixels = source
    .getContext("2d", { willReadFrequently: true })
    .getImageData(0, 0, w, h).data;
  const mask = new Uint8Array(w * h),
    seen = new Uint8Array(w * h);
  for (let y = Math.floor(h * 0.5); y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4,
        r = pixels[i],
        g = pixels[i + 1],
        b = pixels[i + 2];
      mask[y * w + x] =
        Math.max(r, g, b) - Math.min(r, g, b) > 35 && Math.min(r, g, b) < 215
          ? 1
          : 0;
    }
  const shapes = [];
  for (let i = 0; i < mask.length; i++) {
    if (!mask[i] || seen[i]) continue;
    const queue = [i],
      boundary = [];
    seen[i] = 1;
    let x0 = w,
      y0 = h,
      x1 = 0,
      y1 = 0;
    for (let q = 0; q < queue.length; q++) {
      const pos = queue[q],
        x = pos % w,
        y = Math.floor(pos / w);
      x0 = Math.min(x0, x);
      x1 = Math.max(x1, x);
      y0 = Math.min(y0, y);
      y1 = Math.max(y1, y);
      let edge = false;
      for (const [dx, dy] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const nx = x + dx,
          ny = y + dy,
          n = ny * w + nx;
        if (nx < 0 || nx >= w || ny < 0 || ny >= h || !mask[n]) {
          edge = true;
          continue;
        }
        if (!seen[n]) {
          seen[n] = 1;
          queue.push(n);
        }
      }
      if (edge) boundary.push({ x, y });
    }
    if (queue.length < 30 || x1 - x0 < 7 || y1 - y0 < 7) continue;
    const contour = simplifyPolygon(
      hull(boundary),
      Math.max(x1 - x0, y1 - y0) * 0.065,
    );
    const area = (x1 - x0 + 1) * (y1 - y0 + 1),
      fill = queue.length / area;
    const triangle = contour.length === 3 && fill > 0.3 && fill < 0.7;
    shapes.push({
      x: x0,
      y: y0,
      width: x1 - x0 + 1,
      height: y1 - y0 + 1,
      center: (x0 + x1) / 2,
      triangle,
      contour,
      fill,
    });
  }
  return shapes.sort((a, b) => a.center - b.center);
}
export function shapeColumns(shapes, width) {
  return shapes.map((s, i) => ({
    ...s,
    left: i ? (shapes[i - 1].center + s.center) / 2 : 0,
    right:
      i < shapes.length - 1 ? (s.center + shapes[i + 1].center) / 2 : width,
  }));
}
export function overlayShapes(source, shapes) {
  const out = crop(source, {
    x: 0,
    y: 0,
    width: source.width,
    height: source.height,
  });
  const ctx = out.getContext("2d");
  ctx.lineWidth = 2;
  for (const s of shapes) {
    ctx.strokeStyle = s.triangle ? "#d02b63" : "#177565";
    ctx.beginPath();
    s.contour.forEach((p, i) =>
      i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y),
    );
    ctx.closePath();
    ctx.stroke();
    ctx.strokeStyle = "#697c8a";
    ctx.beginPath();
    ctx.moveTo(s.left, 0);
    ctx.lineTo(s.left, out.height);
    ctx.stroke();
  }
  return out;
}
// Connected components within coarse RGB groups remove small colored watermark glyphs,
// while retaining large neutral/gray characters. Saturation is not a prerequisite.
export function largeColorComponents(source, binary = true) {
  const { width: w, height: h } = source,
    ctx = source.getContext("2d", { willReadFrequently: true }),
    data = ctx.getImageData(0, 0, w, h).data;
  const labels = new Int32Array(w * h);
  labels.fill(-1);
  const seen = new Uint8Array(w * h),
    keep = new Uint8Array(w * h);
  for (let i = 0; i < w * h; i++) {
    const p = i * 4,
      r = data[p],
      g = data[p + 1],
      b = data[p + 2];
    if (Math.min(r, g, b) < 210)
      labels[i] =
        Math.floor(r / 40) * 49 + Math.floor(g / 40) * 7 + Math.floor(b / 40);
  }
  for (let i = 0; i < labels.length; i++) {
    if (labels[i] < 0 || seen[i]) continue;
    const queue = [i];
    seen[i] = 1;
    let y0 = h,
      y1 = 0;
    for (let q = 0; q < queue.length; q++) {
      const pos = queue[q],
        x = pos % w,
        y = Math.floor(pos / w);
      y0 = Math.min(y0, y);
      y1 = Math.max(y1, y);
      for (const [dx, dy] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
        [1, 1],
        [-1, 1],
        [1, -1],
        [-1, -1],
      ]) {
        const nx = x + dx,
          ny = y + dy,
          n = ny * w + nx;
        if (
          nx >= 0 &&
          nx < w &&
          ny >= 0 &&
          ny < h &&
          !seen[n] &&
          labels[n] === labels[i]
        ) {
          seen[n] = 1;
          queue.push(n);
        }
      }
    }
    if (y1 - y0 > h * 0.34 && queue.length > w * h * 0.0015)
      for (const p of queue) keep[p] = 1;
  }
  const out = canvas(w, h),
    octx = out.getContext("2d"),
    outData = octx.createImageData(w, h);
  for (let i = 0; i < w * h; i++) {
    const p = i * 4;
    for (let k = 0; k < 3; k++)
      outData.data[p + k] = keep[i] ? (binary ? 0 : data[p + k]) : 255;
    outData.data[p + 3] = 255;
  }
  octx.putImageData(outData, 0, 0);
  return out;
}
