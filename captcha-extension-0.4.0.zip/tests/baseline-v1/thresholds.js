// Selected on 4 calibration samples/type, before holdout. 101 = insufficient evidence to autofill.
export const THRESHOLDS = Object.freeze({ shapes: 92, color: 101, lines: 78 });
