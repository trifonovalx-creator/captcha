(() => {
  // src/background.js
  var key = (tabId) => `controller:${tabId}`;
  chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.id) return;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      const saved = await chrome.storage.session.get(key(tab.id)), existing = saved[key(tab.id)];
      if (existing) {
        try {
          await chrome.windows.update(existing, { focused: true });
          await chrome.runtime.sendMessage({ kind: "ACTIVATE_CONTROLLER", tabId: tab.id }).catch(() => {
          });
          return;
        } catch {
          await chrome.storage.session.remove(key(tab.id));
        }
      }
      const window = await chrome.windows.create({
        url: chrome.runtime.getURL(`controller.html?tab=${tab.id}`),
        type: "popup",
        width: 600,
        height: 830,
        focused: false
      });
      await chrome.storage.session.set({ [key(tab.id)]: window.id });
      await chrome.action.setBadgeText({ tabId: tab.id, text: "\u2026" });
    } catch (error) {
      await chrome.action.setBadgeText({ tabId: tab.id, text: "!" });
      await chrome.action.setTitle({
        tabId: tab.id,
        title: `\u041D\u0435\u043B\u044C\u0437\u044F \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C\u0441\u044F: ${error.message}`
      });
    }
  });
  chrome.windows.onRemoved.addListener(async (windowId) => {
    const entries = await chrome.storage.session.get(null);
    for (const [name, id] of Object.entries(entries))
      if (name.startsWith("controller:") && id === windowId) {
        const tabId = Number(name.slice("controller:".length));
        await chrome.storage.session.remove(name);
        await chrome.tabs.sendMessage(tabId, { kind: "STOP" }).catch(() => {
        });
        await chrome.action.setBadgeText({ tabId, text: "" }).catch(() => {
        });
      }
  });
  chrome.tabs.onRemoved.addListener(
    (tabId) => chrome.storage.session.remove(key(tabId))
  );
})();
