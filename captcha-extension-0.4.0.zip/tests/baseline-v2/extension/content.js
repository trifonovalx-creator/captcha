(() => {
  // src/content.js
  (() => {
    if (globalThis.__captchaMVP) return;
    let observer, timer, epoch = 0, active = false, lastProfile, sequence = 0;
    let current = null, pendingFeedback = null;
    const skippedChallenges = /* @__PURE__ */ new Set();
    const ids = /* @__PURE__ */ new WeakMap();
    let nextId = 1;
    const id = (el) => {
      if (!ids.has(el)) ids.set(el, nextId++);
      return ids.get(el);
    };
    function unique(root, selector, label, optional = false) {
      if (!selector && optional) return null;
      if (!selector) throw Error(`\u041D\u0435 \u0437\u0430\u0434\u0430\u043D \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440: ${label}.`);
      let list;
      try {
        list = root.querySelectorAll(selector);
      } catch {
        throw Error(`\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440: ${label}.`);
      }
      if (list.length !== 1)
        throw Error(
          `${label}: \u043D\u0430\u0439\u0434\u0435\u043D\u043E ${list.length} \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432; \u043D\u0443\u0436\u0435\u043D \u0440\u043E\u0432\u043D\u043E \u043E\u0434\u0438\u043D.`
        );
      return list[0];
    }
    function locate(profile) {
      const root = profile.container ? unique(document, profile.container, "\u041A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440") : document;
      const image = unique(root, profile.image, "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435");
      if (!(image instanceof HTMLImageElement || image instanceof HTMLCanvasElement))
        throw Error("\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C <img> \u0438\u043B\u0438 <canvas>.");
      const input = unique(root, profile.input, "\u041F\u043E\u043B\u0435 \u043E\u0442\u0432\u0435\u0442\u0430");
      if (!(input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement) || input.disabled || input.readOnly || input instanceof HTMLInputElement && !["text", "search", "tel", "url", "email", "password"].includes(
        input.type
      ))
        throw Error("\u041F\u043E\u043B\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E \u0434\u043B\u044F \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u043E\u0433\u043E \u0432\u0432\u043E\u0434\u0430.");
      const instruction = unique(
        root,
        profile.instruction,
        "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u044F"
      ).textContent.trim();
      const bound = (selector, native, label) => {
        const element = unique(root, selector, label, true), text = element ? element.getAttribute("value") || element.textContent : native;
        if (text === null || text === void 0 || text === "")
          throw Error(`\u041D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 ${label}.`);
        const matches = String(text).match(/\d+/g);
        if (matches?.length !== 1)
          throw Error(`\u041D\u0435\u043E\u0434\u043D\u043E\u0437\u043D\u0430\u0447\u043D\u043E\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 ${label}.`);
        return Number(matches[0]);
      };
      const min = bound(
        profile.minSelector,
        input.getAttribute("minlength"),
        "min"
      );
      const max = bound(
        profile.maxSelector,
        input.getAttribute("maxlength"),
        "max"
      );
      if (min < 1 || max < min || max > 64)
        throw Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D \u0434\u043B\u0438\u043D\u044B (1\u201364).");
      return { image, input, instruction, min, max };
    }
    const hash = (text) => {
      let h = 2166136261;
      for (let i = 0; i < text.length; i++) {
        h ^= text.charCodeAt(i);
        h = Math.imul(h, 16777619);
      }
      return (h >>> 0).toString(16);
    };
    function pixels(image) {
      if (image instanceof HTMLCanvasElement) return image.toDataURL("image/png");
      if (!image.complete || !image.naturalWidth)
        throw Error("\u041A\u0430\u0440\u0442\u0438\u043D\u043A\u0430 \u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430.");
      if (image.naturalWidth * image.naturalHeight > 12e6)
        throw Error("\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435.");
      const c = document.createElement("canvas");
      c.width = image.naturalWidth;
      c.height = image.naturalHeight;
      c.getContext("2d").drawImage(image, 0, 0);
      return c.toDataURL("image/png");
    }
    function state(profile) {
      const found = locate(profile);
      let imageData = null;
      try {
        imageData = pixels(found.image);
      } catch (error) {
        if (error.name !== "SecurityError") throw error;
      }
      const rect = found.image.getBoundingClientRect();
      const imageStyle = getComputedStyle(found.image);
      if (!imageData && (imageStyle.objectFit === "contain" || imageStyle.objectFit === "cover" || imageStyle.transform !== "none"))
        throw Error(
          "\u0417\u0430\u0445\u0432\u0430\u0442: object-fit/transform \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u0440\u043E\u0444\u0438\u043B\u044F \u043E\u0431\u0440\u0435\u0437\u043A\u0438."
        );
      const identity = JSON.stringify([
        id(found.image),
        id(found.input),
        found.image.currentSrc || found.image.src || "",
        hash(imageData || ""),
        imageData ? null : [rect.x, rect.y, rect.width, rect.height, innerWidth, innerHeight],
        found.instruction,
        found.min,
        found.max
      ]);
      return {
        ...found,
        challenge: JSON.stringify([
          found.image.currentSrc || found.image.src || "",
          hash(imageData || ""),
          found.instruction
        ]),
        imageData,
        key: hash(identity),
        identity,
        rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
        viewport: { width: innerWidth, height: innerHeight },
        epoch
      };
    }
    async function snapshot(profile) {
      const s = state(profile);
      const token = `${++sequence}:${s.key}:${epoch}`;
      current = { ...s, token, profile };
      return {
        token,
        key: s.key,
        challenge: s.challenge,
        epoch: s.epoch,
        image: s.imageData,
        instruction: s.instruction,
        min: s.min,
        max: s.max,
        rect: s.rect,
        viewport: s.viewport,
        manual: !!s.input.value,
        fallback: !s.imageData
      };
    }
    function announce() {
      if (!active) return;
      chrome.runtime.sendMessage({ kind: "CAPTCHA_CHANGED" }).catch(() => {
      });
    }
    function invalidated() {
      epoch++;
      clearTimeout(timer);
      timer = setTimeout(announce, 220);
    }
    function observe(profile) {
      stop();
      active = true;
      lastProfile = profile;
      observer = new MutationObserver((records) => {
        let root;
        try {
          root = lastProfile.container ? document.querySelector(lastProfile.container) : document.documentElement;
        } catch {
          invalidated();
          return;
        }
        if (!root || records.some(
          (r) => root === r.target || root.contains(r.target) || [...r.removedNodes || []].some(
            (n) => n === root || n.contains?.(root)
          )
        ))
          invalidated();
      });
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: [
          "src",
          "srcset",
          "width",
          "height",
          "minlength",
          "maxlength",
          "disabled",
          "readonly",
          "value",
          "class",
          "style"
        ]
      });
      document.addEventListener("load", invalidated, true);
      document.addEventListener("input", onInput, true);
      for (const name of ["beforeinput", "compositionstart", "paste"])
        document.addEventListener(name, onInput, true);
      document.addEventListener("keydown", onKey, true);
      globalThis.__captchaMVP.poll = setInterval(() => {
        if (!active) return;
        reportFeedback();
        try {
          const s = state(lastProfile);
          if (current && s.identity !== current.identity) invalidated();
          else if (current && !s.imageData) announce();
        } catch {
          invalidated();
        }
      }, 700);
    }
    function onKey(event) {
      if (event.key.length === 1 || event.key === "Backspace" || event.key === "Delete")
        onInput(event);
    }
    function onInput(event) {
      if (current?.input === event.target) invalidated();
    }
    function stop() {
      active = false;
      epoch++;
      observer?.disconnect();
      clearTimeout(timer);
      clearInterval(globalThis.__captchaMVP?.poll);
      document.removeEventListener("load", invalidated, true);
      document.removeEventListener("input", onInput, true);
      for (const name of ["beforeinput", "compositionstart", "paste"])
        document.removeEventListener(name, onInput, true);
      document.removeEventListener("keydown", onKey, true);
      current = null;
    }
    async function fill(message) {
      if (!active || !current || message.token !== current.token)
        return { ok: false, reason: "\u0417\u0430\u0434\u0430\u0447\u0430 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430 \u0438\u043B\u0438 \u0443\u0441\u0442\u0430\u0440\u0435\u043B\u0430." };
      const saved = current, fresh = state(saved.profile);
      if (fresh.identity !== saved.identity || fresh.imageData !== saved.imageData || fresh.epoch !== saved.epoch || fresh.image !== saved.image || fresh.input !== saved.input)
        return {
          ok: false,
          reason: "\u041A\u0430\u043F\u0447\u0430 \u0438\u043B\u0438 \u043F\u043E\u043B\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C; \u043F\u043E\u0437\u0434\u043D\u0438\u0439 \u043E\u0442\u0432\u0435\u0442 \u043E\u0442\u0431\u0440\u043E\u0448\u0435\u043D."
        };
      if (fresh.input.value)
        return { ok: false, reason: "\u0412 \u043F\u043E\u043B\u0435 \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u0442\u0435\u043A\u0441\u0442; \u043E\u043D \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D." };
      if (message.value.length < fresh.min || message.value.length > fresh.max)
        return { ok: false, reason: "\u0418\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u0434\u043B\u0438\u043D\u044B." };
      const prototype = fresh.input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(prototype, "value").set.call(
        fresh.input,
        message.value
      );
      const feedbackBefore = feedbackText(saved.profile);
      fresh.input.dispatchEvent(new Event("input", { bubbles: true }));
      await new Promise((resolve) => setTimeout(resolve, 150));
      let check;
      try {
        check = state(saved.profile);
      } catch {
        return { ok: false, reason: "\u0421\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u043F\u043E\u0441\u043B\u0435 input." };
      }
      if (check.identity !== saved.identity || check.input !== saved.input)
        return { ok: false, reason: "\u041A\u0430\u043F\u0447\u0430 \u0441\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u043F\u043E\u0441\u043B\u0435 input." };
      if (check.input.value === message.value)
        pendingFeedback = {
          token: message.token,
          profile: saved.profile,
          before: feedbackBefore
        };
      return check.input.value === message.value ? { ok: true } : { ok: false, reason: "\u0421\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u043B\u0430 \u0432\u0432\u0435\u0434\u0451\u043D\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435." };
    }
    function feedbackText(profile) {
      if (!profile.feedbackSelector) return null;
      try {
        const root = profile.container ? unique(document, profile.container, "\u041A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440") : document;
        return unique(
          root,
          profile.feedbackSelector,
          "\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C"
        ).textContent.trim();
      } catch {
        return null;
      }
    }
    function reportFeedback() {
      if (!pendingFeedback) return;
      const p = pendingFeedback, text = feedbackText(p.profile);
      if (text === null || text === p.before) return;
      const outcome = text === p.profile.feedbackSuccess ? "correct" : text === p.profile.feedbackFailure ? "incorrect" : null;
      if (outcome) {
        pendingFeedback = null;
        chrome.runtime.sendMessage({ kind: "CAPTCHA_FEEDBACK", token: p.token, outcome }).catch(() => {
        });
      }
    }
    function skip(message) {
      if (!active || !current || message.token !== current.token)
        return { clicked: false, reason: "\u0417\u0430\u0434\u0430\u0447\u0430 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0430 \u0438\u043B\u0438 \u0443\u0441\u0442\u0430\u0440\u0435\u043B\u0430." };
      const saved = current, fresh = state(saved.profile);
      if (fresh.identity !== saved.identity || fresh.imageData !== saved.imageData || fresh.epoch !== saved.epoch || fresh.input !== saved.input)
        return {
          clicked: false,
          reason: "\u041A\u0430\u043F\u0447\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u043D\u0430\u0447\u0430\u043B \u0432\u0432\u043E\u0434; \u043F\u0440\u043E\u043F\u0443\u0441\u043A \u043E\u0442\u043C\u0435\u043D\u0451\u043D."
        };
      if (fresh.input.value)
        return {
          clicked: false,
          reason: "\u0412 \u043F\u043E\u043B\u0435 \u0435\u0441\u0442\u044C \u0440\u0443\u0447\u043D\u043E\u0439 \u0442\u0435\u043A\u0441\u0442; \u043F\u0440\u043E\u043F\u0443\u0441\u043A \u043E\u0442\u043C\u0435\u043D\u0451\u043D."
        };
      if (skippedChallenges.has(fresh.challenge))
        return {
          clicked: false,
          reason: "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0443\u0436\u0435 \u043D\u0430\u0436\u0430\u0442\u043E \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u043A\u0430\u043F\u0447\u0438. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0435 \u043D\u0430\u0436\u0430\u0442\u0438\u0435 \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u043E."
        };
      const root = saved.profile.container ? unique(document, saved.profile.container, "\u041A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440") : document;
      const button = unique(
        root,
        saved.profile.skipSelector,
        "\u041A\u043D\u043E\u043F\u043A\u0430 \u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C"
      );
      if (!(button instanceof HTMLElement) || !button.matches(
        "button,input[type=button],input[type=submit],[role=button],a[href]"
      ) || typeof button.click !== "function")
        return {
          clicked: false,
          reason: "\u042D\u043B\u0435\u043C\u0435\u043D\u0442 \u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043A\u043D\u043E\u043F\u043A\u043E\u0439."
        };
      if (button.matches(":disabled") || button.getAttribute("aria-disabled") === "true" || button.getClientRects().length === 0 || getComputedStyle(button).visibility === "hidden" || button.closest("[inert]"))
        return {
          clicked: false,
          reason: "\u041A\u043D\u043E\u043F\u043A\u0430 \u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u0430 \u0438\u043B\u0438 \u0441\u043A\u0440\u044B\u0442\u0430."
        };
      skippedChallenges.add(fresh.challenge);
      button.click();
      return { clicked: true, challenge: fresh.challenge };
    }
    setInterval(reportFeedback, 500);
    globalThis.__captchaMVP = { stop };
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (sender.id !== chrome.runtime.id) return;
      const run = async () => {
        if (message.kind === "START") {
          observe(message.profile);
          return { ok: true };
        }
        if (message.kind === "STOP") {
          stop();
          return { ok: true };
        }
        if (message.kind === "SNAPSHOT") return snapshot(message.profile);
        if (message.kind === "VALIDATE")
          return current?.token === message.token && state(current.profile).identity === current.identity && epoch === current.epoch;
        if (message.kind === "FILL") return fill(message);
        if (message.kind === "SKIP") return skip(message);
        if (message.kind === "FEEDBACK_POLL") {
          reportFeedback();
          return { ok: true };
        }
        return void 0;
      };
      run().then(
        (value) => reply({ value }),
        (error) => reply({ error: error.message })
      );
      return true;
    });
  })();
})();
