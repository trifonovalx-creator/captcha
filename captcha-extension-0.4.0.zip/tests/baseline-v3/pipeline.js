import { recognize as tesseract, terminateWorker } from "./ocr.js";
import { modelRecognize, terminateModels } from "./model-client.js";
import {
  loadImage,
  crop,
  findShapes,
  shapeColumns,
  transform,
  normalizeInk,
} from "./image.js";
import { CYRILLIC } from "./decision.js";
export function terminateAll() {
  terminateWorker();
  terminateModels();
}
function valid(text, task) {
  return (
    !!text &&
    text.length >= task.min &&
    text.length <= task.max &&
    [...text].every((c) => task.alphabet.includes(c))
  );
}
function resultFor(task, list, base = {}) {
  const grouped = new Map();
  for (const c of list) {
    if (!grouped.has(c.text)) grouped.set(c.text, []);
    grouped.get(c.text).push(c);
  }
  const ranked = [...grouped]
    .map(([text, c]) => ({
      text,
      confidence: Math.min(...c.map((v) => v.confidence)),
      votes: c.length,
    }))
    .sort(
      (a, b) =>
        Number(valid(b.text, task)) - Number(valid(a.text, task)) ||
        b.votes - a.votes ||
        b.confidence - a.confidence,
    );
  const best = ranked[0] || { text: "", confidence: 0, votes: 0 };
  const threshold = task.type === "shapes" ? 97 : 98;
  const accepted =
    valid(best.text, task) &&
    best.confidence >= threshold &&
    best.votes >= 2 &&
    !ranked.some(
      (r) => r.text !== best.text && valid(r.text, task) && r.confidence >= 95,
    );
  return {
    ...base,
    candidate: best.text,
    confidence: best.confidence,
    accepted,
    reason: accepted
      ? "Локальные модели согласны; алфавит, длина и порог проверены."
      : "Локальные модели: недостаточно уверенного согласия.",
    ranked,
    candidates: [
      ...(base.candidates || []).filter(
        (c) =>
          !list.some((l) => l.engine === c.engine && l.variant === c.variant),
      ),
      ...list,
    ],
    debug: base.debug || [],
    modelPath: true,
  };
}
export async function recognize(task, options = {}) {
  const { signal, progress = () => {} } = options,
    deadline = options.deadline || Date.now() + 28000;
  signal?.throwIfAborted();
  const alphabet = task.type === "shapes" ? CYRILLIC : task.alphabet;
  task = { ...task, alphabet };
  if (task.type === "shapes") {
    const base = await tesseract(task, options);
    if (base.accepted || deadline - Date.now() < 1700)
      return { ...base, path: "v2" };
    const source = await loadImage(task.image),
      shapes = shapeColumns(findShapes(source), source.width),
      selected = shapes.filter((s) => s.triangle);
    if (!selected.length) return base;
    const top = Math.min(...shapes.map((s) => s.y)) - 3,
      list = [];
    for (const variant of ["original", "binary"]) {
      let text = "",
        confidence = 100;
      for (const s of selected) {
        signal?.throwIfAborted();
        if (Date.now() >= deadline) throw Error("Бюджет модели истёк.");
        let image = crop(source, {
          x: s.left,
          y: 0,
          width: s.right - s.left,
          height: top,
        });
        if (variant === "binary") image = transform(image, "binary");
        const r = await modelRecognize(
          "easyocr-cyrillic",
          image.toDataURL(),
          alphabet,
          signal,
        );
        text += r.text;
        confidence = Math.min(confidence, r.confidence);
      }
      list.push({
        text,
        confidence,
        variant: "easyocr-" + variant,
        engine: "EasyOCR",
      });
    }
    const result = resultFor(task, list, base);
    return result.accepted
      ? { ...result, path: "v2→EasyOCR" }
      : {
          ...base,
          alternativesModels: list,
          candidates: [...base.candidates, ...list],
          path: "v2→EasyOCR refused",
        };
  }
  const source = await loadImage(task.image),
    b = task.crop || {},
    area = crop(source, {
      x: source.width * (b.left || 0),
      y: source.height * (b.top || 0),
      width: source.width * (1 - (b.left || 0) - (b.right || 0)),
      height: source.height * (1 - (b.top || 0) - (b.bottom || 0)),
    });
  const isCyrillic = /[А-Яа-яЁё]/.test(alphabet),
    name = isCyrillic ? "easyocr-cyrillic" : "helper",
    list = [];
  for (const variant of ["original", "contrast"]) {
    signal?.throwIfAborted();
    const image = variant === "original" ? area : transform(area, "contrast");
    const r = await modelRecognize(name, image.toDataURL(), alphabet, signal);
    list.push({ ...r, variant: name + "-" + variant });
  }
  let result = resultFor(task, list, {
    debug: [{ name: "Вход локальной модели", image: area.toDataURL() }],
  });
  if (result.accepted) return { ...result, path: name };
  if (deadline - Date.now() > 2000) {
    const alternate = name === "helper" ? "easyocr-cyrillic" : null;
    if (alternate) {
      const r = await modelRecognize(
        alternate,
        area.toDataURL(),
        alphabet,
        signal,
      );
      list.push({ ...r, variant: "easyocr-fallback" });
      result = resultFor(task, list, result);
    }
  }
  return { ...result, path: name + "→fallback" };
}
