import test from 'node:test';
import assert from 'node:assert/strict';
import {decideColor} from '../src/color-decision.js';
import {decodeCTC} from '../src/ctc.js';
const task={min:5,max:5,alphabet:'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'};
const c=(text,confidence,variant)=>({text,confidence,variant});
test('weak fallback does not dilute two strong Helper views',()=>{
 const r=decideColor(task,[c('A9U5Y',97.8,'helper-original'),c('A9U5Y',96.9,'helper-contrast'),c('A9U5Y',93.4,'easyocr-fallback')]);
 assert.equal(r.accepted,true);assert.equal(r.confidence,96.9);
});
test('confident l/1 agreement is refused when original evidence is weak',()=>{
 const r=decideColor(task,[c('2g1AS',91.54,'helper-original'),c('2g1AS',97.68,'helper-contrast'),c('2g1AS',93.67,'helper-gray'),c('2g1AS',96.21,'easyocr-fallback')]);
 assert.equal(r.accepted,false);
});
test('strong case competitor still forces abstention',()=>{
 const r=decideColor(task,[c('vWt8f',96,'helper-original'),c('vWt8f',97,'helper-contrast'),c('VWt8f',99.9,'easyocr-fallback')]);
 assert.equal(r.accepted,false);assert.match(r.reason,/VWt8f/);
});
test('duplicate variant cannot supply a second view; alphabet and length are mandatory',()=>{
 assert.equal(decideColor(task,[c('abc12',100,'helper-original'),c('abc12',100,'helper-original')]).accepted,false);
 assert.equal(decideColor(task,[c('abЯ12',100,'helper-original'),c('abЯ12',100,'helper-contrast')]).accepted,false);
});
test('per-symbol telemetry uses CTC run peaks and does not merge repeated characters across blank',()=>{
 const r=decodeCTC(new Float32Array([.1,.9,.02,.98,.99,.01,.2,.8]),[1,4,2],['','x'],'x');
 assert.equal(r.text,'xx');assert.equal(r.symbols.length,2);
 assert.deepEqual(r.symbols.map(s=>[s.startStep,s.endStep,s.peakStep]),[[0,1,1],[3,3,3]]);
 assert.ok(Math.abs(r.symbols[0].confidence-98)<.001);
 assert.ok(Math.abs(r.confidence-80)<.001);
});
