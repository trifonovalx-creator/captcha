// Frozen before calibration: disjoint text/seed sets. Synthetic, never trainer data.
export const colorV4Samples = [];
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
for (const split of ['tune4', 'holdout4']) {
  for (let i = 0; i < 32; i++) {
    let state = (split === 'tune4' ? 0x35191 : 0x891a7) + i * 10007;
    const random = () => ((state = (Math.imul(state, 1664525) + 1013904223) >>> 0) / 2 ** 32);
    let text = '';
    for (let j = 0; j < 5; j++) text += alphabet[Math.floor(random() * alphabet.length)];
    colorV4Samples.push({
      id: `${split}-color-${i + 1}`, split, type: 'color', source: 'synthetic',
      expected: text, text, alphabet, min: 5, max: 5,
      font: ['DejaVu Sans', 'DejaVu Serif', 'DejaVu Sans Mono', 'Liberation Sans', 'Liberation Serif', 'Liberation Mono', 'C059', 'Bitstream Charter'][i % 8],
      grayIndex: i % 5, grayValue: [95, 120, 150, 175][Math.floor(i / 8)],
      angle: (random() - .5) * .16, seed: state, noise: i % 4,
      watermark: ['verify.local', 'sample.net', 'test.site', 'demo.local'][i % 4],
      watermarkColor: ['#a2b92a', '#c1849d', '#75a9b8', '#b39758'][Math.floor(i / 8)],
      watermarkY: [55, 66, 73, 61][i % 4], watermarkAngle: [-.24, .13, -.16, -.31][i % 4],
      crop: {top: .15, bottom: .16, left: 0, right: 0},
      file: `tests/fixtures/v4/${split}-color-${i + 1}.png`,
    });
  }
}
export function renderColorV4(s) {
  const c = document.createElement('canvas'); c.width = 330; c.height = 110;
  const ctx = c.getContext('2d'); ctx.fillStyle = '#f7f7f4'; ctx.fillRect(0,0,330,110);
  ctx.font='10px monospace';ctx.fillStyle='#62676a';ctx.fillText('Synthetic / color diagnostic',6,12);ctx.fillText('Held labels; no real data',6,106);
  const colors=['#b56d40','#507fc4','#499e79','#8664b6','#bf576a','#9e8c31'];
  ctx.textAlign='center';
  [...s.text].forEach((ch,i)=>{ctx.save();ctx.translate(45+60*i,81);ctx.rotate(s.angle*(i%2?1:-1));ctx.font=`bold 55px "${s.font}"`;ctx.fillStyle=i===s.grayIndex?`rgb(${s.grayValue},${s.grayValue},${s.grayValue})`:colors[(i+s.seed)%6];ctx.fillText(ch,0,0);ctx.restore();});
  ctx.save();ctx.translate(158,s.watermarkY);ctx.rotate(s.watermarkAngle);ctx.font='italic 15px "Liberation Sans"';ctx.fillStyle=s.watermarkColor;ctx.fillText(s.watermark,0,0);ctx.restore();
  for(let k=0;k<s.noise*30;k++){ctx.fillStyle='#c6cac4';ctx.fillRect((k*73+s.seed*17)%330,(k*43+s.seed*11)%95,1,1);}
  return c.toDataURL();
}
