import test from "node:test";
import assert from "node:assert/strict";
import { decide, cleanOCR, CYRILLIC, LATIN } from "../src/decision.js";
const options = {
  type: "color",
  min: 5,
  max: 5,
  alphabet: LATIN,
  threshold: 86,
};
const votes = (text, confidence = 95) =>
  ["original", "contrast"].map((variant) => ({ text, confidence, variant }));
test("two strong matching variants permit case-sensitive answer", () => {
  const d = decide(votes("kTyY3"), options);
  assert.equal(d.accepted, true);
  assert.equal(d.candidate, "kTyY3");
});
test("length alone never permits a candidate", () =>
  assert.equal(
    decide([{ text: "abcDE", confidence: 99, variant: "original" }], options)
      .accepted,
    false,
  ));
test("no truncating, padding or case substitutions", () => {
  assert.equal(decide(votes("abcDEF"), options).candidate, "abcDEF");
  assert.equal(decide(votes("abcDEF"), options).accepted, false);
  assert.equal(cleanOCR(" aB 3\n"), "aB3");
});
test("ties, low confidence and outside-alphabet candidates refuse", () => {
  assert.equal(
    decide([...votes("abcDE"), ...votes("abcdE")], options).accepted,
    false,
  );
  assert.equal(decide(votes("abcDE", 60), options).accepted, false);
  assert.equal(decide(votes("аbcDE"), options).accepted, false); // first letter is Cyrillic
});
test("Cyrillic and figure confidence are independently checked", () => {
  const o = {
    type: "shapes",
    min: 3,
    max: 4,
    alphabet: CYRILLIC,
    shapeConfidence: 95,
  };
  assert.equal(decide(votes("КЛЧ"), o).accepted, true);
  assert.equal(
    decide(votes("КЛЧ"), { ...o, shapeConfidence: 60 }).accepted,
    false,
  );
});

test("uncalibrated type cannot autofill even at confidence 100", () =>
  assert.equal(
    decide(votes("abcDE", 100), { ...options, threshold: 101 }).accepted,
    false,
  ));

test("a complete admissible answer outranks frequent truncated strings without rewriting", () => {
  const d = decide(
    [
      { text: "ЛФ", confidence: 0, variant: "a" },
      { text: "ЛФ", confidence: 0, variant: "b" },
      { text: "ДЛФ", confidence: 94, variant: "c" },
      { text: "ДЛФ", confidence: 93, variant: "d" },
    ],
    { type: "shapes", alphabet: CYRILLIC, min: 3, max: 4, threshold: 85 },
  );
  assert.equal(d.candidate, "ДЛФ");
  assert.equal(d.accepted, true);
});
test("strong competing answer refuses even with fewer votes", () => {
  const d = decide(
    [...votes("ЛЛФ", 97), { text: "ДЛФ", confidence: 92, variant: "raw" }],
    { type: "shapes", alphabet: CYRILLIC, min: 3, max: 4, threshold: 85 },
  );
  assert.equal(d.accepted, false);
  assert.match(d.reason, /конкурирующий/);
});
test("segmentation modes of one representation do not produce two independent votes", () => {
  const d = decide(
    [
      { text: "abcDE", confidence: 99, variant: "tight-line" },
      { text: "abcDE", confidence: 99, variant: "tight-raw" },
    ],
    options,
  );
  assert.equal(d.accepted, false);
});
test("weak extra representation cannot dilute two strong agreeing sources", () => {
  const d = decide(
    [...votes("abcDE", 95), { text: "abcDE", confidence: 1, variant: "weak" }],
    options,
  );
  assert.equal(d.accepted, true);
  assert.equal(d.confidence, 95);
});

test("a weak corroborator cannot conceal a strong conflicting single candidate", () => {
  const d = decide(
    [
      { text: "ЖЧЛ", confidence: 97, variant: "a" },
      { text: "ЖЧЛ", confidence: 97, variant: "b" },
      { text: "ЖЧЛ", confidence: 95, variant: "e" },
      { text: "ЖЧД", confidence: 91, variant: "c" },
      { text: "ЖЧД", confidence: 17, variant: "d" },
    ],
    { type: "shapes", alphabet: CYRILLIC, min: 3, max: 4, threshold: 85 },
  );
  assert.equal(d.accepted, false);
  assert.match(d.reason, /сильный конкурирующий/);
});
