import test from "node:test";
import assert from "node:assert/strict";
import { recognize } from "../src/ocr.js";
test("replaceable per-type engine works without browser DOM; cannot bypass final decision", async () => {
  let called = false;
  const result = await recognize(
    { type: "color", image: "not-a-page", alphabet: "Ab3Qx", min: 5, max: 5 },
    {
      engines: {
        color: async (task) => {
          called = true;
          assert.equal(task.image, "not-a-page");
          return {
            accepted: true,
            candidates: [
              { variant: "a", text: "Ab3Qx", confidence: 100 },
              { variant: "b", text: "Ab3Qx", confidence: 100 },
            ],
            debug: [],
          };
        },
      },
    },
  );
  assert.equal(called, true);
  assert.equal(result.candidate, "Ab3Qx");
  assert.equal(result.accepted, false); // color was not successfully calibrated
});
