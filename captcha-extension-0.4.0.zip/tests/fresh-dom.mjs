import { readFile } from "node:fs/promises";
import assert from "node:assert/strict";
import { freshSamples } from "./fresh-fixtures.js";
export async function testFreshDOM({
  demo,
  controller,
  report,
  message,
  profileConfig,
}) {
  await controller.locator("#stop").click();
  await controller.locator("#settings").evaluate((d) => (d.open = true));
  await controller.locator("#auto").uncheck();
  await controller.locator("#skip-low").check();
  await controller.locator("#selector-feedbackSelector").fill("#feedback");
  await controller
    .locator("#selector-feedbackSuccess")
    .fill("Верно. Ответ полностью совпал с эталоном.");
  await controller
    .locator("#selector-feedbackFailure")
    .fill("Ответ отличается от эталона. Проверьте символы и регистр.");
  report.freshDOM = [];
  report.baselineDOM = [];
  const baseline = JSON.parse(
    await readFile("reports/iteration2/baseline-audit/results.json"),
  );
  for (const sample of freshSamples.filter((s) => s.split === "audit")) {
    const image =
      "data:image/png;base64," +
      (await readFile(`tests/fixtures/fresh/${sample.id}.png`)).toString(
        "base64",
      );
    await demo.evaluate(
      async ({ sample, image }) => {
        Demo.selectSample(sample.type + "-1");
        const img = new Image();
        img.src = image;
        await img.decode();
        const c = document.querySelector("canvas");
        c.width = img.width;
        c.height = img.height;
        c.getContext("2d").drawImage(img, 0, 0);
        document.querySelector("#truth").textContent = sample.expected;
        document.querySelector("#sample-id").textContent = sample.id;
      },
      { sample, image },
    );
    await controller.locator("#type").selectOption(sample.type);
    for (const key of ["top", "bottom", "left", "right"])
      await controller.locator("#crop-" + key).fill(String(sample.crop[key]));
    const old = baseline.samples.find((s) => s.id === sample.id);
    if (old.accepted) {
      await message("START", { profile: profileConfig });
      const snap = await message("SNAPSHOT", { profile: profileConfig });
      const filled = await message("FILL", {
        token: snap.token,
        value: old.candidate,
      });
      assert.equal(filled.ok, true);
      const value = await demo.locator("#answer").inputValue();
      report.baselineDOM.push({
        id: sample.id,
        correct: value === sample.expected,
        incorrect: value !== sample.expected,
        declined: false,
      });
      await message("STOP");
      await demo.locator("#answer").evaluate((e) => (e.value = ""));
    } else
      report.baselineDOM.push({
        id: sample.id,
        correct: false,
        incorrect: false,
        declined: true,
      });
    const before = await controller.evaluate(() => ({ ...CaptchaLab.stats }));
    await controller.locator("#start").click();
    await controller.waitForFunction(
      (prev) =>
        CaptchaLab.stats.fills > prev.fills ||
        CaptchaLab.stats.skips > prev.skips ||
        /Техническая ошибка|Пропуск остановлен/.test(
          document.querySelector("#status").textContent,
        ),
      before,
      { timeout: 120000 },
    );
    const after = await controller.evaluate(() => ({ ...CaptchaLab.stats })),
      result = await controller.evaluate(() => ({
        candidate: CaptchaLab.lastResult.candidate,
        confidence: CaptchaLab.lastResult.confidence,
        reason: CaptchaLab.lastResult.reason,
      }));
    if (after.fills === before.fills && after.skips === before.skips)
      throw Error(await controller.locator("#status").textContent());
    const filled = after.fills > before.fills,
      value = await demo.locator("#answer").inputValue(),
      correct = filled && value === sample.expected,
      incorrect = filled && !correct,
      skipped = after.skips > before.skips;
    if (filled) {
      await demo.locator("#submit").click();
      await controller.waitForFunction(
        (prev) =>
          CaptchaLab.stats.correct + CaptchaLab.stats.incorrect >
          prev.correct + prev.incorrect,
        before,
      );
    }
    report.freshDOM.push({
      id: sample.id,
      type: sample.type,
      source: "synthetic",
      expected: sample.expected,
      ...result,
      value,
      correct,
      incorrect,
      skipped,
    });
    console.log(
      "DOM",
      sample.id,
      result.candidate,
      correct ? "CORRECT" : incorrect ? "INCORRECT" : "SKIP",
    );
  }
  report.freshUtility = {};
  for (const type of ["shapes", "color", "lines"]) {
    const rows = report.freshDOM.filter((s) => s.type === type),
      correct = rows.filter((s) => s.correct).length,
      incorrect = rows.filter((s) => s.incorrect).length,
      skipped = rows.filter((s) => s.skipped).length;
    report.freshUtility[type] = {
      n: rows.length,
      bestCorrect: rows.filter((s) => s.candidate === s.expected).length,
      correct,
      incorrect,
      skipped,
      allSkipped: skipped === rows.length,
      useful: correct > 0 && incorrect === 0,
    };
  }
  assert.ok(
    report.freshUtility.shapes.correct > 0,
    "skipping all shape tasks fails usefulness",
  );
  // Every type reports usefulness separately. Manual-only types are explicit failures, not hidden passes.
  report.checks.push(
    "36 final audit PNGs through actual extension: filled values, confirmed skips, manual site feedback; all-skipped type marked NOT useful",
  );
  await controller.locator("#skip-low").uncheck();
  await controller.locator("#type").selectOption("auto");
  for (const key of ["top", "bottom", "left", "right"])
    await controller.locator("#crop-" + key).fill("0");
}
