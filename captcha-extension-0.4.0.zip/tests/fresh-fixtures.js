// Frozen before v2 OCR changes. New strings, fonts, shape colors, slope and noise.
export const freshSamples = [];
const fonts = ["Arial", "Georgia", "Verdana", "Courier New"];
const shapeTexts = [
  "МЖКЦФЛЧД",
  "ФЧКМЫДЮЯ",
  "ЛРБГШЖЯЦ",
  "ЮКЖРЛЧФЫ",
  "ЩЛШЧГЮЯД",
  "БЦЛРЖКФЧ",
  "ЦКЯЛДРШЖ",
  "ЯКМЮЧЦФЛ",
  "ШЖДБЦЛЯК",
  "ДЧЮЛШЖФК",
  "КЦФЯЛЖДЧ",
  "ЧЮКЩФЛРЯ",
  "ЖКЦФЯДЛШ",
  "ЛДЖЧФЮКЯ",
  "КЖДФЦЯЛЧ",
  "ФЯКЛЮЖЦД",
  "ДЛЦЖЯКФЧ",
  "КФЖЛДЧЦЯ",
  "ЮЛКФЖДЦЧ",
  "ЧФЛКДЯЖЦ",
];
const colorTexts = [
  "Ra6Tx",
  "dH9wQ",
  "N4bYe",
  "gL7Df",
  "T2aJx",
  "qZ8mV",
  "E5rWu",
  "cR3tF",
  "Y6nGa",
  "hP9kD",
  "C4fXe",
  "uA7sN",
  "G2dMr",
  "xV8bT",
  "F3qZa",
  "nK6wJ",
  "D9sUc",
  "rE5hP",
  "M7vQy",
  "tW4aR",
];
const lineTexts = [
  "Ha7nR",
  "vT4kP",
  "R6mXq",
  "cN9bY",
  "Fx3pA",
  "wQ5rE",
  "N8hZa",
  "uK6dM",
  "T2vBr",
  "qG7mH",
  "D4sWn",
  "yP9aK",
  "E3hRx",
  "nF6tC",
  "V8qMd",
  "bL2wG",
  "A7rNk",
  "mX4pD",
  "Q6cJy",
  "fH9vR",
];
for (const [type, texts] of [
  ["shapes", shapeTexts],
  ["color", colorTexts],
  ["lines", lineTexts],
])
  for (let i = 0; i < texts.length; i++) {
    const triangles = [0, 3, 6];
    freshSamples.push({
      id: `fresh-${type}-${i + 1}`,
      type,
      source: "synthetic",
      split: i < 8 ? "tune" : "final",
      text: texts[i],
      expected:
        type === "shapes"
          ? triangles.map((k) => texts[i][k]).join("")
          : texts[i],
      triangles,
      font: fonts[i % 4],
      seed: i,
      min: type === "shapes" ? 3 : 5,
      max: type === "shapes" ? 4 : type === "color" ? 5 : 6,
      noise: i % 3,
      slope: ((i % 5) - 2) * 0.035,
      crop:
        type === "color"
          ? { top: 0.15, bottom: 0.16, left: 0, right: 0 }
          : { top: 0, bottom: 0, left: 0, right: 0 },
    });
  }
// Second prospective evaluation, created only after first fresh-final errors were disclosed.
const prospective = {
  shapes: [
    "ФДЖЛЧКЦЯ",
    "КЖФЮЦЛЯД",
    "ЛФЮЖЧКДЦ",
    "ЧЯЖЦФКЛЮ",
    "МЮЛДЖЧКФ",
    "ЦФЖКЛЮЧД",
    "ЯЖЧФДКЛЦ",
    "ШЮФКЛЧДЯ",
    "РЧФЖЛКЦД",
    "ЮКЛЧДФЖЦ",
    "ЖЛФЧЦКДЯ",
    "КЧЖЛДЯФЦ",
  ],
  color: [
    "W3aFn",
    "sG8rY",
    "B6vQe",
    "dM2hT",
    "X9qLa",
    "cP4wK",
    "H7tRu",
    "fZ5nD",
    "J2xVe",
    "aR8sC",
    "Q6mYb",
    "kN3pF",
  ],
  lines: [
    "Y7rMp",
    "aD4vQ",
    "K6nTx",
    "gF9cW",
    "L3sRb",
    "pE8hZ",
    "C5wNk",
    "uJ2mG",
    "R9fVa",
    "hB6qP",
    "M4xDr",
    "tQ7nY",
  ],
};
for (const [type, texts] of Object.entries(prospective))
  texts.forEach((text, i) => {
    const template = freshSamples.filter((s) => s.type === type)[i];
    freshSamples.push({
      ...template,
      id: `prospective-${type}-${i + 1}`,
      split: "prospective",
      seed: i + 27,
      text,
      expected:
        type === "shapes"
          ? template.triangles.map((k) => text[k]).join("")
          : text,
      slope: ((i % 5) - 2) * 0.045,
      noise: (i + 1) % 3,
    });
  });
// Final untouched audit after fixing the competing-candidate confidence dilution bug.
const alphabets = {
  shapes: "АБВГДЖЗКЛМНОПРСТУФХЦЧШЩЫЭЮЯ",
  color: "AbCdEfGhJkLmNpQrStUvWxYz23456789",
  lines: "AbCdEfGhJkLmNpQrStUvWxYz23456789",
};
for (const type of ["shapes", "color", "lines"])
  for (let i = 0; i < 12; i++) {
    let seed =
        104729 +
        i * 997 +
        (type === "shapes" ? 0 : type === "color" ? 20011 : 40009),
      text = "";
    for (
      let j = 0;
      j < (type === "shapes" ? 8 : 5 + (i % 2) * (type === "lines" ? 1 : 0));
      j++
    ) {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      text += alphabets[type][seed % alphabets[type].length];
    }
    const template = freshSamples.filter((s) => s.type === type)[i];
    freshSamples.push({
      ...template,
      id: `audit-${type}-${i + 1}`,
      split: "audit",
      seed: i + 61,
      text,
      expected:
        type === "shapes"
          ? template.triangles.map((k) => text[k]).join("")
          : text,
      slope: ((i % 5) - 2) * 0.04,
      noise: i % 3,
    });
  }
export function renderFresh(sample) {
  const c = document.createElement("canvas");
  c.width = sample.type === "shapes" ? 400 : 330;
  c.height = sample.type === "shapes" ? 130 : 110;
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#f7f7f4";
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.textAlign = "center";
  const colors = [
    "#b56d40",
    "#507fc4",
    "#499e79",
    "#8664b6",
    "#bf576a",
    "#9e8c31",
  ];
  if (sample.type === "shapes") {
    ctx.fillStyle = "#454a4d";
    ctx.font = `38px "${sample.font}"`;
    [...sample.text].forEach((ch, i) => {
      ctx.save();
      ctx.translate(25 + 50 * i, 57);
      ctx.rotate(sample.slope * (i % 2 ? 1 : -1));
      ctx.fillText(ch, 0, 0);
      ctx.restore();
    });
    for (let i = 0; i < 8; i++) {
      const x = 25 + 50 * i,
        y = 98;
      ctx.fillStyle = colors[(i + sample.seed) % 6];
      ctx.beginPath();
      if (sample.triangles.includes(i)) {
        ctx.moveTo(x, y);
        ctx.lineTo(x - 15, y + 27);
        ctx.lineTo(x + 15, y + 27);
        ctx.closePath();
      } else if (i % 2) ctx.arc(x, y + 14, 13, 0, Math.PI * 2);
      else ctx.rect(x - 13, y, 26, 27);
      ctx.fill();
    }
  } else {
    if (sample.type === "color") {
      ctx.fillStyle = "#62676a";
      ctx.textAlign = "left";
      ctx.font = "10px monospace";
      ctx.fillText("Капча для demo.local", 6, 12);
      ctx.fillText("Synthetic labeled example", 6, 106);
      ctx.textAlign = "center";
    }
    const n = sample.text.length,
      step = 300 / n;
    [...sample.text].forEach((ch, i) => {
      ctx.save();
      ctx.translate(15 + step * (i + 0.5), sample.type === "color" ? 81 : 72);
      ctx.rotate(
        sample.type === "lines"
          ? sample.slope + ((i % 3) - 1) * 0.06
          : sample.slope * 0.3,
      );
      ctx.font = `${sample.type === "lines" ? "italic " : ""}bold ${sample.type === "color" ? 57 : 46}px "${sample.font}"`;
      ctx.fillStyle =
        sample.type === "color"
          ? i === sample.seed % 5
            ? "#747879"
            : colors[(i + sample.seed) % 6]
          : "#343a3d";
      ctx.fillText(ch, 0, 0);
      ctx.restore();
    });
    if (sample.type === "color") {
      ctx.save();
      ctx.translate(158, 65);
      ctx.rotate(-0.24);
      ctx.font = "italic 15px Arial";
      ctx.fillStyle = "#a2b92a";
      ctx.fillText("demo.local", 0, 0);
      ctx.restore();
    } else
      for (let k = 0; k < 5 + sample.noise; k++) {
        ctx.beginPath();
        ctx.strokeStyle = k % 2 ? "#979c9a" : "#c2c5c1";
        ctx.lineWidth = 0.6 + sample.noise * 0.1;
        for (let x = 0; x <= 330; x += 4) {
          const y = 21 + k * 10 + Math.sin((x + k * 13 + sample.seed) / 23) * 4;
          x ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
        }
        ctx.stroke();
      }
  }
  // Sparse low-contrast noise, seeded and separated from the glyph labels.
  for (let k = 0; k < sample.noise * 25; k++) {
    const x = (k * 73 + sample.seed * 17) % c.width,
      y = (k * 43 + sample.seed * 11) % (sample.type === "shapes" ? 75 : 95);
    ctx.fillStyle = "#c6cac4";
    ctx.fillRect(x, y, 1, 1);
  }
  return c.toDataURL();
}
