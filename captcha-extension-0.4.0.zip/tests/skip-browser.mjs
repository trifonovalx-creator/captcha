// Imported by the integration runner; works with the real content script and controller.
import assert from "node:assert/strict";
export async function testSkip({
  demo,
  controller,
  message,
  profileConfig,
  checks,
}) {
  const skipsBefore = await controller.evaluate(() => CaptchaLab.stats.skips);
  await controller.locator("#stop").click();
  await controller.locator("#settings").evaluate((d) => (d.open = true));
  await controller.locator("#auto").uncheck();
  await controller.locator("#skip-low").check();
  await controller.locator("#type").selectOption("color");
  await controller.locator("#crop-top").fill(".15");
  await controller.locator("#crop-bottom").fill(".16");
  await demo.evaluate(() => {
    Demo.selectSample("color-1");
    globalThis.skipClicks = 0;
    document
      .querySelector("#skip")
      .addEventListener("click", () => globalThis.skipClicks++);
  });
  await controller.locator("#start").click();
  await controller.waitForFunction(
    () =>
      document
        .querySelector("#status")
        .textContent.includes("Смена капчи подтверждена"),
    {},
    { timeout: 120000 },
  );
  assert.equal(await demo.locator("#sample-id").textContent(), "color-2");
  assert.equal(await demo.evaluate(() => skipClicks), 1);
  assert.equal(
    await controller.evaluate(() => CaptchaLab.stats.skips),
    skipsBefore + 1,
  );
  checks.push(
    "skip: completed low-confidence OCR clicks once and confirms new challenge",
  );
  // Atomic safety checks: fresh token after the previous auto session is stopped.
  const cfg = { ...profileConfig, skipSelector: "[data-captcha-skip]" };
  const arm = async () => {
    await message("START", { profile: cfg });
    return message("SNAPSHOT", { profile: cfg });
  };
  await demo.evaluate(() => Demo.selectSample("color-3"));
  let snap = await arm();
  await demo.locator("#answer").fill("моё");
  let r = await message("SKIP", { token: snap.token });
  assert.equal(r.clicked, false);
  assert.equal(await demo.evaluate(() => skipClicks), 1);
  checks.push("skip: manual text typed after snapshot cancels click");
  await demo.evaluate(() => Demo.selectSample("color-3"));
  snap = await arm();
  await demo.locator("#answer").focus();
  await demo.locator("#answer").press("Shift");
  await demo.evaluate(() =>
    document
      .querySelector("#answer")
      .dispatchEvent(
        new InputEvent("beforeinput", {
          bubbles: true,
          inputType: "insertText",
          data: "a",
        }),
      ),
  );
  r = await message("SKIP", { token: snap.token });
  assert.equal(r.clicked, false);
  checks.push(
    "skip: beforeinput/composition activity with empty value cancels stale click",
  );
  await demo.evaluate(() => Demo.selectSample("color-3"));
  snap = await arm();
  await demo.evaluate(() => Demo.selectSample("color-4"));
  r = await message("SKIP", { token: snap.token });
  assert.equal(r.clicked, false);
  checks.push("skip: late OCR for prior image never clicks");
  await message("STOP");
  await demo.locator("#skip").evaluate((e) => (e.disabled = true));
  await controller.locator("#start").click();
  await controller.waitForFunction(
    () => document.querySelector("#status").textContent.includes("отключена"),
    {},
    { timeout: 120000 },
  );
  assert.equal(await demo.evaluate(() => skipClicks), 1);
  checks.push("skip: disabled button stops processing");
  await demo.locator("#skip").evaluate((e) => (e.disabled = false));
  await controller.locator("#selector-skipSelector").fill("#missing-skip");
  await controller.locator("#start").click();
  await controller.waitForFunction(
    () => document.querySelector("#status").textContent.includes("найдено 0"),
    {},
    { timeout: 120000 },
  );
  assert.equal(await demo.evaluate(() => skipClicks), 1);
  checks.push("skip: missing button stops processing");
  await controller
    .locator("#selector-skipSelector")
    .fill("[data-captcha-skip]");
  await controller.locator("#selector-skipSelector").fill("[data-captcha-max]");
  await controller.locator("#start").click();
  await controller.waitForFunction(
    () =>
      document
        .querySelector("#status")
        .textContent.includes("не является кнопкой"),
    {},
    { timeout: 120000 },
  );
  assert.equal(await demo.evaluate(() => skipClicks), 1);
  checks.push("skip: selector matching a non-button refuses immediately");
  await controller
    .locator("#selector-skipSelector")
    .fill("[data-captcha-skip]");
  // Clone removes demo refresh handler, but preserves an explicit click counter.
  await demo.evaluate(() => {
    Demo.selectSample("color-5");
    const old = document.querySelector("#skip"),
      b = old.cloneNode(true);
    old.replaceWith(b);
    b.addEventListener("click", () => {
      globalThis.skipClicks++;
      document.querySelector("[data-captcha-max]").textContent = "max 6";
    });
  });
  await controller.locator("#start").click();
  await controller.waitForFunction(
    () =>
      document
        .querySelector("#status")
        .textContent.includes("капча не сменилась"),
    {},
    { timeout: 120000 },
  );
  assert.equal(await demo.evaluate(() => skipClicks), 2);
  checks.push(
    "skip: only length-limit mutation is not a new captcha; timeout, one click, no retry",
  );
  await controller.locator("#start").click();
  await controller.waitForFunction(
    () => document.querySelector("#status").textContent.includes("уже нажато"),
    {},
    { timeout: 120000 },
  );
  assert.equal(await demo.evaluate(() => skipClicks), 2);
  checks.push(
    "skip: restarting cannot click the same unchanged challenge twice",
  );
  // Technical OCR/capture error must not be counted as low confidence.
  await demo.evaluate(() => {
    Demo.selectSample("color-6");
    const c = document.querySelector("canvas");
    globalThis.savedForError = c;
    const img = new Image();
    img.src = "data:image/png;base64,bad";
    img.setAttribute("data-captcha-image", "");
    c.replaceWith(img);
  });
  await controller.locator("#start").click();
  await controller.waitForFunction(
    () =>
      document
        .querySelector("#status")
        .textContent.includes("Техническая ошибка"),
    {},
    { timeout: 120000 },
  );
  assert.equal(await demo.evaluate(() => skipClicks), 2);
  checks.push("skip: technical image error causes no click");
  await demo.evaluate(() =>
    document
      .querySelector("img[data-captcha-image]")
      .replaceWith(savedForError),
  );
  await controller.locator("#skip-low").uncheck();
  await controller.locator("#type").selectOption("auto");
  await controller.locator("#crop-top").fill("0");
  await controller.locator("#crop-bottom").fill("0");
  // A configured site response is the only source of correctness counters.
  await controller.locator("#selector-feedbackSelector").fill("#feedback");
  await controller
    .locator("#selector-feedbackSuccess")
    .fill("Верно. Ответ полностью совпал с эталоном.");
  await controller
    .locator("#selector-feedbackFailure")
    .fill("Ответ отличается от эталона. Проверьте символы и регистр.");
  await demo.evaluate(() => Demo.selectSample("shapes-1"));
  await controller.locator("#start").click();
  await controller.waitForFunction(
    () =>
      document.querySelector("#status").textContent.includes("Ответ внесён"),
    {},
    { timeout: 120000 },
  );
  const before = await controller.evaluate(() => CaptchaLab.stats.correct);
  await demo.locator("#submit").click();
  await controller.waitForFunction(
    (n) => CaptchaLab.stats.correct === n + 1,
    before,
  );
  checks.push(
    "feedback: correctness increments only after explicit site response",
  );
}
