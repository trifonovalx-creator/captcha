import test from "node:test";
import assert from "node:assert/strict";
import {
  untilDeadline,
  BudgetExpired,
  OCR_BUDGET_MS,
  ACTION_DEADLINE_MS,
} from "../src/budget.js";
import { decodeCTC, helperTensor } from "../src/ctc.js";
import { parseCSV, evaluateObservations } from "../src/observations.js";
test("fixed production budgets reserve 2 seconds for action", () => {
  assert.equal(OCR_BUDGET_MS, 28000);
  assert.equal(ACTION_DEADLINE_MS, 30000);
});
test("unresolved OCR expires; a late result cannot resolve the raced task", async () => {
  let done;
  const never = new Promise((r) => (done = r));
  await assert.rejects(untilDeadline(never, Date.now() + 15), BudgetExpired);
  done("late");
});
test("cancellation unblocks the queue independently of an OCR promise", async () => {
  const c = new AbortController();
  const p = untilDeadline(new Promise(() => {}), Date.now() + 1000, c.signal);
  c.abort(new DOMException("stop", "AbortError"));
  await assert.rejects(p, { name: "AbortError" });
});
test("CTC keeps case, collapses repeats and handles blank with zero confidence", () => {
  const out = decodeCTC(
    new Float32Array([
      0.01, 0.98, 0.01, 0.01, 0.98, 0.01, 0.99, 0.005, 0.005, 0.01, 0.01, 0.98,
    ]),
    [1, 4, 3],
    ["", "a", "A"],
    "aA",
  );
  assert.equal(out.text, "aA");
  assert.equal(
    decodeCTC(new Float32Array([1, 0, 0]), [1, 1, 3], ["", "a", "A"], "aA")
      .confidence,
    0,
  );
});
test("Helper preprocessing uses BGR channels and zero right padding", () => {
  const x = helperTensor(new Uint8ClampedArray([255, 0, 0, 255]), 1, 1, 2);
  assert.deepEqual([...x], [-1, 0, -1, 0, 1, 0]);
});
test("folder CSV supports quoted fields and preserves manual case", () => {
  assert.deepEqual(parseCSV('file,type,answer\r\n"a,b.png",color,aB3\r\n')[0], {
    file: "a,b.png",
    type: "color",
    answer: "aB3",
  });
});
test("unverified observations never count as measured accuracy", () => {
  const r = evaluateObservations([
    { answer: "aB3", labelVerified: false, candidate: "aB3", wouldFill: true },
    { answer: "aB3", labelVerified: true, candidate: "ab3", wouldFill: true },
  ]);
  assert.equal(r.length, 1);
  assert.equal(r[0].incorrect, true);
});
