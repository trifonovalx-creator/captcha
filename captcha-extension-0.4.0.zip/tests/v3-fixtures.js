const CYR = "АБВГДЕЖЗКЛМНОПРСТУФХЦЧШЩЫЭЮЯ",
  LAT = "AbCdEfGhJkLmNpQrStUvWxYz23456789";
export const v3Samples = [];
for (const split of ["tune3", "eval3"])
  for (const type of ["shapes", "color", "lines"])
    for (let i = 0; i < 12; i++) {
      const cyr = type === "shapes" || (type === "lines" && i % 2 === 1),
        alphabet = cyr ? CYR : LAT,
        len = type === "shapes" ? 8 : type === "lines" ? 5 + (i % 2) : 5;
      let seed =
          937781 +
          (split === "eval3" ? 117013 : 0) +
          (type === "shapes" ? 0 : type === "color" ? 1933 : 7187) +
          i * 65537,
        text = "";
      for (let j = 0; j < len; j++) {
        seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
        text += alphabet[(seed >>> 12) % alphabet.length];
      }
      const triangles = [0, 3, 6],
        font =
          split === "tune3"
            ? ["Arial", "Georgia"][i % 2]
            : ["Verdana", "Courier New"][i % 2];
      v3Samples.push({
        id: `${split}-${type}-${i + 1}`,
        type,
        split,
        source: "synthetic",
        font,
        seed: i + 119,
        noise: i % 3,
        slope: ((i % 5) - 2) * 0.04,
        text,
        triangles,
        expected:
          type === "shapes" ? triangles.map((k) => text[k]).join("") : text,
        min: type === "shapes" ? 3 : 5,
        max: type === "shapes" ? 4 : type === "color" ? 5 : 6,
        alphabet: cyr
          ? "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
          : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
        crop:
          type === "color"
            ? { top: 0.15, bottom: 0.16, left: 0, right: 0 }
            : { top: 0, bottom: 0, left: 0, right: 0 },
      });
    }
